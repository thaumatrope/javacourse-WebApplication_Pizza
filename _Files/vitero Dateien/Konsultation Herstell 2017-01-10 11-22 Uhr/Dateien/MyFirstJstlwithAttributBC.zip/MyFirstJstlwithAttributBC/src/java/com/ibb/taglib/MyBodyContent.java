/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.taglib;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 *
 * @author schulung
 */
public class MyBodyContent extends BodyTagSupport{
    
    public int doAfterBody(){
        try {
            BodyContent bc=getBodyContent();
            JspWriter out=bc.getEnclosingWriter();
            String text=bc.getString();
            out.print(text);
            System.out.println("Ausgabe Inhalt#########" +text);
           
        } catch (IOException ex) {
            Logger.getLogger(MyBodyContent.class.getName()).log(Level.SEVERE, null, ex);
        }
         return SKIP_BODY;
    }
    
}
