/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappeLib;


import java.util.Date;
import java.util.List;



/**
 *
 * @author IBB Teilnehmer
 */
public class BestellPosition {
    private int p_id;
    private int k_id;
    private int anzahl;
    private int b_id;
    private int s_id;
    private Double preiss;

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public int getK_id() {
        return k_id;
    }

    public void setK_id(int k_id) {
        this.k_id = k_id;
    }
    
 
    public int getAnzahl() {
        return anzahl;
    }

    public void setAnzahl(int anzahl) {
        this.anzahl = anzahl;
    }

    public int getB_id() {
        return b_id;
    }

    public void setB_id(int b_id) {
        this.b_id = b_id;
    }

   

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int sp_id) {
        this.s_id = sp_id;
    }

    public Double getPreiss() {
        return preiss;
    }

    public void setPreiss(Double preiss) {
        this.preiss = preiss;
    }

    
   
    
    
    
}
