/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappeLib;



/**
 *
 * @author IBB Teilnehmer
 * 
 * Das ist ein POJO
 */
public class Kunden {
    
    public int k_id;
    private String k_vorname;
    private String k_nachname;
    private String k_ort;
    private String k_strasse;
    private String k_plz; 

    public Kunden() {
        k_id = 0;
        k_vorname="";
        k_nachname="";
        k_strasse = "";
        k_plz = "";
        k_ort = "";
    }
    
    
    public Kunden(int k_id, String vorname, String nachname, String ort, 
            String strasse, String plz){
        this.k_id = k_id;
        this.k_vorname = vorname;
        this.k_nachname = nachname;
        this.k_ort = ort;
        this.k_strasse = strasse;
        this.k_plz = plz;
    }

    public int getK_id() {
        return k_id;
    }

    public void setK_id(int k_id) {
        this.k_id = k_id;
    }

    public String getK_vorname() {
        return k_vorname;
    }

    public void setK_vorname(String k_vorname) {
        this.k_vorname = k_vorname;
    }

    public String getK_nachname() {
        return k_nachname;
    }

    public void setK_nachname(String k_nachname) {
        this.k_nachname = k_nachname;
    }

    public String getK_ort() {
        return k_ort;
    }

    public void setK_ort(String k_ort) {
        this.k_ort = k_ort;
    }

    public String getK_strasse() {
        return k_strasse;
    }

    public void setK_strasse(String k_strasse) {
        this.k_strasse = k_strasse;
    }

    public String getK_plz() {
        return k_plz;
    }

    public void setK_plz(String k_plz) {
        this.k_plz = k_plz;
    }

    

    public String getStrasse() {
        return k_strasse;
    }

    /**
     * @param strasse the strasse to set
     */
    public void setStrasse(String strasse) {
        this.k_strasse = strasse;
    }

    /**
     * @return the plz
     */
    public String getPlz() {
        return k_plz;
    }

    /**
     * @param plz the plz to set
     */
    public void setPlz(String plz) {
        this.k_plz = plz;
    }
    

    
}
