/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappeLib;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author IBB Teilnehmer
 */
public class Bestellung implements Serializable{
    private int b_id;
    private String ipAdresse;
    private String sessionId;
    private Double gesamtpreis;
    private String bestellungsdatum;
    private List<BestellPosition> bestellungsListe;
    private Kunden myKunde;

    /**
     * Das ist Doku
     */
    public Bestellung() {
       bestellungsListe=new ArrayList();
    }

    
    
    
    public String getIpAdresse() {
        return ipAdresse;
    }

    public void setIpAdresse(String ipAdresse) {
        this.ipAdresse = ipAdresse;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getBestellungsdatum() {
        return bestellungsdatum;
    }

    public void setBestellungsdatum(String bestellungsdatum) {
        this.bestellungsdatum = bestellungsdatum;
    }

    public Double getGesamtpreis() {
        Double gesamtPreis = 0.0;
        for (BestellPosition item: this.bestellungsListe) {
            gesamtPreis = gesamtPreis + (item.getAnzahl() * item.getPreiss());
        }
        return gesamtpreis;
    }

    public void setGesamtpreis(Double gesamtpreis) {
        this.gesamtpreis = gesamtpreis;
    }

    public List<BestellPosition> getBestellungsListe() {
        return bestellungsListe;
    }

    public void setBestellungsListe(List<BestellPosition> bestellungsListe) {
        this.bestellungsListe = bestellungsListe;
    }

    public int getB_id() {
        return b_id;
    }

    public void setB_id(int id) {
        this.b_id = id;
    }

    public Kunden getMyKunde() {
        return myKunde;
    }

    public void setMyKunde(Kunden myKunde) {
        this.myKunde = myKunde;
    }
    
    
    
    
    
}
