/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mappeLib;



/**
 *
 * @author IBB Teilnehmer
 */
public class Speise {

    private int s_id;
    private String bezeichnung;
    private double preiss;
    private int anzahl;
   

    public Speise() {
       
        this.bezeichnung = "";
        this.preiss = 0.0;
        this.anzahl = 0;
        
    }

    public Speise(String name, double preis, int id, double kosten) {
        this.bezeichnung = name;
        this.preiss = preis;
        this.s_id = id;
        

    }

    public Speise(String name, double preis, int id, int anz, double kosten) {
        this.bezeichnung = bezeichnung;
        this.preiss = preis;
        this.s_id = id;
        this.anzahl = anz;
       

    }

   

    public void setName(String name) {
        this.bezeichnung = name;
    }

    

    public double getPreiss() {
        return preiss;
    }

    public void setPreiss(double preiss) {
        this.preiss = preiss;
    }

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int id) {
        this.s_id = id;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public int getAnzahl() {
        return anzahl;
    }

    public void setAnzahl(int anzahl) {
        this.anzahl = anzahl;
    }
}


//    public int addSpeisen(int bestellungId) throws SQLException {
//
////            Context ctx = new InitialContext();
////            DataSource ds = (DataSource)ctx.lookup("jdbc/nhmPizzeria");
//        Connection dbConnection = getConnection();
//
//        this.bestellungId = bestellungId;
//        PreparedStatement stmt = null;
//        ResultSet generatedKeys = null;
//        try {
//            stmt = dbConnection.prepareStatement(
//                    "insert into diebestellung"
//                    + " (sp_id, sp_anzahl, sp_preiss)"
//                    + " values (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
//
//            stmt.setInt(1, this.id);
//            stmt.setInt(2, this.anzahl);
//            stmt.setDouble(3, this.preiss);
//
//            int affectedRows = stmt.executeUpdate();
//
//            if (affectedRows == 0) {
//                throw new SQLException("Creating user failed, no rows affected.");
//            }
//
//            generatedKeys = stmt.getGeneratedKeys();
//
//            if (generatedKeys.next()) {
//                this.id = generatedKeys.getInt(1);
//            } else {
//                throw new SQLException("Creating user failed, no ID obtained.");
//            }
//            generatedKeys.close();
//
//        } catch (SQLException ex) {
//            System.out.print("SQL-Exception beim Speichern der Speise:" + ex);
//        } finally {
//            stmt.close();
//
//            dbConnection.close();
//        }
//        return this.id;
//    }

