/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ibb.model;

import java.sql.Date;

/** POJO
 * Plain
 * Old
 * Java 
 * Object
 *
 * @author Schulung
 */
public class Person {
    private String firstname;
    private String lastname;
    private String email;
    private String handy;
    private Date since; 
    
    
    /**
     * Holt den Vornamen
     * @return 
     */
    public String getFirstname() {
        return firstname;
    }

    public String getHandy() {
        return handy;
    }

    public void setHandy(String handy) {
        this.handy = handy;
    }

    
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getSince() {
        return since;
    }

    public void setSince(Date since) {
        this.since = since;
    }

  
    
   
    
}
