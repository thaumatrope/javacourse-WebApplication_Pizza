/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.dao;



import com.ibb.model.SportArt;
import com.ibb.model.SportArtBewertung;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Schulung
 */
public class DaoSportart extends GConnection {


    
    
    
    public List<SportArt> getListSportArt() {
        
        List<SportArt> listP = new ArrayList();
        Connection con = null;
        Statement stm = null;
        ResultSet rs = null;
        try {
            con = getConnection();
            if (con == null) {
                return null;
            }
            stm = con.createStatement();
            rs = stm.executeQuery("SELECT spid,bezeichnung FROM sportart");
            
            while (rs.next()) {
                SportArt en = new SportArt();
                en.setSpId(rs.getInt("spid"));
                en.setBezeichnung(rs.getString("bezeichnung"));
                                        
                listP.add(en);
            }

        } catch (SQLException ex) {
            Logger.getLogger(SportArtBewertung.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e) {
                Logger.getLogger(SportArtBewertung.class.getName()).log(Level.SEVERE, null, e);
            }
            try {
                if (stm != null) {
                    stm.close();
                }
            } catch (Exception e) {
                Logger.getLogger(SportArtBewertung.class.getName()).log(Level.SEVERE, null, e);
            }
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
               Logger.getLogger(SportArtBewertung.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return listP;
    }
    public boolean store(SportArtBewertung mySport,Integer pId) {
        Connection con = null;
        PreparedStatement stm = null;
        boolean stored = false;
        try {
            
            con = getConnection();
            if(con == null) return false;
            stm = con.prepareStatement("INSERT INTO sportartbewertung (pId,bewertung,spbId) VALUES(?,?,?)");
            stm.setInt(1, pId);
            stm.setString(2, mySport.getBewertung().trim());
            stm.setInt(3, mySport.getSpId() );
            int rows = stm.executeUpdate();
            con.commit();
            stored = rows == 1;
        } catch (SQLException ex) {
            Logger.getLogger(SportArt.class.getName()).log(Level.SEVERE, null, ex);
            stored = false;
        } finally {
            try { if( stm != null) stm.close(); } catch(Exception e) {}
            try { if( con != null) con.close(); } catch(Exception e) {}
        }
        return stored;
    }
    
}
