/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibb.model;

/**
 *
 * @author Schulung
 */
public class SportArtBewertung extends SportArt{
     private String bewertung;
    

    public SportArtBewertung() {
    }

    public SportArtBewertung( String bezeichnung, String bewertung,String id) {
        super(bezeichnung);
        this.setSpId(Integer.parseInt(id));
        this.bewertung = bewertung;
    }

       
    
    public String getBewertung() {
        return bewertung;
    }

    public void setBewertung(String bewertung) {
        this.bewertung = bewertung;
    }
     
     
     
}
