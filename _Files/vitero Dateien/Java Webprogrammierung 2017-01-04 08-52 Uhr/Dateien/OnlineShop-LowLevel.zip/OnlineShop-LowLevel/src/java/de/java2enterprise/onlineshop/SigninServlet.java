package de.java2enterprise.onlineshop;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;


@WebServlet("/signin")
public class SigninServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(
		HttpServletRequest request, 
		HttpServletResponse response) 
				throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
				
		try {
                    
                    //request.login(email, password);
			Customer customer = find(email, password,request);
			
			if(customer!=null) {
				HttpSession session = request.getSession();
				session.setAttribute("customer", customer);
			}
		} catch (Exception e) {
			throw new ServletException(e.getMessage());
		}
		response.setContentType("text/html;charset=UTF-8");
		
		RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);
	}
	
	public Customer find(String _email, String _password,HttpServletRequest request) {	
	    Customer cus;
            
            try {
               request.login(_email, _password);
               cus=new Customer(_email, _password);
            } catch (ServletException ex) {
                Logger.getLogger(SigninServlet.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
//            try {
//                Connection con =
//                        ((DataSource)InitialContext.
//                                doLookup("jdbc/onlineshop")).getConnection();
//                PreparedStatement stmt = con.prepareStatement(
//                        "SELECT " +
//                                "id, " +
//                                "email, " +
//                                "password " +
//                                "FROM customer " +
//                                "WHERE email=? " +
//                                "AND password=?");
//                
//                stmt.setString(1, _email);
//                stmt.setString(2, _password);
//                
//                ResultSet rs = stmt.executeQuery();
//                if(rs.next()) {
//                    
//                    Customer customer = new Customer();
//                    
//                    Long id = Long.valueOf(rs.getLong("id"));
//                    customer.setId(id);
//                    
//                    String email = rs.getString("email");
//                    customer.setEmail(email);
//                    
//                    String password = rs.getString("password");
//                    customer.setPassword(password);
//                    
//                    return customer;
//                }
//                con.close();
//                return null;
//            } catch (NamingException ex) {
//                Logger.getLogger(SigninServlet.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (SQLException ex) {
//                Logger.getLogger(SigninServlet.class.getName()).log(Level.SEVERE, null, ex);
//            }
            return cus;
	}

}
