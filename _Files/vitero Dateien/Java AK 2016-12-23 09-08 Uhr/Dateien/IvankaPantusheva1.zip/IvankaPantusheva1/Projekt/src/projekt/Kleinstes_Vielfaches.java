
package projekt;

/**
 *
 * @author Ivanka Pantusheva
 */
public class Kleinstes_Vielfaches implements AufgabeLoesen {
    
   @Override
    public String start(){
        int number = 0, divisor, rest, divisions;

        do {
            number += 60;
            divisions = 14; // Es sind 14 Zahlen von 7 bis 20

            for (divisor = 7; (divisor < 21); divisor++)
            {
                rest = number % divisor;
                divisions--;

                if (rest != 0)
                {
                    //System.out.println("   " + number + " % " + divisor + " != 0 (Rest " + rest + ")");
                    break;
                }
            }
        } while (divisions > 0);
        
        String text = number + " kann ohne Rest durch 1 bis 20 geteilt werden";
        
        return(text);
    }
}
    
