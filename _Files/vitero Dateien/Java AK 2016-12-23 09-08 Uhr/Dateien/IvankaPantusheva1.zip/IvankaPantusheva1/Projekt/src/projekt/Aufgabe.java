
package projekt;

/**
 *
 * @author Ivanka Pantusheva
 */
public class Aufgabe {
    private int id;
    private String aufgabeName;
    
    public Aufgabe(int id, String aufgabeName){
        
        this.id=id;
        this.aufgabeName=aufgabeName;
    }
    
     public Aufgabe(){
       
    }
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id=id;
    }
    public String getAufgabeName(){
        return aufgabeName;
    }
    
    public void setAufgabeName(String aufgabeName){
        this.aufgabeName=aufgabeName;
    }
   
}
