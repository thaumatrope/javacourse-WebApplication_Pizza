package projekt;


/**
 *
 * @author Ivanka Pantusheva
 */
public class DifferenzQuadratZahlen implements AufgabeLoesen{
    
    @Override
    public String start() {
        int limit = 100;
        String text = null;
        text = "Die Differenz ist " + cleverA(limit);
        return (text);
    }
 
    private long cleverA(int limit) {
        long difference = 0;
        long sum = (1 + limit) * (limit / 2);

        if (limit % 2 != 0) {
            sum += (limit + 1) / 2;
        }

        for (int i = 1; i < limit + 1; i++) {
            difference += i * (sum - i);
        }

        return difference;
    }    
}
