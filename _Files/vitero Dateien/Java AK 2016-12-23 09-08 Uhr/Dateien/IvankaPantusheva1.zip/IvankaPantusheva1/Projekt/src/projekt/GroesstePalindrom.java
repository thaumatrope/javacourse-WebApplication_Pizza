
package projekt;

/**
 *
 * @author Ivanka Pantusheva
 */
public class GroesstePalindrom implements AufgabeLoesen{
    
    @Override
    public String start() {
        int num1 = 999, num2 = 999, num2Start = 999, length, i, j, num1Temp, num2Temp;
        String resultAsString;
        boolean palindromFound;

        do {
            palindromFound = true;
            resultAsString = String.valueOf(num1 * num2);

            length = resultAsString.length();

            for (i = 0, j = length - 1; (i < j) && palindromFound; i++, j--)
            {
                if (resultAsString.charAt(i) != resultAsString.charAt(j))
                    palindromFound = false;
            }
            num1Temp = num1;
            num2Temp = num2;
            
            num2--;

            if ((num2 == 99) && (num1 > 99))
            {
                num1--;
                num2 = --num2Start;
            }
        } while (!palindromFound && (num1 > 99) && (num2 > 99));
        
        String text= null;
        
        if (palindromFound){
            text = "Palindrom gefunden: " + resultAsString + " = " + num1Temp +" * " + num2Temp;
        }else{
            text = "Palindrom wurde nicht gefunden";
        }
        return text;
    }
}

