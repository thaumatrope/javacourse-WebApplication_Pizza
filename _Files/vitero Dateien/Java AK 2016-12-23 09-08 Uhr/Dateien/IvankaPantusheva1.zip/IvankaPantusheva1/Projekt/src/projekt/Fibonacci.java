
package projekt;

import java.awt.SystemColor;
/**
 *
 * @author Ivanka Pantusheva
 */
public class Fibonacci {
    
    public String start(int n){
        
        String text = fib(n);
        return (text);
    }
    
    
    
    public String fib(int n){
        long fn=1, fn_1=1,fn_2=1;
        String text=" ";
        
        if(n==1)
            text=fn+" ";
        
        else if(n>1)
            text = fn+", "+fn+", ";
        
        for (int i=2;i<n;i++){
            fn=fn_1+fn_2;
            fn_2=fn_1;
            fn_1=fn;
            text = text + fn+", ";
        }
   
        text = text + " ";
        
        return (text);
        
    }

    
        
}

