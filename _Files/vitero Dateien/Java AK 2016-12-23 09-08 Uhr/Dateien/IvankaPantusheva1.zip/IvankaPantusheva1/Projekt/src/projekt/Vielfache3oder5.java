
package projekt;

/**
 *
 * @author Ivanka Pantusheva
 */
public class Vielfache3oder5 implements AufgabeLoesen {
    
    @Override
    public String start(){
        int sum = 0;
        String text = " ";
        for (int i=1 ; i<=1000 ; i++){
            if((i%3==0)||(i%5==0)){
                sum+=i;
                text = text+ " " + i;
            }   
        }

        return text;
    
    }
}
