
package projekt;

import javax.swing.JFrame;

/**
 *
 * @author Ivanka Pantusheva
 */
public class Projekt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        
        HauptFenster3 i=new HauptFenster3();
        i.setVisible(true);
        
    }
    
}

