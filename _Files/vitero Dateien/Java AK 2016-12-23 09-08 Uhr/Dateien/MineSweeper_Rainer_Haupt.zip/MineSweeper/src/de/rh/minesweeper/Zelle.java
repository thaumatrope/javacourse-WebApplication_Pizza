/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rh.minesweeper;

import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author IBB Teilnehmer
 */
public class Zelle {

    private Boolean debugModus = false;
    private String Resource = "class.Zelle";
    private int zeile;
    private int spalte;
    private int countNeighbours;
    private boolean mine = false;
    private boolean flagged = false;
    private boolean offen = false;
    private boolean visible = false;
    private JButton schalter = new JButton();
    private JLabel anzeige;
    private JLabel restMinen;
    private String anzeigeText;

    public Zelle(int zeile, int spalte, JLabel restMinen) {
        this.zeile = zeile;
        this.spalte = spalte;
        this.restMinen = restMinen;
        countNeighbours = 0;
        anzeigeText = " ";
        if (debugModus) {
            System.out.println(Resource + ".constructor - zeile " + zeile + " spalte " + spalte);
        }
        schalter.setText(anzeigeText);
    }

    public boolean isOffen() {
        return offen;
    }

    public void setOffen(boolean offen) {
        this.offen = offen;
    }

    public JButton getSchalter() {
        return schalter;
    }

    public void setSchalter(JButton schalter) {
        this.schalter = schalter;
    }

    public String getSchalterLabel() {
        return schalter.getText();
    }

    public void setSchalterLabel(String schalterText) {
        this.schalter.setText(schalterText);
    }

    public int getZeile() {
        return zeile;
    }

    public void setZeile(int zeile) {
        this.zeile = zeile;
    }

    public int getSpalte() {
        return spalte;
    }

    public void setSpalte(int spalte) {
        this.spalte = spalte;
    }

    public int getCountNeighbours() {
        return countNeighbours;
    }

    public void setCountNeighbours(int countNeighbours) {
        this.countNeighbours = countNeighbours;
        if (debugModus) {
            System.out.println(Resource + ".setCountNeighbours: Zeile " + zeile + " Spalte " + spalte + " countNeighbours " + countNeighbours + " mine " + mine);
        }
    }

    public boolean isMine() {
        return mine;
    }

    public void setMine(boolean mine) {
        this.mine = mine;
        if (debugModus) {
            System.out.println(Resource + ".setMine: Zeile " + zeile + " Spalte " + spalte + " mine " + mine);
        }
    }

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }

    public void toggleFlag() {
        //this.flagged = !flagged;
        if (debugModus) {
            System.out.println(" in toggleFlag - " + flagged);
        }
        if (!this.flagged) {
            Settings.flaggenGesetzt++;
            setFlagged(true);
            schalter.setText("F");
        } else {
            Settings.flaggenGesetzt--;
            setFlagged(false);
            schalter.setText(" ");
        }
        //TODO: Zaehler herauf- oder heruntersetzen und Flagge explizit umsetzen
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible() {
        this.visible = true;
        //TODO: auf Bomben ueberpruefen und gegebenenfalls Spiel beenden

    }

    public JLabel getAnzeige() {
        return anzeige;
    }

    public void setAnzeige(JLabel anzeige) {
        this.anzeige = anzeige;
    }

}
