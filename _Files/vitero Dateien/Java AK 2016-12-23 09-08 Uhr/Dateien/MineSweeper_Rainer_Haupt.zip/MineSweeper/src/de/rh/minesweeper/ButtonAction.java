/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rh.minesweeper;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author IBB Teilnehmer
 */
public class ButtonAction implements MouseListener {

    boolean debugModus = true;
    SpielPanel sPanel;
    Zelle zelle;
    JButton schalter;

    public ButtonAction(JButton schalter, SpielPanel sPanel, Zelle zelle) {
        this.sPanel = sPanel;
        this.schalter = schalter;
        this.zelle = zelle;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (debugModus) {
            System.out.println("mouseClicked(MouseEvent e) zelle.isVisible() " + zelle.isVisible());
            System.out.println("mouseClicked(MouseEvent e) zelle.isFlagged() " + zelle.isFlagged());
        }
        if (!zelle.isVisible()) {
            if (zelle.isMine() && !zelle.isFlagged() && e.getModifiers() == 16) {
                JOptionPane.showMessageDialog(null, "!!! Verloren !!!");
            } else {
                if (e.getModifiers() == 16) // if it's a regular clic
                {
                    //zelle.setVisible();
                    sPanel.setFlaggenGesetzt(sPanel.getFlaggenGesetzt() - 1);
                    System.out.println("mouseClicked(MouseEvent e) e.getModifiers() == 16 " + zelle.isFlagged());
                } else // if it's alt+clic, cmd+clic, maj+clic, ...
                {
                    zelle.toggleFlag();
                    sPanel.setFlaggenGesetzt(sPanel.getFlaggenGesetzt() + 1);
                    System.out.println("mouseClicked(MouseEvent e) NOT e.getModifiers() == 16 " + zelle.isFlagged());
                }
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
//        System.out.println("mousePressed(MouseEvent e)");
    }

    @Override
    public void mouseReleased(MouseEvent e) {
//        System.out.println("mouseReleased(MouseEvent e)");
    }

    @Override
    public void mouseEntered(MouseEvent e) {
//        System.out.println("mouseEntered(MouseEvent e)");
    }

    @Override
    public void mouseExited(MouseEvent e) {
//        System.out.println("mouseExited(MouseEvent e)");
    }
}
