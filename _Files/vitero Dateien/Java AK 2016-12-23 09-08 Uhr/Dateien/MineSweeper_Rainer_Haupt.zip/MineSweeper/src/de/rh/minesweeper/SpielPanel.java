/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rh.minesweeper;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.Random;
import javax.swing.JLabel;

/**
 *
 * @author IBB Teilnehmer
 */
public class SpielPanel extends JPanel {

    private Boolean debugModus = true;
    private String Resource = "class.SpielPanel";

    private int zeilen;
    private int spalten;
    private int anzahlBomben;
    private int flaggenGesetzt;
    JLabel restMinen;
    
    private Zelle[][] zellen;

    //private Schalterfeld sf;
    //private JPanel sPanel = new JPanel();
    public SpielPanel(int zeilen, int spalten, int bomben, JLabel restMinen) {
        initValues(zeilen, spalten, bomben, restMinen);
        initPanel(); //this.zeilen, this.spalten, anzahlBomben
    }

    public void initValues(int zeilen, int spalten, int bomben, JLabel restMinen) {
        this.zeilen = zeilen;
        this.spalten = spalten;
        this.anzahlBomben = bomben;
        this.restMinen = restMinen;
    }

    public void initPanel() { //int zeilen, int spalten, int bomben

        if (debugModus) {
            System.out.println(Resource + ".initPanel()");
        };
        //sf = new Schalterfeld(zeilen, spalten, bomben);
        this.removeAll();
        zellen = new Zelle[zeilen][spalten];

        this.setLayout(new GridLayout(zeilen, spalten, 0, 0)); //sf.getZeilen(), sf.getSpalten(),0,0));
        //zellen = sf.getZellen();
        for (int i = 0; i < zeilen; i++) {
            for (int j = 0; j < spalten; j++) {
                zellen[i][j] = new Zelle(i, j, restMinen);

                add(zellen[i][j].getSchalter());
                zellen[i][j].getSchalter().addMouseListener(new ButtonAction(zellen[i][j].getSchalter(), this, zellen[i][j]));

                if (debugModus) {
                    System.out.print(Resource + ".initPanel(): i " + i + " j " + j);
                    System.out.print(" - Flags: " + zellen[i][j].isFlagged() + "/");
                    System.out.print(zellen[i][j].isMine() + "/");
                    System.out.print(zellen[i][j].isVisible() + "/");
                    System.out.println(zellen[i][j].getSchalter().toString());
                }
            }
        }
        platziereMinen();              /*zeilen, spalten, anzahlBomben*/
        zaehleMinen();                 /*zeilen, spalten, anzahlBomben*/
    }

    public void platziereMinen() {     /*int zeilen, int spalten, int minen*/

        Random zufall = new Random();
        int zufallZeile, zufallSpalte;
        int bombenzaehler = 0;
        //this.zeilen = zeilen;
        //this.spalten = spalten;

        for (int i = 0; i < anzahlBomben; i++) {
            do {
                zufallZeile = zufall.nextInt(zeilen);
                zufallSpalte = zufall.nextInt(spalten);
                System.out.println(Resource + ".platziereMinen() in do " + zufallZeile + " " + zufallSpalte + " " + bombenzaehler);

            } while (zellen[zufallZeile][zufallSpalte].isMine());
            zellen[zufallZeile][zufallSpalte].setMine(true);
            bombenzaehler++;
            System.out.println(Resource + ".platziereMinen() in for " + zufallZeile + " " + zufallSpalte + " " + bombenzaehler);
        }
    }

    private void zaehleMinen(/*int zeilen, int spalten, int minen*/) {
        if (debugModus) {
            System.out.println(Resource + ".zaehleMinen: Start");
        }
        //this.zeilen = zeilen;
        //this.spalten = spalten;

        for (int i = 0; i < zeilen; i++) {
            for (int j = 0; j < spalten; j++) {
                int anzahlMinen = 0;
                if (feldExistiert((i - 1), (j))) {
                    if (debugModus) {
                        System.out.println(Resource + ".zaehleMinen: feldExistiert((i - 1), (j)) " + feldExistiert((i - 1), (j))
                                + " anzahlMinen " + anzahlMinen);
                    }
                    if (zellen[i - 1][j].isMine()) {
                        anzahlMinen++;
                        if (debugModus) {
                            System.out.println(Resource + ".zaehleMinen: feldExistiert((i - 1), (j)) " + feldExistiert((i - 1), (j))
                                    + " zellen[i - 1][j].isMine() " + zellen[i - 1][j].isMine()
                                    + " anzahlMinen " + anzahlMinen);
                        }
                    }
                }
                if (feldExistiert((i - 1), (j - 1)) && zellen[i - 1][j - 1].isMine()) {
                    anzahlMinen++;
                }
                if (feldExistiert((i), (j - 1)) && zellen[i][j - 1].isMine()) {
                    anzahlMinen++;
                }
                if (feldExistiert((i + 1), (j - 1)) && zellen[i + 1][j - 1].isMine()) {
                    anzahlMinen++;
                }
                if (feldExistiert((i + 1), (j)) && zellen[i + 1][j].isMine()) {
                    anzahlMinen++;
                }
                if (feldExistiert((i + 1), (j + 1)) && zellen[i + 1][j + 1].isMine()) {
                    anzahlMinen++;
                }
                if (feldExistiert((i), (j + 1)) && zellen[i][j + 1].isMine()) {
                    anzahlMinen++;
                }
                if (feldExistiert((i - 1), (j + 1)) && zellen[i - 1][j + 1].isMine()) {
                    anzahlMinen++;
                }
                zellen[i][j].setCountNeighbours(anzahlMinen);
                if (debugModus) {
                    System.out.println(Resource + ".zaehleMinen: Zeile " + i
                            + " Spalte " + j + " anzahlMinen " + anzahlMinen);
                }
            }
        }
    }

    public boolean feldExistiert(int zeile, int spalte) {
        Boolean existiert = false;
        if ((zeile >= 0 && zeile < zeilen) && (spalte >= 0 && spalte < spalten)) {
            existiert = true;
        }
        if (debugModus && false) {
            System.out.println(Resource + ".feldExistiert: existiert " + existiert
                    + " zeile " + zeile + " zeilen " + zeilen
                    + " spalte " + spalte + " spalten " + spalten);
        }
        return existiert;
    }

    public int getFlaggenGesetzt() {
        return flaggenGesetzt;
    }

    public void setFlaggenGesetzt(int flaggenGesetzt) {
        this.flaggenGesetzt = flaggenGesetzt;
    }

    public int getAnzahlBomben() {
        return anzahlBomben;
    }

}
