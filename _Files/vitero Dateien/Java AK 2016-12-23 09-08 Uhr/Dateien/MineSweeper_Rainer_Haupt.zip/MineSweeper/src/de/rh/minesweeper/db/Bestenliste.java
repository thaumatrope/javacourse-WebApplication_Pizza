/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rh.minesweeper.db;

import javax.swing.JFrame;
import java.sql.*;
import javax.swing.JTextArea;

/**
 *
 * @author IBB Teilnehmer
 */
public class Bestenliste {
    boolean debugModus = true;
    private int id;
    private String name;
    private int score;
    public Bestenliste() {
    }

    public JTextArea liesBestenliste() {
        JTextArea liste;
        liste = new JTextArea();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String verbindung = "jdbc:mysql://localhost:3306/minesweeper?zeroDateTimeBehavior=convertToNull";
            Connection myCon = DriverManager.getConnection(verbindung, "root", "");
            Statement mystm = myCon.createStatement();
            String abfrage = "Select name, score from highscores order by score desc";
            ResultSet meinRes = mystm.executeQuery(abfrage);
            System.out.println(meinRes);
            liste.append("Score\tName\n");
            while (meinRes.next()) {
                //String id = meinRes.getString(1);     //erster Index ist 1
                String name = meinRes.getString(1);   //erster Index ist 1
                String score = meinRes.getString(2);  //erster Index ist 1

                liste.append(score + "\t" + name + "\n");
            }
            meinRes.close();  // Resultset
            mystm.close();    // Statement
            myCon.close();    // Datenbankverbindung
        } catch (Exception ex) {
            System.out.println("Listenaufbau fehlgeschlagen! " + ex.toString());
        }
        return liste;
    }

    public void schreibeEintrag(String name, String score) {
        id = 1;
        int maxId = 0;
        int scoreActual = Integer.parseInt(score);
        int scoreDb = 1000000;
        boolean eintragExists = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String verbindung = "jdbc:mysql://localhost:3306/minesweeper?zeroDateTimeBehavior=convertToNull";
            Connection myCon = DriverManager.getConnection(verbindung, "root", "");
            Statement mystm = myCon.createStatement();
            String abfrage = "Select id, score from highscores where name like '" + name + "'";
            ResultSet meinRes = mystm.executeQuery(abfrage);
            System.out.println(abfrage + "/" + meinRes);
            while (meinRes.next()) {
                id = Integer.parseInt(meinRes.getString(1)); //erster Index ist 1
                scoreDb = Integer.parseInt(meinRes.getString(2));
                eintragExists = true;
            }

            if ((eintragExists) && (scoreDb < scoreActual)) { //update
                if (debugModus) System.out.println("eintragExists = " + eintragExists + " update ");
                abfrage = "update highscores set score = " + scoreActual + " where id = " + id ;
                mystm.executeUpdate(abfrage);
                
            } else if (!eintragExists) { //insert
                if (debugModus) System.out.println("eintragExists = " + eintragExists + " insert ");
                abfrage = "Select id, score from highscores";
                meinRes = mystm.executeQuery(abfrage);
                while (meinRes.next()) {
                    maxId = new Integer(meinRes.getString(1)).intValue(); //erster Index ist 1
                }
                maxId += 1;
                abfrage = "insert into highscores(id, name, score) values ( " 
                        + maxId + ", '" + name + "', " + scoreActual + ")";
                mystm.executeUpdate(abfrage);
            } 

            meinRes.close();  // Resultset
            mystm.close();    // Statement
            myCon.close();    // Datenbankverbindung
            
        } catch (Exception ex) {
            System.out.println("Highscore Eintrag fehlgeschlagen! " + ex.toString());
        }

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
