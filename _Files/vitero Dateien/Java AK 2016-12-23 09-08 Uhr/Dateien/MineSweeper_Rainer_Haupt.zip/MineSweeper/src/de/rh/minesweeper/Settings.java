/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rh.minesweeper;

/**
 *
 * @author IBB Teilnehmer
 */
public class Settings {

    public static int flaggenGesetzt;
    public static int anzahlBomben;
}
