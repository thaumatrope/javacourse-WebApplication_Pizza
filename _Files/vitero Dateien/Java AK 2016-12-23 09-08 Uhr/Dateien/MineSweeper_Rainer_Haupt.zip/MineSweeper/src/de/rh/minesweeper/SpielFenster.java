/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rh.minesweeper;

import de.rh.minesweeper.db.Bestenliste;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author IBB Teilnehmer
 */
public class SpielFenster extends JFrame implements ActionListener {

    boolean debugMode = false;
    int groesse = 0;

    private JMenuBar leiste = new JMenuBar();
    private JMenu eintrag1 = new JMenu("Spiel");
    private JMenu eintrag2 = new JMenu("Info");
    private JMenuItem item11 = new JMenuItem("5 x 5");
    private JMenuItem item12 = new JMenuItem("10 x 10");
    private JMenuItem item13 = new JMenuItem("15 x 15");
    private JMenuItem item21 = new JMenuItem("Bestenliste");
    private JMenuItem item22 = new JMenuItem("User setzen neu");
    private JMenuItem item23 = new JMenuItem("User setzen kleiner");
    private JMenuItem item24 = new JMenuItem("User setzen grösser");

    private int zeilen = 5;
    private int spalten = 5;
    private int bomben = 7;

//
    private JFrame frame = new JFrame();
    private JPanel header = new JPanel();
    private JFrame mineFrame = new JFrame();

    private JFrame bestListFrame = new JFrame();
    private JLabel restMinen = new JLabel("", JLabel.CENTER);
    private JButton start = new JButton("Start");
    private JLabel zeit = new JLabel("", JLabel.CENTER);

    private SpielPanel spielPanel = new SpielPanel(zeilen, spalten, bomben, restMinen);

//    private JPanel minePanel = new JPanel();
    private Bestenliste besteSpieler = new Bestenliste();

    public SpielFenster() {
        super("Minesweeper");
        init();
    }

    private void init() {

        Settings.flaggenGesetzt = 0;

        this.setLayout(new BorderLayout());

        header.setLayout(new GridLayout(1, 3));

        leiste.add(eintrag1);
        leiste.add(eintrag2);
        eintrag1.add(item11);
        eintrag1.add(item12);
        eintrag2.add(item21);
        eintrag2.add(item22);
        eintrag2.add(item23);
        eintrag2.add(item24);
        this.setJMenuBar(leiste);

        item11.addActionListener(this);
        item12.addActionListener(this);
        item21.addActionListener(this);
        item22.addActionListener(this);
        item23.addActionListener(this);
        item24.addActionListener(this);

        System.out.println(groesse);

        spielPanel.initValues(zeilen, spalten, bomben, restMinen);
        spielPanel.initPanel();

        int restMin = spielPanel.getAnzahlBomben() - spielPanel.getFlaggenGesetzt();
        restMinen.setText(Integer.toString(restMin));

        this.setSize(250, 350);
        this.setResizable(false);

        this.header.add(restMinen);
        this.header.add(start);
        this.header.add(zeit);

        this.add(header, BorderLayout.NORTH);
        this.add(spielPanel, BorderLayout.CENTER);
        this.add(getFooterPanel(), BorderLayout.SOUTH);

        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private JPanel getFooterPanel() {
        JPanel inner = new JPanel();
        inner.setLayout(new GridLayout(1, 2, 10, 0));
        inner.add(new JLabel("Footer"));
        inner.add(new JLabel("by RH-Solutions"));

        return inner;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == item11) {
            this.groesse = 1;
            zeilen = 5;
            spalten = 5;
            bomben = 7;
            this.setResizable(true);
            this.validate();
            this.setSize(250, 350);
            this.setResizable(false);
            spielPanel.initValues(zeilen, spalten, bomben, restMinen);
            spielPanel.initPanel();
        }
        if (e.getSource() == item12) {
            this.groesse = 2;
            zeilen = 10;
            spalten = 10;
            bomben = 15;
            this.setResizable(true);
            this.validate();
            this.setSize(500, 600);
            this.setResizable(false);
            spielPanel.initValues(zeilen, spalten, bomben, restMinen);
            spielPanel.initPanel();
        }
        if (e.getSource() == item21) {
            this.zeigeBestenListe();
            this.validate();
        }
        if (e.getSource() == item22) {
            this.schreibeEintragBL(1);
            this.validate();
        }
        if (e.getSource() == item23) {
            this.schreibeEintragBL(2);
            this.validate();
        }
        if (e.getSource() == item24) {
            this.schreibeEintragBL(3);
            this.validate();
        }

    }

    public void schreibeEintragBL(int art) {
        switch (art) {
            case 1:
                besteSpieler.schreibeEintrag("Peter", "88");
                break;
            case 2:
                besteSpieler.schreibeEintrag("Franz", "50");
                break;
            case 3:
                besteSpieler.schreibeEintrag("Franz", "150");
                break;
            default:

        }
    }

    public void zeigeBestenListe() {
        JPanel showPanel = new JPanel();
        bestListFrame.pack();

        showPanel.validate();
        showPanel.setLayout(new BorderLayout());
        showPanel.add(new JLabel("Bestenliste"), BorderLayout.NORTH);
        JTextArea anzeigeBesteSpiel = besteSpieler.liesBestenliste();
        showPanel.add(anzeigeBesteSpiel, BorderLayout.CENTER);
        bestListFrame.add(showPanel);

        bestListFrame.setVisible(true);
        bestListFrame.setResizable(true);
        bestListFrame.setSize(250, 350);
        bestListFrame.setResizable(false);
    }
}
