/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.panels.deco;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Teilnehmer
 */
public class South extends JPanel {

    private JLabel madeby = new JLabel("made by friqql MMXVI");

    /**
     * Der Süden
     */
    public South() {

        this.add(madeby);
        madeby.setForeground(Color.WHITE);
        this.setBackground(Color.decode("#234567"));

    }

}
