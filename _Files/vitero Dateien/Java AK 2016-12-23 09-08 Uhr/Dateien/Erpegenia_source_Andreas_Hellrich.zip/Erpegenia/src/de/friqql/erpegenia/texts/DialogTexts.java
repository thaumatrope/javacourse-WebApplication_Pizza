/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.texts;

import de.friqql.erpegenia.db.ReadTexts.ReadChapterTexts;
import de.friqql.erpegenia.db.ReadTexts.ReadDialogTexts;
import java.util.Map;

/**
 * Liest die Dialogtexte aus der Datenbank ein und speichert sie in eine hashmap
 *
 * @author Teilnehmer
 */
public class DialogTexts extends Texts {

    @Override
    public Map getTexts() {
        //Einlesen
        ReadDialogTexts read = new ReadDialogTexts();
        try {
            read.lesen();
        } //Nicht vorhanden
        catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        //Ablegen
        String[] gelesenes = read.getGelesen();

        //Dialogtexte
        dict.put("Good1", gelesenes[0]);
        dict.put("Bad1", gelesenes[1]);
        dict.put("Good2", gelesenes[2]);
        dict.put("Bad2", gelesenes[3]);
        dict.put("Good3", gelesenes[4]);
        dict.put("Bad3", gelesenes[5]);
        dict.put("Good4", gelesenes[6]);
        dict.put("Bad4", gelesenes[7]);
        dict.put("Good5", gelesenes[8]);
        dict.put("Bad5", gelesenes[9]);
        dict.put("Good6", gelesenes[10]);
        dict.put("Bad6", gelesenes[11]);
        dict.put("Good7", gelesenes[12]);
        dict.put("Bad7", gelesenes[13]);
        dict.put("Good8", gelesenes[14]);
        dict.put("Bad8", gelesenes[15]);
        dict.put("Good9", gelesenes[16]);
        dict.put("Bad9", gelesenes[17]);
        return dict;
    }
}
