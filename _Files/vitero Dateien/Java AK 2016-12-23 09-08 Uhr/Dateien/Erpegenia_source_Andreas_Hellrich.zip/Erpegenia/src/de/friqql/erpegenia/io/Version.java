/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 *
 * @author Teilnehmer
 */
public class Version {

    String version;

    // Liest die Version aus einer Textversion ein
    private void readVersion() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("io/version.txt"));
        try {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }
            version = sb.toString();
        } finally {
            br.close();
        }
    }

    //Gibt die Version (Oder eine Dummyversion) aus
    public String getVersion() {
        try {
            readVersion();
        } catch (Exception ex) {
            version = "ERPEGENIA by friqql";

            System.out.println("ERROR " + ex);
        }

        return version;

    }
}
