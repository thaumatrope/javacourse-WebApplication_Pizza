/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.dialogs.bad;

import de.friqql.erpegenia.texts.DialogTexts;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 * Spieler war bei Frage 4 böse.
 *
 * @author Teilnehmer
 */
public class C4bad extends JDialog implements ActionListener {

    private DialogTexts dt = new DialogTexts();
    private Map dict = dt.getTexts();
    private JTextArea jTextArea1 = new JTextArea();
    private JDialog me = this;

    /*
   Der Konstruktor der vierten bösen Nachricht
     */
    public C4bad(JFrame frame) {
        this.setLayout(new FlowLayout());
        jTextArea1.setText((String) dict.get("Bad4"));
        jTextArea1.setDisabledTextColor(Color.RED);
        jTextArea1.setEnabled(false);
        jTextArea1.setBackground(Color.decode("#F0F0F0"));

        this.setBackground(Color.BLACK);
        this.add(jTextArea1);
        this.setSize(300, 250);
        this.setTitle("Schlecht gemacht!");

        JButton close = new JButton();
        close.setSize(100, 50);
        close.setText("Fenster zu!");
        close.addActionListener(this);
        this.add(close);
        this.setLocationRelativeTo(frame);
        this.setModal(true);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        me.setVisible(false);
    }
}
