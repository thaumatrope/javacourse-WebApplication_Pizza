/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Alles was mit der Datenbankbehandlung des Spielers zu tun hat
 *
 * @author Teilnehmer
 */
public class Spielerliste {

    private String name;
    private int karma;
    private String spielerzahlstring;
    private int spielerzahl;
    private int id;
    private int running;
    private boolean runningbool;
    private String[] namen = new String[999];
    private int[] karmas = new int[999];
    private Map spieler = new HashMap();

    /**
     * Legt den Spieler an
     *
     * @param name
     * @param karma
     * @param crunning
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public void schreiben(String name, int karma, boolean crunning) throws ClassNotFoundException, SQLException {
        this.name = name;
        this.karma = karma;
        this.id = spielerzahlErmitteln() + 1;
        if (crunning == true) {
            this.running = 1;
        } else {
            this.running = 0;
        }

        Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon = DriverManager.getConnection(verbindung, "'root'", "");
        Statement mystm = (Statement) myCon.createStatement();
        String eingabe = "Insert INTO spieler ";

        eingabe += "(ID,Name,Karma,Running) values";

        eingabe += "(";

        eingabe += id;
        eingabe += " , ";
        eingabe += "'";
        eingabe += name;
        eingabe += "' , ";
        eingabe += karma;
        eingabe += " , ";
        eingabe += running;
        eingabe += ")";

        mystm.executeUpdate(eingabe);
        spielerzahlErmitteln();

    }

    /**
     * Fügt Karma hinzu
     *
     * @param ckarma
     * @param cplus
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    public void plusKarma(int ckarma, int cplus) throws ClassNotFoundException, SQLException{
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("FEHLER DATENBANK NICHT GEFUNDEN!");
        }
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon;
        try {
            myCon = DriverManager.getConnection(verbindung, "'root'", "");

            Statement mystm = (Statement) myCon.createStatement();
            this.karma = ckarma;
            karma += cplus;
            String eingabe = "UPDATE spieler ";
            eingabe += "SET Karma= ";
            eingabe += +karma;

            eingabe += " WHERE ID = ";
            try {
                eingabe += spielerzahlErmitteln();

            } catch (ClassNotFoundException ex) {
                System.out.println("ERROR: Datenbank nicht gefunden!");
            } catch (SQLException ex) {
                System.out.println("ERROR: SQL Fehler: " + ex);
            }

            mystm.executeUpdate(eingabe);
        } catch (SQLException ex) {
            Logger.getLogger(Spielerliste.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Zieht Karma ab
     *
     * @param ckarma
     * @param cminus
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    public void minusKarma(int ckarma, int cminus) throws ClassNotFoundException, SQLException{
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("FEHLER DATENBANK NICHT GEFUNDEN!");
        }
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon;
        try {
            myCon = DriverManager.getConnection(verbindung, "'root'", "");

            Statement mystm = (Statement) myCon.createStatement();
            this.karma = ckarma;
            karma -= cminus;
            String eingabe = "UPDATE spieler ";
            eingabe += "SET Karma= ";
            eingabe += +karma;

            eingabe += " WHERE ID = ";
            try {
                eingabe += spielerzahlErmitteln();

            } catch (ClassNotFoundException ex) {
                System.out.println("ERROR: Datenbank nicht gefunden!");
            } catch (SQLException ex) {
                System.out.println("ERROR: SQL Fehler: " + ex);
            }

            mystm.executeUpdate(eingabe);
        } catch (SQLException ex) {
            Logger.getLogger(Spielerliste.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Ermittelt die Zahl der Spieler
     *
     * @return Die Spielerzahl
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public int spielerzahlErmitteln() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon = DriverManager.getConnection(verbindung, "'root'", "");
        Statement mystm = (Statement) myCon.createStatement();
        spielerzahlstring = "SELECT COUNT(Name) FROM spieler";
        try {

            ResultSet myRes = mystm.executeQuery(spielerzahlstring);

            while (myRes.next()) {
                //Aus einer Zeile mit getString/getInt/getByte...Daten formatiert auslesen

                spielerzahl = myRes.getInt(1);
            }

        } catch (Exception ex) {
            System.out.println("FEHLER " + ex);
        }

        return spielerzahl;
    }

    // Für die bestenliste
    /**
     * Liest die Namen aus
     *
     * @return Die Namen
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public List bestenlisteName() throws ClassNotFoundException, SQLException {
        List nam = new ArrayList();

        Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon = DriverManager.getConnection(verbindung, "'root'", "");
        Statement mystm = (Statement) myCon.createStatement();

        String abfrage = "Select Name, Karma From spieler ORDER BY karma desc";
        ResultSet myRes = mystm.executeQuery(abfrage);

        int i = 0;
        while (myRes.next()) {
            //Aus einer Zeile mit getString/getInt/getByte...Daten formatiert auslesen

            nam.add(myRes.getString(1));//erster Index ist 1

            i += 1;

        }

        return nam;

    }

    /**
     * Liest das Karma aus
     *
     * @return das Karma
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public List bestenlisteKarma() throws ClassNotFoundException, SQLException {
        List kar = new ArrayList();

        Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon = DriverManager.getConnection(verbindung, "'root'", "");
        Statement mystm = (Statement) myCon.createStatement();

        String abfrage = "Select Name, Karma From spieler ORDER BY karma desc";
        ResultSet myRes = mystm.executeQuery(abfrage);

        int i = 0;
        while (myRes.next()) {
            //Aus einer Zeile mit getString/getInt/getByte...Daten formatiert auslesen

            kar.add(myRes.getInt(2));//erster Index ist 1

            i += 1;

        }

        return kar;

    }

    /**
     * Liest die Daten des Spielers in eine Map
     *
     * @return Die Spielerdaten
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public Map spielerHolen() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon = DriverManager.getConnection(verbindung, "'root'", "");
        Statement mystm = (Statement) myCon.createStatement();

        String abfrage = "Select * From spieler WHERE id=" + spielerzahlErmitteln();
        ResultSet myRes = mystm.executeQuery(abfrage);

        while (myRes.next()) {

            this.id = myRes.getInt(1);//erster Index ist 1
            this.name = myRes.getString(2);
            this.karma = myRes.getInt(3);

            if (myRes.getInt(4) == 0) {
                this.runningbool = false;

            } else {
                this.runningbool = true;
            }

        }
        spieler.put("ID", id);
        spieler.put("Name", name);
        spieler.put("Karma", karma);
        spieler.put("Running", runningbool);

        return spieler;

    }

    /**
     * Gibt die Namen aus
     *
     * @return die Namen
     */
    public String[] getNamen() {
        return namen;
    }

    /**
     * Gibt das Karma aus
     *
     * @return das Karma
     */
    public int[] getKarma() {
        return karmas;
    }

    /**
     * Setzt beim Spieler running auf false
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    public void runningOff() throws ClassNotFoundException, SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("FEHLER DATENBANK NICHT GEFUNDEN!");
        }
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon;
        try {
            myCon = DriverManager.getConnection(verbindung, "'root'", "");

            Statement mystm = (Statement) myCon.createStatement();

            String eingabe = "UPDATE spieler ";
            eingabe += "SET Running= 0";

            eingabe += " WHERE ID = ";
            try {
                eingabe += spielerzahlErmitteln();

            } catch (ClassNotFoundException ex) {
                System.out.println("ERROR: Datenbank nicht gefunden!");
            } catch (SQLException ex) {
                System.out.println("ERROR: SQL Fehler: " + ex);
            }

            mystm.executeUpdate(eingabe);
        } catch (SQLException ex) {
            Logger.getLogger(Spielerliste.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
