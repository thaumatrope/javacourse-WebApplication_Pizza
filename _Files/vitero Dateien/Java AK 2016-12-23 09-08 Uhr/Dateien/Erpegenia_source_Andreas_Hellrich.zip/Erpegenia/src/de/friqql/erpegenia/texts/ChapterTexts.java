/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.texts;

import de.friqql.erpegenia.db.ReadTexts.ReadChapterTexts;
import java.util.Map;

/**
 * Liest die Chaptertexte aus der Datenbank ein und speichert sie in eine
 * hashmap
 *
 * @author Teilnehmer
 */
public class ChapterTexts extends Texts {

    @Override
    public Map getTexts() {
        //Einlesen
        ReadChapterTexts read = new ReadChapterTexts();
        try {
            read.lesen();
        } //Nicht vorhanden
        catch (Exception ex) {
            System.out.println("Error! " + ex);
        }

        //Ablegen
        String[] gelesenes = read.getGelesen();

        //Kapitel
        dict.put("Vor1", gelesenes[0]);
        dict.put("Vor2-1", gelesenes[1]);
        dict.put("Vor2-2", gelesenes[2]);
        dict.put("Vor3", gelesenes[3]);
        dict.put("Chap1", gelesenes[4]);
        dict.put("Chap2", gelesenes[5]);
        dict.put("Chap3", gelesenes[6]);
        dict.put("Chap4", gelesenes[7]);
        dict.put("Chap5", gelesenes[8]);
        dict.put("Chap6", gelesenes[9]);
        dict.put("Chap7", gelesenes[10]);
        dict.put("Chap8", gelesenes[11]);
        dict.put("Chap9", gelesenes[12]);

        //Enden
        dict.put("End1", gelesenes[13]);
        dict.put("End2", gelesenes[14]);
        dict.put("End3", gelesenes[15]);
        return dict;
    }

}
