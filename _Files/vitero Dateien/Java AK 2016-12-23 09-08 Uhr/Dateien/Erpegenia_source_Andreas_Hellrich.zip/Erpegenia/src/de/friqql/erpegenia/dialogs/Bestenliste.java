/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.dialogs;

import de.friqql.erpegenia.db.Spielerliste;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

/**
 * Die bestenliste
 *
 * @author Teilnehmer
 */
public class Bestenliste extends JDialog {

    private Spielerliste sl = new Spielerliste();
    private JTextArea area51 = new JTextArea();
    private JScrollPane sp = new JScrollPane(area51);
    private String high = "";
    private List namen = new ArrayList();
    private List karma;

    /**
     * Konstruktor der Bestenliste
     *
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public Bestenliste() throws ClassNotFoundException, SQLException, IOException{

        this.setResizable(false);

        this.setBackground(Color.decode("#3399FF"));
        sp.setBackground(Color.decode("#3399FF"));
        area51.setBackground(Color.decode("#3399FF"));
        area51.setForeground(Color.WHITE);

        area51.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        try {
            this.namen = sl.bestenlisteName(); //Namen einlesen
            this.karma = sl.bestenlisteKarma(); // Karma einlesen
            int sz;
            sz = sl.spielerzahlErmitteln();

            OutputStream schreiber = new FileOutputStream("simplythebest.txt");

            //Liste in area einfügen und in datei schreiben
            for (int i = 0; i < sz; i++) {
                String moo1 = "Name: " + namen.get(i);
                schreiber.write(moo1.getBytes());
                schreiber.write(System.getProperty("line.separator").getBytes());
                String moo2 = "Karma: " + karma.get(i);
                schreiber.write(moo2.getBytes());
                schreiber.write(System.getProperty("line.separator").getBytes());
                schreiber.write(System.getProperty("line.separator").getBytes());

            }

            high = "";
            InputStream leser = new FileInputStream("simplythebest.txt");
            int gelesen;

            while ((gelesen = leser.read()) != -1) {

                high += (char) gelesen;

                area51.setText(high);

            }
            area51.setEditable(false);

            this.add(sp);

            area51.setCaretPosition(0);
            this.setTitle("Bestenliste");
            this.setSize(300, 600);

            //Wenn was schiefgeht...    
        } catch (ClassNotFoundException ex) {
            System.out.println("Datenbank nicht gefunden " + ex);
        } catch (SQLException ex) {
            System.out.println("SQL Fehler " + ex);
        } catch (IOException ex) {
            Logger.getLogger("Fehler beim Schreiben der Datei! " + ex);
        }

        this.setVisible(true);

    }
}
