/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.story;

import de.friqql.erpegenia.db.Spielerliste;
import de.friqql.erpegenia.dialogs.Bestenliste;
import de.friqql.erpegenia.panels.deco.South;
import de.friqql.erpegenia.panels.deco.North;
import de.friqql.erpegenia.panels.vor.Vor1;
import de.friqql.erpegenia.panels.vor.Vor2;
import java.awt.BorderLayout;
import java.awt.Color;
import static java.awt.Frame.ICONIFIED;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

/**
 * Die Story die implementiert ist... vielleicht gibts ja irgendwann mehr?
 *
 * @author Teilnehmer
 */
public class Story1 extends Story implements MenuListener {

    //Variablen
    private JMenuBar leiste = new JMenuBar();

    private JMenu min = new JMenu("Ⓜ");

    private JMenu beenden = new JMenu("Ⓧ");

    private JMenu bestenliste = new JMenu("Bestenliste");
    private JLabel abstand1 = new JLabel("                                                                          ");
    private JLabel abstand2 = new JLabel("                                                                              ");

    private JLabel versionl = new JLabel(version);
    private Vor1 center1 = new Vor1();
    private Vor2 center2 = new Vor2();
    private North north = new North();
    private South south = new South();

    private Spielerliste sl = new Spielerliste();
    private int pX;
    private int pY;

    //Die Storyfunjktion
    public Story1() {

        //Farben
        versionl.setForeground(Color.ORANGE);
        bestenliste.setForeground(Color.WHITE);
        min.setForeground(Color.ORANGE);
        beenden.setForeground(Color.RED);

        this.setLayout(new BorderLayout());
        this.add(center1, BorderLayout.CENTER);

        this.add(north, BorderLayout.NORTH);
        this.add(south, BorderLayout.SOUTH);
        this.setSize(700, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setUndecorated(true);

        // DRAG
        this.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                // Get x,y and store them
                pX = me.getX();
                pY = me.getY();
            }
        });

        this.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent me) {
                // Set the location
                // get the current location x-co-ordinate and then get
                // the current drag x co-ordinate, add them and subtract most recent
                // mouse pressed x co-ordinate
                // do same for y co-ordinate
                setLocation(getLocation().x + me.getX() - pX, getLocation().y + me.getY() - pY);
            }
        });

        leiste.add(bestenliste);
        leiste.add(abstand1);
        leiste.add(versionl);
        leiste.add(abstand2);
        leiste.add(min);
        leiste.add(beenden);

        beenden.setFont(beenden.getFont().deriveFont(18.0f));
        min.setFont(min.getFont().deriveFont(18.0f));
        beenden.addMenuListener(this);
        min.addMenuListener(this);
        bestenliste.addMenuListener(this);

        this.setJMenuBar(leiste);
        leiste.setBackground(Color.decode("#234567"));

    }

    public void c2() {
        this.remove(center1);
        this.add(center2, BorderLayout.CENTER);
        this.setVisible(true);
    }

    @Override
    public void menuSelected(MenuEvent e) {
        if (e.getSource() == bestenliste) {
            Bestenliste bl;
            try {
                bl = new Bestenliste();
                    bl.setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Story1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Story1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Story1.class.getName()).log(Level.SEVERE, null, ex);
            }
        
         
        }
        if (e.getSource() == beenden) {
            try {
                sl.runningOff();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Story1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Story1.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.exit(0);
        }
        if (e.getSource() == min) {
            setState(ICONIFIED);
        }
    }

    @Override
    public void menuDeselected(MenuEvent e) {

    }

    @Override
    public void menuCanceled(MenuEvent e) {

    }
}
