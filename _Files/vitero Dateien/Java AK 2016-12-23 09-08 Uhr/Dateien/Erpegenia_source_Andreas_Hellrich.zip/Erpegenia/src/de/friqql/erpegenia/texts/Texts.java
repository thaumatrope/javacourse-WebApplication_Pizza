/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.texts;

import java.util.HashMap;
import java.util.Map;
import de.friqql.erpegenia.interfaces.HasTextsMaps;

/**
 * Die Klasse mit der die Texte eingeladen werden. Eigentlich unbenötigt, aber
 * drin, weil Baum.
 *
 * @author Teilnehmer
 */
public class Texts implements HasTextsMaps {

    protected Map dict = new HashMap();

    @Override
    public Map getTexts() {
        return dict;
    }

}
