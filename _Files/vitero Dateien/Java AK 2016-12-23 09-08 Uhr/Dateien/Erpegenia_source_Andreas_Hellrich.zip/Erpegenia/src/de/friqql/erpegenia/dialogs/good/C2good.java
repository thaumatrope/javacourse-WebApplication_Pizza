/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.dialogs.good;

import de.friqql.erpegenia.texts.DialogTexts;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;

/**
 * Spieler war bei Frage 2 lieb.
 *
 * @author Teilnehmer
 */
public class C2good extends JDialog implements ActionListener {

    private DialogTexts dt = new DialogTexts();
    private Map dict = dt.getTexts();
    private JTextArea jTextArea1 = new JTextArea();
    private JDialog me = this;

    /*
   Der Konstruktor der zweiten guten Nachricht
     */
    public C2good(JFrame frame) {
        this.setLayout(new FlowLayout());
        jTextArea1.setText((String) dict.get("Good2"));
        jTextArea1.setDisabledTextColor(Color.decode("#234567"));
        jTextArea1.setEnabled(false);
        jTextArea1.setBackground(Color.decode("#F0F0F0"));

        this.setBackground(Color.BLACK);
        this.add(jTextArea1);
        this.setSize(300, 250);
        this.setTitle("Gut gemacht!");

        JButton close = new JButton();
        close.setSize(100, 50);
        close.setText("Fenster zu!");
        close.addActionListener(this);
        this.add(close);
        this.setLocationRelativeTo(frame);
        this.setModal(true);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        me.setVisible(false);
    }
}
