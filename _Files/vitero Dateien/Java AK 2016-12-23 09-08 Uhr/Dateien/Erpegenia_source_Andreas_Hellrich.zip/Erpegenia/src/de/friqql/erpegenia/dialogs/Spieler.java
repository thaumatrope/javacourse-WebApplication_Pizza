/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.dialogs;

import de.friqql.erpegenia.db.Spielerliste;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.JTextArea;

/**
 * Legt den Spieler an
 *
 * @author Teilnehmer
 */
public class Spieler extends JDialog {

    //Legt die Map für den Spieler an
    private Map dict = new HashMap();

    public Spieler() throws Exception {

        Spielerliste sl = new Spielerliste();

        dict = sl.spielerHolen(); //Füllt das dictionary mit dem Spieler

        //area 51 ... hier gibt es keine Aliens!
        JTextArea area51 = new JTextArea();
        area51.setBackground(Color.decode("#3399FF"));
        area51.setForeground(Color.WHITE);
        area51.append("\nID \n" + dict.get("ID"));
        area51.append("\n\nName \n" + dict.get("Name"));
        area51.append("\n\nKarma  \n" + dict.get("Karma"));
        area51.setEditable(false);

        this.add(area51);
        this.setLocationRelativeTo(null);
        this.setSize(200, 200);
        this.setTitle("Spieler");
        this.setVisible(true);

    }

}
