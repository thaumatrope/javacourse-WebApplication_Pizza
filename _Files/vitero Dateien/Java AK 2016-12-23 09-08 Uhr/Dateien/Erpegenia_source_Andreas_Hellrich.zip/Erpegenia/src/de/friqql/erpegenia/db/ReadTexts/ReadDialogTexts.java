/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.friqql.erpegenia.db.ReadTexts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Teilnehmer
 */
public class ReadDialogTexts {

    private String[] gelesen = new String[999];

    /**
     * einlesen
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public void lesen() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/erpegenia?zeroDateTimeBehavior=convertToNull";
        Connection myCon = DriverManager.getConnection(verbindung, "'root'", "");
        Statement mystm = (Statement) myCon.createStatement();

        String abfrage = "Select * From dialogtexte";
        ResultSet myRes = mystm.executeQuery(abfrage);

        int i = 0;
        while (myRes.next()) {
            //Aus einer Zeile mit getString/getInt/getByte...Daten formatiert auslesen

            int ID = myRes.getInt(1);
            String text = myRes.getString(2);//erster Index ist 1

            gelesen[i] = text;
            i += 1;
        }

    }

    /**
     * Gelesenes zurückgeben
     *
     * @return das gelesene
     */
    public String[] getGelesen() {

        return gelesen;
    }

}
