package calcparser;

/**
 * Created by HOST on 27.11.2016.
 */
public interface Cmd {
    public CalcParser exec(CalcParser calc);
}
