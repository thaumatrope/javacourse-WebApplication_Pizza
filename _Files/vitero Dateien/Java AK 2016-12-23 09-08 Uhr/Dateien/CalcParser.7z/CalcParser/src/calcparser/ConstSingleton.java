package calcparser;
/**
 *
 * @author IBB Teilnehmer
 */
abstract public class ConstSingleton {
    
    private ConstSingleton(){}

    private static Const constInstance = null;

    public static Const getConstInstance(){

        if(constInstance == null){
            constInstance = new Const();
        }

        return constInstance;

    }

}