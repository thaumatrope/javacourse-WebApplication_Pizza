package calcparser;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author IBB Teilnehmer
 */
public class Const implements Cmd, Serializable {

    public Map<String, Double> _const = new HashMap<>();


    // get _const HashMap
    public Map<String, Double> getConstMap() {
        return _const;
    }

    // set _const HashMap
    public void setConstMap(String s, Double d) {
        _const.put(s, d);
    }

    // delete _const HashMap
    public void delete() {

        _const = new HashMap<String, Double>();
    }

    // show _const HashMap
    public void showAll() {
        System.out.println("Konstanten :");
        for(String key : _const.keySet()){
            System.out.println("            =>  " + key + " : " + _const.get(key));
        }
    }


    @Override
    public CalcParser exec(CalcParser calc) {
        if (_const.isEmpty()) {
            System.out.println("Keine Konstanten vorhanden");
        } else {
            showAll();
        }
        return calc;
    }


}
