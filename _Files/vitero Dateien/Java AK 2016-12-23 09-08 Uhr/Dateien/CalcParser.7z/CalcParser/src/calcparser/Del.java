package calcparser;
/**
 *
 * @author IBB Teilnehmer
 */
public class Del implements Cmd{

    @Override
    public CalcParser exec(CalcParser calc) {
        
        
        if(calc.getParts().length > 1){
            if(calc.getPart(1).equals("const")){
                calc.getConstInstance().delete();
                return calc;
            }
        }   
        
        if(!calc.getStack().empty()){ 
            calc.getStack().pop();
        }else {
            System.out.println("Keine Werte im Stack");
        }
        
        return calc;
        
    }
    
    
}
