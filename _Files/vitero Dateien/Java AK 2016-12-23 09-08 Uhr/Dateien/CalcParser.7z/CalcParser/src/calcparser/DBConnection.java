/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calcparser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author IBB Teilnehmer
 */
public class DBConnection {
    
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static final String CONN_STRING = "jdbc:mysql://localhost:3306/calcdb";
    
    private static Connection conn = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
    
    
    public static void main(String... args)throws SQLException{
    
    
        Connection conn = null;
        
        try{
            conn = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
            DBConnection.stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM num");
            
            String SQLString = "";
            rs.last();
            System.out.println(rs.getRow());
            
        } catch (SQLException e){
           System.err.println(e);
        } finally{
           if (conn != null){
               conn.close();
           }
        }
    }
    
}
