package calcparser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Scanner;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author IBB Teilnehmer
 */
public class CalcParser implements Serializable{
    
    /** Eingabe getrennt nach dem Leerzeichen */
    private String[] parts;
    
    /** Neue Stack<Double> */
    private Stack<Double> stack; 

    /** Objekt vom Typ Const */
    private final Const constInstance;
    
    /** Objekt vom Typ Const */
    private static CalcParser calcInstance;
    
    private boolean nullFlag = false;
    
    public void setNullFlag(boolean t){
        this.nullFlag = t;
    }
    
    public boolean getNullFlag(){
        return nullFlag;
    }
    
    public CalcParser(){
        stack = new Stack<Double>();
        constInstance = ConstSingleton.getConstInstance();
    }
    
    
    // Input - Befehl, output - Stack oder Constanten
    public static CalcParser userInput(String input){
        run(input);
        return calcInstance;
    }
    
    
    /** Erstellt ein einziges Objekt Const fur den ganzen Programmablauf */
    public Const getConstInstance() {
        return this.constInstance;
    }

    
    /** Getter-, Setter fur String[] getParts und String part */
    public String getPart(int i) {
        return parts[i];
    }
    public String[] getParts() {
        return parts;
    }
    public void setParts(String[] parts) {
        this.parts = parts;
    }
    
    /** Getter-, Setter Stack<Double> */
    public Stack<Double> getStack() {
        return stack;
    }
    public void setStack(Stack<Double> stack) {
        this.stack = stack;
    }
    
    
    // Connection from GUI
    private static void run(String input){
         
        CalcParser calc = getCalc();
        
        /** User Eingabe splitten */
        String[] parts = input.split(" ");
        calc.setParts(parts);

        /** User Eingabe wird uppercase. Befehl vom Typ String abspeichern. */
        String cmdName = parts[0].toLowerCase();

        /** Map fullen mit key-value Paaren Befehlsname=>Cmd Object */
        Cmd command = CommandFactory.getCommand(cmdName, calc);

        /** Mit dem jeweiligen Objekt uberschriebene exec() methode aufrufen. */
        try{
            calc.setNullFlag(false);
            calc = command.exec(calc);
            calcInstance = calc;
        }catch(Exception e){
           System.out.println("Falsche Eingabe. Bitte uberprufen!!");
        }finally{
           
            try {
                OutputStream os = new FileOutputStream("calcObject.data");
                ObjectOutputStream objSchreiber = new ObjectOutputStream(os);
                objSchreiber.writeObject(calc);

                objSchreiber.flush();

                } catch (FileNotFoundException ex) {
                   System.out.println("Datei nicht zugreifbar");
                } catch (IOException ex) {
                    System.out.println("Strom tut nicht");
                    ex.printStackTrace();
                }   
        } 

    }
    
    
    
    /**
     * main() für Ausgabe in der Konsole
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        CalcParser calc = new CalcParser();
        

        // Neue scanner Instanz erstellen
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNext()) {

            String line = scanner.nextLine();

            // User Eingabe splitten 
            String[] parts = line.split(" ");
            calc.setParts(parts);

            // User Eingabe wird uppercase. Befehl vom Typ String abspeichern. 
            String cmdName = parts[0].toLowerCase();

            // Map fullen mit key-value Paaren Befehlsname=>Cmd Object 
            Cmd command = CommandFactory.getCommand(cmdName, calc);

            // Mit dem jeweiligen Objekt uberschriebene exec() methode aufrufen. 
            try{
                command.exec(calc);
            }catch(Exception e){
               System.out.println("Falsche Eingabe. Bitte uberprufen!!");
            } finally{
           
                try {

                    OutputStream os = new FileOutputStream("calcObject.data");
                    ObjectOutputStream objSchreiber = new ObjectOutputStream(os);
                    objSchreiber.writeObject(calc);

                    objSchreiber.flush();

                } catch (FileNotFoundException ex) {
                    System.out.println("Datei nicht zugreifbar");
                } catch (IOException ex) {
                    System.out.println("Strom tut nicht");
                    ex.printStackTrace();
                }   
            } 

        }
    }
    
    
    
    private static CalcParser getCalc(){
        File calc = new File("calcObject.data");
        if (!calc.exists()){
            return new CalcParser();
        } else{
            CalcParser calcInstance = null;
            try{
                ObjectInputStream objLeser = new ObjectInputStream(new FileInputStream("calcObject.data"));
                    calcInstance = (CalcParser)objLeser.readObject();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(CalcParser.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(CalcParser.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(CalcParser.class.getName()).log(Level.SEVERE, null, ex);
                }  
            return calcInstance;
        }
       
        
    }   
    
    
    
}
