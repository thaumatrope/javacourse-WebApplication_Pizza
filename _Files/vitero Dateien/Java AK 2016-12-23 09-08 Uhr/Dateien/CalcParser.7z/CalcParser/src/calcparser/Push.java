package calcparser;

public class Push implements Cmd{

    @Override
    public CalcParser exec(CalcParser calc){
        
        if(calc.getPart(1).matches("^[a-zA-Z]*$")) {
            // suchen nach der konstanten in der Map
            for(String c : calc.getConstInstance().getConstMap().keySet()){
                if(String.valueOf(calc.getPart(1)).equals(c)){
                    calc.getStack().push(calc.getConstInstance().getConstMap().get(c));
                    return calc;
                }
            }
                
            System.out.println("Konstante " + calc.getPart(1)  + " nicht vorhanden");
        }
          
        System.out.println(calc.getPart(1));  
        calc.getStack().push(Double.valueOf(calc.getPart(1)));
        
        return calc;
    }
}

