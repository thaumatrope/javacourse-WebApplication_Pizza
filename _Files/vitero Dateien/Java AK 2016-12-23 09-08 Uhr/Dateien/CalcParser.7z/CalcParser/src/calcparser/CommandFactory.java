package calcparser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IBB Teilnehmer
 */
public class CommandFactory {
    
    public static Cmd getCommand(String command, CalcParser calc)
  {
    
        switch (command) {
            case "push":
                return new Push();
            case "print":
                return new Print();
            case "add":
                return new Add();
            case "mul":
                return new Mul();
            case "div":
                return new Div();
            case "def":
                return new Def();
            case "del":
                return new Del();
            case "const":
                return calc.getConstInstance();
        }

    return null;
  }
    
}
