package calcparser;
/**
 *
 * @author IBB Teilnehmer
 */
public class Mul implements Cmd {
    
    @Override
    public CalcParser exec(CalcParser calc){
        double val = calc.getStack().pop() * calc.getStack().pop();
        calc.getStack().push(val);
        
        return calc;
    }
    
}
