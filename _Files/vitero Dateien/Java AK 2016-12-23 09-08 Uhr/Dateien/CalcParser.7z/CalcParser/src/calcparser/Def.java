package calcparser;
/**
 *
 * @author IBB Teilnehmer
 */
public class Def implements Cmd{
    
    @Override
     public CalcParser exec(CalcParser calc) {
        
        calc.getConstInstance().setConstMap(calc.getPart(1),Double.valueOf(calc.getPart(2)));
        //System.out.println(calc.getConstInstance());
        
        return calc;
    }
    
    
}