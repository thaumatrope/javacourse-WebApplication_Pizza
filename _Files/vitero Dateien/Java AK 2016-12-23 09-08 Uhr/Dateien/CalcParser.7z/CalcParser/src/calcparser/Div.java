package calcparser;

import java.io.Serializable;

/**
 *
 * @author IBB Teilnehmer
 */
public class Div implements Cmd, Serializable{
    
    @Override
    public CalcParser exec(CalcParser calc){
        
        
        double val;
        double a = calc.getStack().pop();
        double b = calc.getStack().pop();
        
        
        //Devision Durch 0
        if(b == 0.0){
            System.out.println("Division durch 0 nicht moglich");
            calc.setNullFlag(true);
            return calc;
        }else if (a == 0.0){
            calc.getStack().push(a);
            return calc;
        }
        
        // Die gro?ere Zahl kommt an die erste Stelle bei einer Division
        if (b > a){
           val = b/a;
        }else{
           val = a/b;
        }
        
        calc.getStack().push(val); 
        
        return calc;
    
    }
    
}
