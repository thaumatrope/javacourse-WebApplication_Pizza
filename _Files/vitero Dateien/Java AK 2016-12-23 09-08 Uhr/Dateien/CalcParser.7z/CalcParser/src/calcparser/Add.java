package calcparser;

/**
 * Created by HOST on 28.11.2016.
 */
public class Add implements Cmd {

    @Override
    public CalcParser exec(CalcParser calc){
        double val = calc.getStack().pop() + calc.getStack().pop();
        calc.getStack().push(val);
        
        return calc;
    }
}
