package calcparser;

public class Print implements Cmd {

    @Override
    public CalcParser exec(CalcParser calc){
        
        if(calc.getStack().empty()){
            System.out.println("Keine Elemente vorhanden");
        }else {
            System.out.println("Zahlen im Stack :");
                for(Double key : calc.getStack()){
                System.out.println("            =>  " + key);
            }
        } 
        
        return calc;
    }
}
