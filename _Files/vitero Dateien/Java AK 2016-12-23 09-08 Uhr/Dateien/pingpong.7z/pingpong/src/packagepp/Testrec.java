/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packagepp;
import pingpong.* ;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.awt.Color;
import java.awt.Graphics;
import javax.swing.*;

public class Testrec extends JPanel
{
 rectangle fx ;   
/*   int x ;
    int y ;
    int a ;
    int b  ;       
  
  
  
  public  Test ( int x1, int x2, int x3, int x4) {
  super() ;
  x = x1;
  y = x2 ;
  a = x3 ;
  b = x4 ;
  }
 */ 

 public Testrec(rectangle f) {
     super() ;
     fx = f ;
 }
 
 @Override
    
    public void paintComponent ( Graphics  g )
  {

    super.paintComponent( g );
    g.drawLine( fx.getc1(), fx.getc2(), fx.gets1(), fx.gets2() );
    g.setColor(Color.yellow);
  }
}

