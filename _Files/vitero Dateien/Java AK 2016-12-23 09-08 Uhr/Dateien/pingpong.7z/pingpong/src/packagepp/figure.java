/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packagepp;

/**
 *
 * @author Teilnehmer2
 */
public class figure {
    
// coordinate of figure
    
    protected int c1 ;
    
    protected int c2 ;

// spped of figure    
    protected int s1    ;
    
    protected int s2    ;
            
    protected String  color ;
    
     public  figure (int c1 , int c2 , int s1, int s2, String color ) 
    { this.c1 = c1 ;
      this.c2 = c2 ;
      this.s1 = s1 ;
      this.s2 = s2 ;        ;
      this.color = color ;
    }
     
    
    public int getc1 () 
    { return  c1  ; } 
   
    public int getc2 () 
    { return  c2  ; } 
    
    public int gets1 () 
    { return  s1  ; } 
    
    public int gets2 () 
    { return  s2  ; } 
    
    public String getcolor () 
    { return  color  ; }
    
     public void setcoordinate ( int c1n, int c2n ) 
    { c1 = c1n ;
      c2 = c2n ;      
             } 
    
    public void setspeed ( int s1n, int s2n ) 
    { s1 = s1n ;
      s2 = s2n ;      
             } 
  
    // Bewegung der Figur nach einer Zeiteinheit int = 1 wird modelliert
    public void move ( )
 {  
  c1 = c1 + s1 ;
  c2 = c2 + s2 ;
  
 }
 
 // Reflektion der Figur an jeweils vertikaler bzw horizontaler Kante wird beschrieben 
public boolean region ( float p , float q)
{   if  ( c1/c2 <= p/q )  
    
    return true ;
   
    else
    
    return false ;

}      
        

// Die Geschwindigkeitsveränderung nach Reflektion wird beschrieben 
    
 public void reflect (float p , float q)
 {
     if  ( region(p,q) == true )  {
 
         s1 = s1 ;
         s2 = -s2 ;
     }
    else {
 
         s1 = -s1 ;
         s2 = s2 ;     
     }   
 }
 
 }  

