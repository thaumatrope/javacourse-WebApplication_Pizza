/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packagepp;

/**
 *
 * @author Teilnehmer2
 */


/**
 *
 * @author Teilnehmer2
 */


import java.awt.Graphics;
import javax.swing.*;

public class DrawRec extends JPanel {


int x ;
int y ;

int a ;
int b ;

public DrawRec ( int i1, int i2, int i3 , int i4) {

x = i1 ;
y = i2 ;
a = i3 ;
b = i4 ;




}
   public void paintcp (Graphics g  )
  {
    super.paintComponent( g );
    g.drawLine( x, y, a, b );
  }


        
        
}