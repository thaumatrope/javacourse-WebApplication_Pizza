/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packagepp;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Graphics;
import javax.swing.*;
/**
 *
 * @author Ferdinand
 */
public class figd
{
  public static void main( String[] args )
  {
   
     JFrame f = new JFrame();
    f.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    f.setSize( 400, 400 );
    figure f1 = new figure(10,10,100,50,"red") ;
    Test t1 = new Test(f1) ;
    f.add( t1 );
    
    f.setVisible( true );
  }
}