/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pingpong;
import packagepp.* ;
import java.awt.Graphics;
import javax.swing.*;
import java.util.Scanner; 
import java.lang.Math ;

import packagepp.figure;
/**
 *
 * @author Teilnehmer2
 */
public class mainfigure {
    
  int n1 ;
  int n2 ;
  
  int p ;
  int q;
  
  int steps ;
  
  
  
   public static void main (String[] args) 
   {
  
  System.out.println("Please enter number of rectangles and circles") ;
  
    Scanner sc = new Scanner(System.in);
     int  n1 = sc.nextInt();
     int n2 = sc.nextInt() ;
   
     rectangle rects[] = new rectangle[n1] ;
     circle  circles[]  = new circle[n2] ;
  
     
  System.out.println("Please box dimensions p and q") ; 
 
  
     int p = sc.nextInt();
     int q = sc.nextInt() ;
  
    
     System.out.println("Please enter number of steps ") ; 
 
  
     int steps = sc.nextInt();
     
     
     System.out.println("Please enter rectangles:") ; 
  
 
   for ( int i = 0 ; i < n1 ; i++ )
   {  System.out.println("c1 : "  ) ;
      int c1inp ;
      c1inp = sc.nextInt() ;
   System.out.println("c2 : "  ) ;
      int c2inp ;
      c2inp = sc.nextInt() ;
   System.out.println("s1 : "  ) ;
      int s1inp ;
      s1inp = sc.nextInt() ;
   System.out.println("s2 : "  ) ;
      int s2inp ;
      s2inp = sc.nextInt() ;
   System.out.println("a : "  ) ;
      int ainp ;
      ainp = sc.nextInt() ;
   System.out.println("b : "  ) ;
      int binp ;
      binp = sc.nextInt() ;
   System.out.println("color : "  ) ;
      String colorinp ;
      colorinp = sc.next() ;
  
   rects[i]  = new rectangle (c1inp, c2inp,s1inp,s2inp,colorinp,ainp,binp) ;
    
   rects[i].simulation(steps,p,q) ;
   }   
    
   
   
   
   System.out.println("Please enter circles :") ; 
  
    for ( int i = 0 ; i < n2 ; i++ )
   {  System.out.println("c1 : "  ) ;
      int c1inp ;
      c1inp = sc.nextInt() ;
   System.out.println("c2 : "  ) ;
      int c2inp ;
      c2inp = sc.nextInt() ;
   System.out.println("s1 : "  ) ;
      int s1inp ;
      s1inp = sc.nextInt() ;
   System.out.println("s2 : "  ) ;
      int s2inp ;
      s2inp = sc.nextInt() ;
   System.out.println("r : "  ) ;
      int rinp ;
      rinp = sc.nextInt() ;
   
  System.out.println("color : "  ) ;
      String colorinp ;
      colorinp = sc.next() ;
   
      
      circles[i]  = new circle (c1inp, c2inp,s1inp,s2inp,colorinp,rinp) ;
      circles[i].simulation(steps,p,q) ;
   }   
  
    
    /*
    for (int j =1 ; j <= n1; j++ ) 
    {
    for ( int i = 1; i<= steps; i++) 
    {
         float ct1 = rects[j].getc1() ;
     float ct2 = rects[j].getc2() ;
        float st1 = rects[j].gets1() ;
     float st2 = rects[j].gets2() ;
     
     if (  Math.abs(ct1) < p & Math.abs(ct2) < q)    
     
     rects[j].move() ;
     
     else 
     
         rects[j].setcoordinate(ct1-st1,ct2-st2 ) ;
         rects[j].reflect(p,q);
         rects[j].resize(p,q);
    }
       
        
    }
    */    
        
  String figuretype = new String()  ; 
  String rec  = new String("rectangle")  ;
  String circ  = new String ("circle") ;
   System.out.println("Enter type of figure :  : "  ) ;
      figuretype = sc.next() ;
  
      int figurenumber0 ;
   
   System.out.println("Enter number of figure :  : "  ) ;
      
      figurenumber0 = sc.nextInt() ;
   
      int figurenumber = figurenumber0 - 1 ; 
      if ( figuretype.equals(rec)  ) {
     
      System.out.println("Rectangle " + figurenumber0 + " is in state  : "    ) ;
       System.out.println("c1 =  " + rects[figurenumber].getc1()     ) ;
      System.out.println("c2 =  " + rects[figurenumber].getc2()     ) ;
      System.out.println("s1 =  " + rects[figurenumber].gets1()     ) ;
      System.out.println("s2 =  " + rects[figurenumber].gets2()     ) ;
      System.out.println("a =  " + rects[figurenumber].geta()     ) ;
      System.out.println("b =  " + rects[figurenumber].getb()     ) ;
      System.out.println("Color =  " + rects[figurenumber].getcolor()     ) ;
      } 
      
   if ( figuretype.equals(circ)  ) {
     
      System.out.println("Rectangle " + figurenumber0 + " is in state  : "    ) ;
       System.out.println("c1 =  " + circles[figurenumber].getc1()     ) ;
      System.out.println("c2 =  " + circles[figurenumber].getc2()     ) ;
      System.out.println("s1 =  " + circles[figurenumber].gets1()     ) ;
      System.out.println("s2 =  " + circles[figurenumber].gets2()     ) ;
      System.out.println("r =  " + circles[figurenumber].getr()     ) ;
  
      System.out.println("Color =  " + circles[figurenumber].getcolor()     ) ;
      } 
   

    JFrame f = new JFrame();
    f.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    f.setSize( 400, 400 );
    figure f1 = new figure(10,10,100,50,"red") ;
    //Test t1 = new Test(f1) ;
    //f.add( t1 );
    
    f.setVisible( true );
   
   
   Testrec recp [] = new Testrec[n1] ;
   Testcirc recpcic [] = new Testcirc[n1] ;
   
   
   for ( int j = 1 ; j <= steps ; j++)
   {
   
   for (int i = 1 ; i <= n1 ; i++ ) 
   { 
       rects[i].simulation( j, p, q) ; 
       recp[i-1] = new Testrec( rects[i]) ;
       f.add(recp[i-1] );
   
  }
     for (int i = 1 ; i <= n1 ; i++ ) 
   { 
        
       
       f.remove(recp[i-1] );
   }
    for (int i = 1 ; i <= n2 ; i++ ) 
   { 
       circles[i].simulation(j,p,q);
       recpcic[i-1] = new Testcirc( circles[i]) ;
       f.add(recpcic[i-1] );
   
  }
     for (int i = 1 ; i <= n1 ; i++ ) 
   { 
        
       
       f.remove(recpcic[i-1] );
   }
   
   }  
   }
   }