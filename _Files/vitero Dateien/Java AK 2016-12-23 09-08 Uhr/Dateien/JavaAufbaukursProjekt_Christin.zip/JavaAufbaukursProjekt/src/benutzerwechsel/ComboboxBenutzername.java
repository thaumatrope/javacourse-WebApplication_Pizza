/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package benutzerwechsel;

import datenbank.DBVerbindung;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;


/**
 *
 * @author Teilnehmer
 */
public class ComboboxBenutzername extends DefaultComboBoxModel<String>{
     
        private List<String> benutzer;
        private DBVerbindung dbv;
       // private String verbindung = "jdbc:mysql://localhost:3306/projektarbeit_christin?zeroDateTimeBehavior=convertToNull";
        
        public ComboboxBenutzername() {
            dbv = new DBVerbindung();
            benutzer = new ArrayList<>();
            try {
                
                Statement stmt = dbv.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM anmeldung");
                while (rs.next())  {
                    benutzer.add(rs.getString("benutzername"));
                }
                    
            } catch (SQLException ex) {
                Logger.getLogger(BenutzerWechselnDialog.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        
        @Override
        public int getSize() {
            return benutzer.size();
        }

        @Override
        public String getElementAt(int index) {
            return benutzer.get(index);
        }
    }
