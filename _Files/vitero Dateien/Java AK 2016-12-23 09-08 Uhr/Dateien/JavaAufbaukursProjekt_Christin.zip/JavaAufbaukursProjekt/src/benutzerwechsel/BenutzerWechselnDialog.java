/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package benutzerwechsel;

import datenbank.DBVerbindung;
import java.awt.Dialog;
import javax.swing.JDialog;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.*;

/**
 *
 * @author Teilnehmer
 */
public class BenutzerWechselnDialog extends JDialog {

    private static final long serialVersionUID = 1L;
    private DBVerbindung dbv;
    
    public BenutzerWechselnDialog(JFrame parent, String title) {
        super(parent, title, Dialog.ModalityType.APPLICATION_MODAL);
             
        JPanel dialogBenutzerwechseln = new JPanel();
        JPanel panelMitte = new JPanel();

        getContentPane().add(panelMitte, BorderLayout.PAGE_START);
        panelMitte.setLayout(new GridLayout(4, 1));

        //Label für Benutzername
        JLabel labelName = new JLabel("Benutzername eingeben:", JLabel.CENTER);
        panelMitte.add(labelName);

        //Combobox
        JComboBox comboBoxBenutzername = new JComboBox();
        comboBoxBenutzername.setModel(new ComboboxBenutzername());
        panelMitte.add(comboBoxBenutzername);

        //Panel Sueden
        JPanel panelSuedenBenutzerwechsel = new JPanel();

        //Button OK
        JButton buttonOK = new JButton("OK");
        panelSuedenBenutzerwechsel.add(buttonOK);
        buttonOK.addActionListener(new ActionListenerOK());
        getContentPane().add(panelSuedenBenutzerwechsel, BorderLayout.PAGE_END);

        //Button Beenden
        JButton buttonAbbrechen = new JButton("Beenden");
        panelSuedenBenutzerwechsel.add(buttonAbbrechen);
        buttonAbbrechen.addActionListener(new ActionListenerAbbrechen());
        getContentPane().add(panelSuedenBenutzerwechsel, BorderLayout.PAGE_END);

        //Eigenschaften des Dialoges
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.add(dialogBenutzerwechseln);
        this.setSize(400, 300);
        this.setLocationRelativeTo(parent);
        setVisible(true);
    }

    @Override
    public JRootPane createRootPane() {
        JRootPane rootPane = new JRootPane();
        KeyStroke stroke = KeyStroke.getKeyStroke("ESCAPE");
        Action action = new AbstractAction() {

            private static final long serialVersionUID = 1L;

            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("escaping..");
                setVisible(false);
                dispose();
            }
        };
        InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        inputMap.put(stroke, "Beenden");
        rootPane.getActionMap().put("Beenden", action);
        return rootPane;
    }
}
