/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package benutzerwechsel;

import com.sun.glass.ui.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Teilnehmer
 */
public class ActionListenerOK implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("führt vergleich aus");
        
       // BenutzerWechselnDialog.close(1);
        
    }
    
}
