/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package layoutKomponenten;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import wochenzettelErstellen.WochenzettelErstellen;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author Teilnehmer
 */
public class MenuZeileTop extends JFrame implements ActionListener{
    JMenuBar menueZeileTop = new JMenuBar();
    JMenu datei = new JMenu("Datei");
    JMenu hilfe = new JMenu("Hilfe");
    JMenu einstellungen = new JMenu("Einstellungen");
    JMenu wochenzettelMenu = new JMenu("Wochenzettel");
    
    JMenuItem beenden = new JMenuItem("Beenden");
    JMenuItem wochenzettelErstellen = new JMenuItem("Neuer Wochenzettel");
    
    Koerper koerper = new Koerper();
    WochenzettelErstellen wochenzettel = new WochenzettelErstellen();

    public MenuZeileTop(){
        super();
        menuZeileZeichnen();
    }
    
    private void menuZeileZeichnen(){
        menueZeileTop.add(datei);
        menueZeileTop.add(wochenzettelMenu);
        menueZeileTop.add(einstellungen);
        menueZeileTop.add(hilfe);
        
        datei.add(beenden);
        wochenzettelMenu.add(wochenzettelErstellen);
        
        this.setJMenuBar(menueZeileTop);
        this.add(koerper);
        this.setSize(1000, 600);
        this.setTitle("Manager");
        this.setLocationRelativeTo(null);
        
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        
        beenden.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Ereignis: " + e.getSource());
        
        if(e.getSource()==beenden){
            System.out.println("Gedrueckt " + beenden.getActionCommand());
            System.exit(0);
        }
        
        if (e.getSource()== wochenzettelErstellen){
            System.out.println("Gedrueckt " + wochenzettelErstellen.getActionCommand());

        }
    }
}
