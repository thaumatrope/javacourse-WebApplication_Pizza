package layoutKomponenten;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Teilnehmer
 */
public class KoerperSueden extends JPanel{
    
    JLabel copyright = new JLabel("Copyright bei Duke", JLabel.CENTER);

    public KoerperSueden() {
        this.setLayout(new FlowLayout());    
        this.add(copyright);
      
        Font schriftartCopyright  = new Font("Arial", Font.BOLD, 12);
        copyright.setForeground(Color.decode("#0489b1"));
        copyright.setFont(schriftartCopyright);  


    }

}
