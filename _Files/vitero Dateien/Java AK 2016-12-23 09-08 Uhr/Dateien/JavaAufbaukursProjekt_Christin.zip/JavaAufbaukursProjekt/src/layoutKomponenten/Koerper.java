/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package layoutKomponenten;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JPanel;
import wochenzettelErstellen.WochenzettelErstellen;

/**
 *  Sorgt für den Aufbau des Fensters
 * @author Teilnehmer
 */
public class Koerper extends JPanel {
    
    private JPanel kopf = new KoerperNorden();
 //   private JButton links = new JButton("Links");
 //   private JButton rechts = new JButton("Rechts");
    private JPanel mitte = new WochenzettelErstellen();
    private JPanel fusszeile = new KoerperSueden();
    

    public Koerper(){
        zeichneKoerper();
    }
    
/**
 * 
 */
    public void zeichneKoerper(){

        kopf.setBackground(Color.decode("#f1f1f1"));
        
        this.setLayout(new BorderLayout());       
        this.add(kopf, BorderLayout.NORTH);
   //     this.add(links, BorderLayout.WEST);
   //     this.add(rechts, BorderLayout.EAST);
        this.add(fusszeile, BorderLayout.SOUTH);
        this.add(mitte, BorderLayout.CENTER);
    }
}

