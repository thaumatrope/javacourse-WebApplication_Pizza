/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package layoutKomponenten;

import benutzerwechsel.BenutzerWechselnDialog;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * Baut den Koerper des Fensters auf
 * @author Teilnehmer
 */
public class KoerperNorden extends JPanel implements ActionListener{
    
    EmptyBorder paddingPanel = new EmptyBorder(0,10,0,10);
    Font schriftart = new Font("Arial", Font.BOLD, 20);
    
    //Firenanschrift
    private JLabel firmaLabel = new JLabel("<html>Duke Java<p/>"
                                    + "Javagasse 33a</p>"
                                    + "56980 Insel Java</html>");    
    
    //Für Logo
    private JLabel logoLabel = new JLabel("",JLabel.CENTER);

    //Für Benutzerwechsel
    private JPanel benutzerwechselnPanel = new JPanel();
    
   // private List<String> benutzernameStringDB=benutzer.get(index);
    private JLabel angemeldetalsLabel = new JLabel("Sie sind angemeldet als " 
                   + "Duke" , JLabel.RIGHT);

    private JPanel panelButton = new JPanel();
    private JButton iconButton = new JButton();
    private JLabel benutzerWechsel = new JLabel("Benutzer wechseln: ", JLabel.RIGHT);
    
/**
 * Konstruktor für KoerperNorden
 * BorderLayout: Norden = Design
 * Kopfzeile besteht aus Logo, Text und UserAnmeldung
 */
    public KoerperNorden(){
        //benutzerwechselDialog = new BenutzerWechsel(parent, true);
    
        // Setzt das Layout des Panels
        this.setLayout(new BorderLayout()); 
        
        //Text Firmendaten
        firmaLabel.setBorder(paddingPanel);
        firmaLabel.setForeground(Color.decode("#0489b1"));
        firmaLabel.setFont(schriftart);   
        this.add(firmaLabel, BorderLayout.WEST);

        
        // Logo 
        logo();
        logoLabel.setBorder(paddingPanel);
        logoLabel.setOpaque(false);
        this.add(logoLabel, BorderLayout.CENTER);

        //tabelle
        angemeldet();

        this.add(benutzerwechselnPanel, BorderLayout.EAST);
    }
    
    public void logo(){
        
        ImageIcon bild = new ImageIcon("E:\\Java AufbauKurs\\Projektarbeit "
                + "Christin Moeller\\JavaAufbaukursProjekt\\src\\bilder\\"
                + "Java-duke-guitar.png");
        bild.setImage(bild.getImage().getScaledInstance(200,100, 
                Image.SCALE_DEFAULT));
        logoLabel.setIcon(bild);             
        logoLabel.setOpaque(true);              
    }

/**
 * Baut die Tabelle zusammen
 */
    public void angemeldet(){
        
        benutzerwechselnPanel.setBackground(Color.decode("#f1f1f1"));
        benutzerwechselnPanel.setLayout(new BorderLayout());

        
        benutzerwechselnPanel.add(angemeldetalsLabel, BorderLayout.NORTH);
        angemeldetalsLabel.setFont(schriftart);
        angemeldetalsLabel.setForeground(Color.decode("#0489b1"));
        angemeldetalsLabel.setBorder(paddingPanel);
        
        benutzerwechselnPanel.add(benutzerWechsel, BorderLayout.CENTER);
        benutzerWechsel.setBorder(paddingPanel);
        benutzerWechsel.setFont(schriftart);
        benutzerWechsel.setForeground(Color.decode("#0489b1"));   
        
        benutzerwechselnPanel.add(iconButton, BorderLayout.EAST);
        iconButton.setContentAreaFilled(false);
        iconButton.setBorder(paddingPanel);
        ImageIcon bild2 = new ImageIcon("E:\\Java AufbauKurs\\Projektarbeit "
                + "Christin Moeller\\JavaAufbaukursProjekt\\src\\bilder\\"
                + "icon_benutzerwechsel.png");
        iconButton.setIcon(bild2); 
        iconButton.addActionListener(this);
        
        bild2.setDescription("Benutzer wechseln oder abmelden.");
   }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==iconButton){
            System.out.println(iconButton.getActionCommand());
            BenutzerWechselnDialog myDialog = new BenutzerWechselnDialog
                        (new JFrame(), "Dialogfeld" );
        }
    }
}

    