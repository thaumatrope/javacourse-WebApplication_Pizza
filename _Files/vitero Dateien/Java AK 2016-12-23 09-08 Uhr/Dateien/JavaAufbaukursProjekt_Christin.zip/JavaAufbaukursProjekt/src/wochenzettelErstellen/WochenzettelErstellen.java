/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wochenzettelErstellen;

import javax.swing.JPanel;

/**
 *
 * @author Teilnehmer
 */
public class WochenzettelErstellen extends JPanel{
    

    
    public WochenzettelErstellen (){
    }
}
