package datenbank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Teilnehmer
 */
public class DBVerbindung {
    private Connection myCon;
        
    public DBVerbindung() {
 //       Class.forName("com.mysql.jdbc.Driver");
        String verbindung = "jdbc:mysql://localhost:3306/projektarbeit_"
                + "christin?zeroDateTimeBehavior=convertToNull";

        try {
            myCon = DriverManager.getConnection(verbindung, "root", "");
            System.out.println("Verbindung zu DB war erfolgreich");
        } catch (SQLException ex) {
            System.out.println("Verbindung zu DB war nicht erfolgreich!");
        }
    } 
    public Connection getConnection(){
        return myCon;
    }
    
    public void close(){
        try {
            myCon.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBVerbindung.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
