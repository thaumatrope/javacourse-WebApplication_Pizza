/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui_Projekt;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author IBB Teilnehmer
 */
public class Raster extends JPanel implements Runnable {

    private JButton button1 = new JButton();
    private JRadioButton rbutton1 = new JRadioButton("rot");
    private JRadioButton rbutton2 = new JRadioButton("blau");
    private JRadioButton rbutton3 = new JRadioButton("weiss");
    private ButtonGroup rbuttons = new ButtonGroup();
    private JTextField textfield = new JTextField(10);
    private JTextArea textarea = new JTextArea();
    private JTextArea textarea2 = new JTextArea();

    private JPanel hilfspanel1 = new JPanel(new GridLayout(1, 0));
    private String eingabe;
    private static ArrayList<String> ganzeeingabe = new ArrayList();

    public Raster(int i) {
        füllepanelaus();
    }

    public Raster(String a) {
        füllepanel2aus();
    }

    public void füllepanelaus() {
        //Buttongroup wird gefüllt und in dem Hauptpanel hinzugefügt
        rbuttons.add(rbutton1);
        rbuttons.add(rbutton2);
        rbuttons.add(rbutton3);

        // this.add(rbuttons); // funktioniert nicht?
        this.add(rbutton1);
        this.add(rbutton2);
        this.add(rbutton3);
        this.setVisible(false);

        // Die Buttons im Buttongroup werden dann in den Hilfpanel hinzugefügt
        hilfspanel1.add(rbutton1);
        hilfspanel1.add(rbutton2);
        hilfspanel1.add(rbutton3);

        this.add(hilfspanel1);
        this.add(button1);
        button1.setText("Speichern");
        this.add(textarea);
        this.add(textfield);
        textfield.setText("Bitte hier etwas eingeben");

        eventlistener();
    }

    public void füllepanel2aus() {
        this.add(textarea2);

    }

    private void eventlistener() {
//Den Radiobuttons sowie das Button wird ein Event hinzugefügt
        rbutton1.addActionListener((ActionEvent ae) -> {
            System.out.println("rot gedrückt");
            button1.setBackground(Color.red);

        });

        rbutton2.addActionListener((ActionEvent ae) -> {
            System.out.println("blau gedrückt");
            button1.setBackground(Color.blue);

        });

        rbutton3.addActionListener((ActionEvent ae) -> {
            System.out.println("grün gedrückt");
            button1.setBackground(Color.white);

        });

        button1.addActionListener((ActionEvent ae) -> {
            System.out.println("Speicherbutton gedrückt");
            eingabe = textfield.getText();
            textarea.append(eingabe);
            System.out.println(eingabe);
            ganzeeingabe.add(eingabe);
            textfield.setText("");

            // in einer Text datei speichern
            File textspeicher = new File("textspeicher.txt");
            try {
                if (!textspeicher.exists()) {
                    textspeicher.createNewFile();

                }
                BufferedWriter ausgabebuffered = new BufferedWriter(new FileWriter(textspeicher));
                String zeile;

                for (int i = 0; i < ganzeeingabe.size(); i++) {
                    System.out.println(ganzeeingabe.get(i));
                    zeile = ganzeeingabe.get(i);
                    ausgabebuffered.write(zeile);
                }
                ausgabebuffered.flush();
            } catch (FileNotFoundException ex) {
                System.out.println("Text konnte nicht gefunden werden");
            } catch (IOException ex) {
                System.out.println("Text konnte nicht gespeichert werden");
            }

        });

        textfield.addActionListener((ActionEvent ae) -> {
            System.out.println("Textfield angeklickt");
            eingabe = textfield.getText();
            System.out.println(eingabe);
            textarea.append(eingabe + "\n");
            ganzeeingabe.add(eingabe + "\n");
            System.out.println("GanzeText..."+ganzeeingabe.size());
            textfield.setText("");
        });

    }

    public void addLayout(int i) {

        if (i == 1) {
            this.removeAll();
            this.setLayout(new BorderLayout());
            this.add(hilfspanel1, BorderLayout.NORTH);
            this.add(button1, BorderLayout.WEST);
            this.add(textarea, BorderLayout.SOUTH);
            this.add(textfield, BorderLayout.CENTER);
            this.validate();
            this.setVisible(true);
        }
        if (i == 2) {
            this.removeAll();
            this.setLayout(new GridLayout());
            this.validate();
            this.add(textarea2);
            this.setVisible(true);

        }

    }

    public void getganzeeingabe() {
        System.out.println("..."+ganzeeingabe.size());
        for (int i = 0; i < ganzeeingabe.size(); i++) {
            System.out.print(ganzeeingabe.get(i));
            System.out.println("Springt hier nicht rein?");
            textarea2.append(ganzeeingabe.get(i));
            textarea2.setForeground(Color.blue);

        }
    }

    @Override
    public void run() {
        try {
            TimeUnit.SECONDS.sleep(1);
            System.out.println("Timeout");
            textarea2.setForeground(Color.red);
            //textarea2.setText("sddfgdfg"+ganzeeingabe+"abc");
        } catch (InterruptedException ex) {
            Logger.getLogger(Raster.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
