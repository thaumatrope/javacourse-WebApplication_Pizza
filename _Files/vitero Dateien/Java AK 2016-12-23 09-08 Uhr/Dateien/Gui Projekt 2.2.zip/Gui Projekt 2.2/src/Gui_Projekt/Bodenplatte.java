/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui_Projekt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.lang.*;

/**
 *
 * @author IBB Teilnehmer
 */
public class Bodenplatte extends JFrame implements ActionListener {

    JMenuBar leiste = new JMenuBar();
    JMenu eintrag1 = new JMenu("Auswahl");
    JMenuItem item1 = new JMenuItem("Mach die Lichter an");
    JMenuItem item2 = new JMenuItem("Mach die Lichter aus");
    Raster addpanel = new Raster(1);
    Raster addpanel2 = new Raster(2);

    public Bodenplatte() {
        super("Diskofieber");

        fülleframeaus();

    }

    private void fülleframeaus() {

        leiste.add(eintrag1);
        eintrag1.add(item1);
        eintrag1.add(item2);

        item1.addActionListener(this);
        item2.addActionListener(this);

       

        this.setJMenuBar(leiste);
        this.setVisible(true);
        this.setSize(500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // this.setVisible(false); // hier falsch positioniert. Es blendet sonst den ganzen Fenster aus!
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == item1) {
            this.add(addpanel);
            addpanel.addLayout(1);
            System.out.println("Licht an");

        }
        if (ae.getSource() == item2) {
            //this.setVisible(false);
            this.add(addpanel2);
            //setVisible(true);
           
            addpanel2.addLayout(2);
            addpanel2.getganzeeingabe();
            Thread t1 = new Thread(addpanel2);
            t1.start();
            System.out.println("Licht aus");

            
        }
    }
}
