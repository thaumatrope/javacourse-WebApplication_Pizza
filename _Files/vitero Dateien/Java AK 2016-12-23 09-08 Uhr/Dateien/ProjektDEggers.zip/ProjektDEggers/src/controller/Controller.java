/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.DB;
import model.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import view.GUI;
import view.dialogs.SettingsDialog;

/**
 *
 * @author Dorothea Eggers
 */
public class Controller implements ActionListener {

    private DB myDB = new DB();
    private GUI myGUI;
    private Data myData;

    private SettingsDialog settingsDlg;
    private SettingsController settingsCtr;

    public Controller() {
        try {

            //init
            this.myData = new Data();
            this.myGUI = new GUI(this);

            this.settingsCtr = new SettingsController(this);

            //add view to model as Observer
            //Courses    
            for (Course c : this.myData.getCourses().values()) {
                c.addObserver(myGUI);
            }
            //Contacts
            for (Contact c : this.myData.getContacts().values()) {
                c.addObserver(myGUI);
            }
            //Participants
            for (Participant p : this.myData.getParticipants()) {
                p.addObserver(myGUI);
            }

            this.myGUI.setVisible(true);

        } catch (Exception e) {
            System.out.println("Fehler : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(e.getActionCommand());

        switch (e.getActionCommand()) {
            case "connect":

                try {
                    this.myDB.connectDB();

                    //get model data
                    this.myData = myDB.getCourseRegistrationData();

                    //add view to model as Observer
                    //Courses    
                    for (Course c : this.myData.getCourses().values()) {
                        c.addObserver(myGUI);
                    }
                    //Contacts
                    for (Contact c : this.myData.getContacts().values()) {
                        c.addObserver(myGUI);
                    }
                    //Participants
                    for (Participant p : this.myData.getParticipants()) {
                        p.addObserver(myGUI);
                    }
                    this.myGUI.resetTables();
                    this.myGUI.validate();

                } catch (SQLException ex) {
                    System.out.println("Fehler beim Aufbau der Datenbankverbindung: " + ex.getMessage());
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
                break;
            case "disconnect":
                try {
                    this.myDB.disconnectDB();

                    //clear data
                    this.myData = new Data();
                    this.myGUI.resetTables();
                    this.myGUI.validate();

                } catch (SQLException ex) {
                    System.out.println("Fehler beim Trennen der Datenbankverbindung: " + ex.getMessage());
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
                break;

            case "settings":
                //get current settings
                String[] settings = new String[4];

                myDB.readDBSettings();
                settings[0] = myDB.getDriverClass();
                settings[1] = myDB.getDbURL();
                settings[2] = myDB.getUser();
                settings[3] = myDB.getPwd();

                this.settingsDlg = new SettingsDialog(this.myGUI, this, settings);
                this.settingsDlg.setVisible(true);

                break;
            default:
                break;

        }

    }

    //**************************************************************************
    //Getter und Setter
    public Data getData() {
        return this.myData;
    }

    public DB getDB() {
        return this.myDB;
    }

    public SettingsDialog getSettingsDlg() {
        return settingsDlg;
    }

    public SettingsController getSettingsCtr() {
        return settingsCtr;
    }

}
