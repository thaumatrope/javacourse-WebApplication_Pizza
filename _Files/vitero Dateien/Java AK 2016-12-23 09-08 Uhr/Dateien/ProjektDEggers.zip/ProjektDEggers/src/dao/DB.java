/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;//data access objects

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import model.*;

/**
 *
 * @author Dorothea Eggers
 */
public class DB {

    String driverClass, dbURL, user, pwd;
    File dbFile = new File("res/db.txt");

    Connection myCon;
    Statement myStm;

    String courseAll = "SELECT * FROM  courses";
    String contactAll = "SELECT * FROM  contacts";
    String participantAll = "SELECT * FROM  participants";

    public void connectDB() throws SQLException, ClassNotFoundException {

        readDBSettings();
        //Class.forName("com.mysql.jdbc.Driver");
        Class.forName(this.driverClass);
        String con = this.dbURL;//"jdbc:mysql://localhost:3306/course_registration?zeroDateTimeBehavior=convertToNull";

        myCon = DriverManager.getConnection(con, "'" + user + "'", pwd);//DriverManager.getConnection(con, "'root'", "");
        myStm = myCon.createStatement();

    }

    public void disconnectDB() throws SQLException {
        myStm.close();
        myCon.close();

    }

    public Data getCourseRegistrationData() throws Exception {

        Map<String, Course> courses = new HashMap<>();
        Map<Integer, Contact> contacts = new HashMap<>();
        ArrayList<Participant> participants = new ArrayList<>();

        //get courses
        ResultSet myRes = myStm.executeQuery(courseAll);
        while (myRes.next()) {

            String id = myRes.getString(1);
            String title = myRes.getString(2);
            String description = myRes.getString(3);
            String restrictions = myRes.getString(4);
            float cost_member = myRes.getFloat(5);
            float cost_non = myRes.getFloat(6);
            float cost_child = myRes.getFloat(7);
            String subject = myRes.getString(8);

            courses.put(id, new Course(id, title, description, restrictions, cost_member, cost_non, cost_child, subject));

        }

        //get contacts
        myRes = myStm.executeQuery(contactAll);
        while (myRes.next()) {

            int id = myRes.getInt(1);
            String firstname = myRes.getString(2);
            String lastname = myRes.getString(3);
            String tel = myRes.getString(4);
            String email = myRes.getString(5);
            String courseID = myRes.getString(6);

            contacts.put(id, new Contact(id, firstname, lastname, tel, email, courses.get(courseID)));

        }

        //get participants
        myRes = myStm.executeQuery(participantAll);
        while (myRes.next()) {

            String firstname = myRes.getString(1);
            String lastname = myRes.getString(2);
            String typ = myRes.getString(3);
            String courseID = myRes.getString(4);
            int contactID = myRes.getInt(5);
            Date regDate = myRes.getDate(6);
            Date paidDate = myRes.getDate(7);

            participants.add(new Participant(firstname, lastname, typ, courses.get(courseID), contacts.get(contactID), regDate, paidDate));

        }

        myRes.close();

        return new Data(courses, contacts, participants);

    }

    public void readDBSettings() {
        if (dbFile.exists()) {
            BufferedReader in = null;
            try {
                in = new BufferedReader(new FileReader(dbFile));
                String zeile;
                this.driverClass = in.readLine().trim();
                this.dbURL = in.readLine().trim();
                this.user = in.readLine().trim();
                this.pwd = ((zeile = in.readLine()) == null) ? "" : zeile.trim();
            } catch (FileNotFoundException ex) {
                System.out.println(ex.getMessage());
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            } finally {
                try {
                    in.close();
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }

        }

    }

    public void writeDBSettings(String[] settings) {

        try {
            if (!(this.myCon == null || this.myCon.isClosed())) {
                disconnectDB();
            }

            this.driverClass = settings[0];
            this.dbURL = settings[1];
            this.user = settings[2];
            this.pwd = settings[3];

            connectDB();
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        try {
            //overwrite settings
            BufferedWriter out = new BufferedWriter(new FileWriter(dbFile, false));
            out.write(settings[0]);
            out.newLine();
            out.write(settings[1]);
            out.newLine();
            out.write(settings[2]);
            out.newLine();
            out.write(settings[3]);
            out.flush();

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //**************************************************************************
    //Getter
    public boolean trySettings(String[] settings) {

        boolean settingsOK = true;
        try {
            Class.forName(settings[0]);
            String con = settings[1];

            Connection tryCon = DriverManager.getConnection(con, "'" + settings[2] + "'", settings[3]);//DriverManager.getConnection(con, "'root'", "");
        } catch (ClassNotFoundException ex) {
            settingsOK = false;
        } catch (SQLException ex) {
            settingsOK = false;
        }

        return settingsOK;
    }

    public String getDriverClass() {
        return driverClass;
    }

    public void setDriverClass(String driverClass) {
        this.driverClass = driverClass;
    }

    public String getDbURL() {
        return dbURL;
    }

    public void setDbURL(String dbURL) {
        this.dbURL = dbURL;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

}
