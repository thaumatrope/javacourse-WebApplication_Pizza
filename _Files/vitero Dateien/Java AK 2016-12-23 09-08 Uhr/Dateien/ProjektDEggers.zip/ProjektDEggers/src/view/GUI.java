/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.Controller;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Observable;
import java.util.Observer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import model.*;
import view.editors.CourseEditPanel;

/**
 *
 * @author Dorothea Eggers
 */
public class GUI extends JFrame implements Observer {

    private static final long serialVersionUID = 1L;
    final private Controller controller;
    //main menu
    final private JToolBar menu;
    final private JButton connect, disconnect, settings;
    //tabbedpane
    final private JTabbedPane tabbedPane;
    //splitpane
    final private JSplitPane courses, contacts, participants;
    //upper splitpane infoPane: table and toolbar
    final private JScrollPane coursesTablePane, contactsTablePane, participantsTablePane;
    final private JTable coursesTable, contactsTable, participantsTable;
    final private DefaultTableCellRenderer column_right;
    final private JToolBar coursesToolBar, contactsToolBar, participantsToolBar;
    private JButton newButton, editButton, deleteButton;
    private final JPanel coursesInfoPane, contactsInfoPane, participantsInfoPane;   
    //lower splitpane: edit
    final private JScrollPane coursesEditPane, contactsEditPane, participantsEditPane;    
    //icons for buttons and tabs
    ImageIcon connectIcon, disconnectIcon, settingsIcon;
    ImageIcon courseIcon, contactIcon, participantIcon;
    ImageIcon newIcon, editIcon, deleteIcon;

    public GUI(Controller controller) {

        this.controller = controller;
        setTitle("Anmeldungsverwaltung");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setBounds(200, 200, 800, 600);

        //create Icons
        connectIcon = new ImageIcon("res/img/connect.png", "connect");
        disconnectIcon = new ImageIcon("res/img/disconnect.png", "disconnect");
        settingsIcon = new ImageIcon("res/img/cog.png", "settings");

        courseIcon = new ImageIcon("res/img/calendar-blue.png", "courses");
        contactIcon = new ImageIcon("res/img/address-book-blue.png", "contacts");
        participantIcon = new ImageIcon("res/img/user.png", "participants");
        
        newIcon = new ImageIcon("res/img/page_add.png", "new");
        editIcon = new ImageIcon("res/img/page_edit.png", "edit");
        deleteIcon = new ImageIcon("res/img/page_delete.png", "delete");
        
        //menu
        menu = new JToolBar();
        menu.setFloatable(false);
        
        connect = new JButton("Verbindung herstellen", connectIcon);
        connect.setActionCommand("connect");
        connect.setToolTipText("Datenbank verbinden");
        connect.addActionListener(this.controller);
        
        disconnect = new JButton("Verbindung trennen", disconnectIcon);
        disconnect.setActionCommand("disconnect");
        disconnect.setToolTipText("Datenbank trennen");
        disconnect.addActionListener(this.controller);
        
        settings = new JButton("Verbindung einrichten", settingsIcon);
        settings.setActionCommand("settings");
        settings.setToolTipText("Datenbankverbindung einrichten");
        settings.addActionListener(this.controller);
        
        menu.add(connect);
        menu.add(disconnect);
        menu.add(settings);
        menu.validate();
        
        add(menu, BorderLayout.PAGE_START);       

        //**********************************************************************
        //create tabs
        //courses
        tabbedPane = new JTabbedPane();
        column_right = new DefaultTableCellRenderer(); //some columns should be aligned right
        column_right.setHorizontalAlignment(JLabel.RIGHT);
                
        coursesTable = new JTable(new TableModelCourse(controller.getData().getCourses()));
        coursesTable.setAutoCreateRowSorter(true);  
        coursesTablePane = new JScrollPane(coursesTable);
        coursesTablePane.setMinimumSize(new Dimension(100, 200));
        coursesEditPane = new JScrollPane(new CourseEditPanel(controller));
        coursesEditPane.setMinimumSize(new Dimension(100, 200));
        
        coursesToolBar = new JToolBar();
        coursesToolBar.setFloatable(false);
        newButton = new JButton("Neu", newIcon);
        newButton.setActionCommand("new course");
        newButton.setToolTipText("Neu anlegen");
        newButton.addActionListener(this.controller);
        editButton = new JButton("Bearbeiten", editIcon);
        editButton.setActionCommand("edit course");
        editButton.setToolTipText("Veranstaltung bearbeiten");
        editButton.addActionListener(this.controller);
        deleteButton = new JButton("Löschen", deleteIcon);
        deleteButton.setActionCommand("delete course");
        deleteButton.setToolTipText("Veranstaltung löschen");
        deleteButton.addActionListener(this.controller);
        coursesToolBar.add(newButton);
        coursesToolBar.add(editButton);
        coursesToolBar.add(deleteButton);
        coursesToolBar.validate();
        
        coursesInfoPane = new JPanel(new BorderLayout());
        coursesInfoPane.add(coursesTablePane);
        coursesInfoPane.add(coursesToolBar, BorderLayout.PAGE_END);
                
        courses = new JSplitPane(JSplitPane.VERTICAL_SPLIT, coursesInfoPane, coursesEditPane);
        tabbedPane.addTab("Veranstaltungen", courseIcon, courses,
                "Veranstaltungen");

        //contacts
        contactsTable = new JTable(new TableModelContact(controller.getData().getContacts()));
        contactsTable.setAutoCreateRowSorter(true);
        contactsTablePane = new JScrollPane(contactsTable);
        contactsEditPane = new JScrollPane();
        contactsEditPane.setMinimumSize(new Dimension(100, 200));
        
        contactsToolBar = new JToolBar();
        contactsToolBar.setFloatable(false);
        newButton = new JButton("Neu", newIcon);
        newButton.setActionCommand("new contact");
        newButton.setToolTipText("Neu anlegen");
        newButton.addActionListener(this.controller);
        editButton = new JButton("Bearbeiten", editIcon);
        editButton.setActionCommand("edit contact");
        editButton.setToolTipText("Kontaktperson bearbeiten");
        editButton.addActionListener(this.controller);
        deleteButton = new JButton("Löschen", deleteIcon);
        deleteButton.setActionCommand("delete contact");
        deleteButton.setToolTipText("Kontaktperson löschen");
        deleteButton.addActionListener(this.controller);
        contactsToolBar.add(newButton);
        contactsToolBar.add(editButton);
        contactsToolBar.add(deleteButton);
        contactsToolBar.validate();
        
        contactsInfoPane = new JPanel(new BorderLayout());
        contactsInfoPane.add(contactsTablePane);
        contactsInfoPane.add(contactsToolBar, BorderLayout.PAGE_END);
                
        contacts = new JSplitPane(JSplitPane.VERTICAL_SPLIT, contactsInfoPane, contactsEditPane);
        tabbedPane.addTab("Kontaktpersonen", contactIcon, contacts,
                "Kontaktpersonen");

        //participants
        participantsTable = new JTable(new TableModelParticipant(controller.getData().getParticipants()));
        participantsTable.setAutoCreateRowSorter(true);
        participantsTablePane = new JScrollPane(participantsTable);
        participantsEditPane = new JScrollPane();
        participantsEditPane.setMinimumSize(new Dimension(100, 200));
        
        participantsToolBar = new JToolBar();
        participantsToolBar.setFloatable(false);
        newButton = new JButton("Neu", newIcon);
        newButton.setActionCommand("new participant");
        newButton.setToolTipText("Neu anlegen");
        newButton.addActionListener(this.controller);
        editButton = new JButton("Bearbeiten", editIcon);
        editButton.setActionCommand("edit participant");
        editButton.setToolTipText("Teilnehmer bearbeiten");
        editButton.addActionListener(this.controller);
        deleteButton = new JButton("Löschen", deleteIcon);
        deleteButton.setActionCommand("delete participant");
        deleteButton.setToolTipText("Teilnehmer löschen");
        deleteButton.addActionListener(this.controller);
        participantsToolBar.add(newButton);
        participantsToolBar.add(editButton);
        participantsToolBar.add(deleteButton);
        participantsToolBar.validate();
        
        participantsInfoPane = new JPanel(new BorderLayout());
        participantsInfoPane.add(participantsTablePane);
        participantsInfoPane.add(participantsToolBar, BorderLayout.PAGE_END);
        
        participants = new JSplitPane(JSplitPane.VERTICAL_SPLIT, participantsInfoPane, participantsEditPane);
        tabbedPane.addTab("Teilnehmer", participantIcon, participants,
                "Teilnehmer");
        
        add(tabbedPane);
    }

    public void resetTables() {

        coursesTable.setModel(new TableModelCourse(controller.getData().getCourses()));
                        
        coursesTable.getColumnModel().getColumn(4).setCellRenderer(column_right);
        coursesTable.getColumnModel().getColumn(5).setCellRenderer(column_right);
        coursesTable.getColumnModel().getColumn(6).setCellRenderer(column_right);

        contactsTable.setModel(new TableModelContact(controller.getData().getContacts()));
        contactsTable.getColumnModel().getColumn(0).setCellRenderer(column_right);

        participantsTable.setModel(new TableModelParticipant(controller.getData().getParticipants()));
        participantsTable.getColumnModel().getColumn(5).setCellRenderer(column_right);
        participantsTable.getColumnModel().getColumn(6).setCellRenderer(column_right);

    }

    @Override
    public void update(Observable o, Object arg) {
        //Test
        if (o instanceof model.Course) {
            //edit course
            System.out.println(o);
        } else if (o instanceof model.Contact) {
            //edit contact
            System.out.println(o);
        } else if (o instanceof model.Participant) {
            //edit participant
            System.out.println(o);
        } else {
            System.out.println(o.getClass());
        }
    }

}
