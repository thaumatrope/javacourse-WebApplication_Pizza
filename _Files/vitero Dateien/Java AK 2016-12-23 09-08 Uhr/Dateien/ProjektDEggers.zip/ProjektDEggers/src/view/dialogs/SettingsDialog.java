package view.dialogs;

import controller.Controller;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Dorothea Eggers
 */
public class SettingsDialog extends JDialog {

    final private Controller controller;
    final private JLabel driverLabel = new JLabel("Treiberklasse: ");
    final private JLabel urlLabel = new JLabel("Datenbank-URL: ");
    final private JLabel userLabel = new JLabel("Benutzername: ");
    final private JLabel pwdLabel = new JLabel("Passwort: ");

    final private JTextField driverTF = new JTextField(50);
    final private JTextField urlTF = new JTextField(50);
    final private JTextField userTF = new JTextField(50);
    final private JPasswordField pwdTF = new JPasswordField(50);
    
    
    final private JButton saveButton = new JButton("Speichern");
    final private JButton cancelButton = new JButton("Abbrechen");
    
    public SettingsDialog(JFrame parent, Controller controller, String[] settings) {
        super(parent, "Datenbankeinstellungen", true);
        this.controller = controller;

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();

        cs.fill = GridBagConstraints.HORIZONTAL;

        assert !(settings.length == 4) : "Settings vollständig";

        driverTF.setText(settings[0]);
        urlTF.setText(settings[1]);
        userTF.setText(settings[2]);
        pwdTF.setText(settings[3]);

        //driver
        cs.gridx = 0;
        cs.gridy = 0;
        cs.gridwidth = 1;
        panel.add(driverLabel, cs);

        cs.gridx = 1;
        cs.gridy = 0;
        cs.gridwidth = 2;
        panel.add(driverTF, cs);

        //url
        cs.gridx = 0;
        cs.gridy = 1;
        cs.gridwidth = 1;
        panel.add(urlLabel, cs);

        cs.gridx = 1;
        cs.gridy = 1;
        cs.gridwidth = 2;
        panel.add(urlTF, cs);

        //user
        cs.gridx = 0;
        cs.gridy = 2;
        cs.gridwidth = 1;
        panel.add(userLabel, cs);

        cs.gridx = 1;
        cs.gridy = 2;
        cs.gridwidth = 2;
        panel.add(userTF, cs);

        //pwd
        cs.gridx = 0;
        cs.gridy = 3;
        cs.gridwidth = 1;
        panel.add(pwdLabel, cs);

        cs.gridx = 1;
        cs.gridy = 3;
        cs.gridwidth = 2;
        panel.add(pwdTF, cs);

        panel.setBorder(new LineBorder(Color.GRAY));

        saveButton.setActionCommand("save settings");
        saveButton.addActionListener(controller.getSettingsCtr());
        cancelButton.setActionCommand("cancel settings");
        cancelButton.addActionListener(controller.getSettingsCtr());

        JPanel bp = new JPanel();
        bp.add(saveButton);
        bp.add(cancelButton);

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    public String getDriver() {
        return driverTF.getText();
    }

    public String getUrl() {
        return urlTF.getText();
    }

    public String getUser() {
        return userTF.getText();
    }

    public String getPwd() {
        return new String(pwdTF.getPassword());
    }
    
    
    

}
