/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.editors;

import controller.Controller;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.border.LineBorder;

import model.Course;
import view.SpringUtilities;

/**
 *
 * @author Dorothea Eggers
 */
public class CourseEditPanel extends JPanel {

    private JLabel idLB, titleLB, descLB, restLB, cmLB, cnLB, ccLB, subjectLB;

    private JTextField idTF, titleTF, cmTF, cnTF, ccTF, subjectTF;
    private JTextArea descTA, restTA;

    private Controller controller;
    private Course course;

    public CourseEditPanel(Controller controller) {
        //empty
        this.controller = controller;
        setLayout(new BorderLayout());

        //labels
        idLB = new JLabel("ID");
        titleLB = new JLabel("Titel");
        descLB = new JLabel("Beschreibung");
        restLB = new JLabel("Hinweise");
        cmLB = new JLabel("Kosten für Mitglied");
        cnLB = new JLabel("Kosten für Nicht-Mitglied");
        ccLB = new JLabel("Kosten für Kind");
        subjectLB = new JLabel("Betreff");

        //textfields and -areas
        idTF = new JTextField(20);
        titleTF = new JTextField(20);
        subjectTF = new JTextField(20);
        cmTF = new JTextField(20);
        cnTF = new JTextField(20);
        ccTF = new JTextField(20);
        descTA = new JTextArea(8, 20);
        descTA.setBorder(new LineBorder(Color.GRAY));
        restTA = new JTextArea(4, 20);
        restTA.setBorder(new LineBorder(Color.GRAY));

        JPanel left = new JPanel(new SpringLayout());
        left.add(idLB);
        left.add(idTF);
        left.add(titleLB);
        left.add(titleTF);
        left.add(subjectLB);
        left.add(subjectTF);
        left.add(cmLB);
        left.add(cmTF);
        left.add(cnLB);
        left.add(cnTF);
        left.add(ccLB);
        left.add(ccTF);
        
        SpringUtilities.makeGrid(left,
                         6, 2, //rows, cols
                         0, 0, //initialX, initialY
                         5, 5);//xPad, yPad
        

        JPanel right = new JPanel(new SpringLayout());
        right.add(descLB);
        right.add(descTA);
        right.add(restLB);
        right.add(restTA);
        
        SpringUtilities.makeGrid(right,
                         2, 2, //rows, cols
                         0, 0, //initialX, initialY
                         5, 5);//xPad, yPad
        
        add(left, BorderLayout.WEST);
        add(right, BorderLayout.EAST);
        validate();
    }

    public CourseEditPanel(Course course) {
        //empty
        this.course = course;

    }

    //**************************************************************************
    //Getter
    public String getIdTF() {
        return idTF.getText();
    }

    public String getTitleTF() {
        return titleTF.getText();
    }

    public String getDescTA() {
        return descTA.getText();
    }

    public String getRestTA() {
        return restTA.getText();
    }

    public String getCmTF() {
        return cmTF.getText();
    }

    public String getCnTF() {
        return cnTF.getText();
    }

    public String getCcTF() {
        return ccTF.getText();
    }

    public String getSubjectTF() {
        return subjectTF.getText();
    }
    //**************************************************************************
    //Setter
    
    public void setCourse(Course course){
        this.course = course;
        this.idTF.setText(course.getId());
        this.titleTF.setText(course.getTitle());
    this.subjectTF.setText(course.getSubject());
    this.cmTF.setText(String.format("%.2f €", course.getCost_member()));
    this.cnTF.setText(String.format("%.2f €", course.getCost_non()));
    this.ccTF.setText(String.format("%.2f €", course.getCost_child()));
    this.descTA.setText(course.getDescription());
    this.restTA.setText(course.getRestrictions());
    }
}
