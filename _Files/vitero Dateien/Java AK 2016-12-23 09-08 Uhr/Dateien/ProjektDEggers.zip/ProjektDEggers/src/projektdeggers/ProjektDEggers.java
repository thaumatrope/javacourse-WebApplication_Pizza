/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektdeggers;

import controller.Controller;

/**
 *
 * @author Dorothea Eggers
 */
public class ProjektDEggers {

    /**
     * @param args the command line arguments
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws ClassNotFoundException{

        new Controller();
    }
    
}
