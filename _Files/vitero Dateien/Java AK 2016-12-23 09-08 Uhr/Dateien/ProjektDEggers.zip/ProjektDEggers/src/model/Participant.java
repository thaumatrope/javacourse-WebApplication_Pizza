/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import java.util.Observable;

/**
 *
 * @author Dorothea Eggers
 */
public class Participant extends Observable {

    private String firstname;
    private String lastname;
    private String typ;
    private Course course;
    private Contact contact;
    private Date regDate;
    private Date paidDate;

    public Participant(String firstname, String lastname, String typ, Course course, Contact contact, Date regDate, Date paidDate) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.typ = typ;
        this.course = course;
        this.contact = contact;
        this.regDate = regDate;
        this.paidDate = paidDate;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
        setChanged();
        notifyObservers();
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
        setChanged();
        notifyObservers();
    }

      public String getTyp() {
        return typ;
    }

    public void setTyp(String typ) {
        this.typ = typ;
        setChanged();
        notifyObservers();
    }
    
    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
        setChanged();
        notifyObservers();
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
        setChanged();
        notifyObservers();
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
        setChanged();
        notifyObservers();
    }

    public Date getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(Date paidDate) {
        this.paidDate = paidDate;
    }
    
}
