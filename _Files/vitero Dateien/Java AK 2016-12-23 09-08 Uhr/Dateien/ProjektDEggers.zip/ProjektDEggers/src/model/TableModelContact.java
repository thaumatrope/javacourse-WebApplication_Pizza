/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.HashMap;
import java.util.Map;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Dorothea Eggers
 */
public class TableModelContact extends AbstractTableModel{
    Map<Integer, Contact> contacts = new HashMap();
    protected String[] columnNames = { "ID", "Vorname", "Nachname",
                "Telefon", "Email", "Veranstaltung"};
    
    public TableModelContact(Map<Integer, Contact> data){
     this.contacts = data;
    }
    
    @Override
    public int getRowCount() {
       return contacts.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        
        Integer cid = (Integer) contacts.keySet().toArray()[rowIndex];
        Contact ci = contacts.get(cid);
        switch (columnIndex) {
            case 0: 
                return ci.getId();
            case 1:
                return ci.getFirstname();
            case 2:
                return ci.getLastname();
            case 3:
                return ci.getTel();
            case 4:
                return ci.getEmail();
            case 5:
                return ci.getCourse();
           }
           return null;
    }
    
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    
    public void setColumnNames(String keyName, String valueName) {
        String[] names={keyName,valueName};
        columnNames=names;
    }
    
    
}
