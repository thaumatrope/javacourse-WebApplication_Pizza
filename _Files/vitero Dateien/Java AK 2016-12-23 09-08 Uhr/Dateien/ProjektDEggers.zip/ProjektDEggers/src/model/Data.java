/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Dorothea Eggers
 */
public class Data {
        final private Map<String, Course> courses;
        final private Map<Integer, Contact> contacts;
        final private ArrayList<Participant> participants;

    public Data(Map<String, Course> courses, Map<Integer, Contact> contacts, ArrayList<Participant> participants) {
        this.courses = courses;
        this.contacts = contacts;
        this.participants = participants;
    }

    public Data() {
        this.courses = new HashMap<>();
        this.contacts = new HashMap<>();
        this.participants = new ArrayList<>();
    }

    public Map<String, Course> getCourses() {
        return courses;
    }

    public Map<Integer, Contact> getContacts() {
        return contacts;
    }

    public ArrayList<Participant> getParticipants() {
        return participants;
    }

    
}
