/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Dorothea Eggers
 */
public class TableModelParticipant extends AbstractTableModel{

    ArrayList<Participant> participants = new ArrayList();
    protected String[] columnNames = { "Vorname", "Nachname", "Typ",
                "Veranstaltung", "Kontaktperson", "Anmeldedatum", "Zahlungseingagng"};
    
    public TableModelParticipant(ArrayList<Participant> data){
     this.participants = data;
    }
    
    @Override
    public int getRowCount() {
       return participants.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Participant pi = participants.get(rowIndex);
        switch (columnIndex) {
            case 0: 
                return pi.getFirstname();
            case 1:
                return pi.getLastname();
            case 2:
                return pi.getTyp();
            case 3:
                return pi.getCourse();
            case 4:
                return pi.getContact();
            case 5:
                return pi.getRegDate();
            case 6:
                return pi.getPaidDate();    
                
           }
           return null;
    }
    
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    
    public void setColumnNames(String keyName, String valueName) {
        String[] names={keyName,valueName};
        columnNames=names;
    }
    
    
}
