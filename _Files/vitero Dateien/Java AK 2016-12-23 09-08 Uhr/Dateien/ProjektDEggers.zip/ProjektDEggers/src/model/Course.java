/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Observable;

/**
 *
 * @author Dorothea Eggers
 */
public class Course extends Observable {

    private String id;
    private String title;
    private String description;
    private String restrictions;
    private float cost_member;
    private float cost_non;
    private float cost_child;
    private String subject;

    public Course(String id, String title, String description, String restrictions, float cost_member, float cost_non, float cost_child, String subject) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.restrictions = restrictions;
        this.cost_member = cost_member;
        this.cost_non = cost_non;
        this.cost_child = cost_child;
        this.subject = subject;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
        setChanged();
        notifyObservers();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
        setChanged();
        notifyObservers();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
        setChanged();
        notifyObservers();
    }

    public String getRestrictions() {
        return restrictions;
    }

    public void setRestrictions(String restrictions) {
        this.restrictions = restrictions;
        setChanged();
        notifyObservers();
    }

    public float getCost_member() {
        return cost_member;
    }

    public void setCost_member(float cost_member) {
        this.cost_member = cost_member;
        setChanged();
        notifyObservers();
    }

    public float getCost_non() {
        return cost_non;
    }

    public void setCost_non(float cost_non) {
        this.cost_non = cost_non;
        setChanged();
        notifyObservers();
    }

    public float getCost_child() {
        return cost_child;
    }

    public void setCost_child(float cost_child) {
        this.cost_child = cost_child;
        setChanged();
        notifyObservers();
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
        setChanged();
        notifyObservers();
    }

    @Override
    public String toString() {
        return this.id + " " + this.title;
    }

}
