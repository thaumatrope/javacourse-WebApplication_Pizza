/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.HashMap;
import java.util.Map;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Dorothea Eggers
 */
public class TableModelCourse extends AbstractTableModel{
    Map<String, Course> courses = new HashMap();
    protected String[] columnNames = { "ID", "Titel", "Beschreibung",
                "Hinweise", "Kosten Mitglied", "Kosten Nichtmitglied", "Kosten Kind", "Zahlungs-Betreff"};
    
    public TableModelCourse(Map<String, Course> data){
     this.courses = data;
    }
    
    @Override
    public int getRowCount() {
       return courses.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
            
        String cid = (String) courses.keySet().toArray()[rowIndex];
        Course ci = courses.get(cid);
        switch (columnIndex) {
            case 0: 
                return ci.getId();
            case 1:
                return ci.getTitle();
            case 2:
                return ci.getDescription();
            case 3:
                return ci.getRestrictions();
            case 4:
                return String.format("%.2f €", ci.getCost_member());
            case 5:
                return String.format("%.2f €", ci.getCost_non());
            case 6:
                return String.format("%.2f €", ci.getCost_child());
            case 7:
                return ci.getSubject();
           }
           return null;
    }
    
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    
    public void setColumnNames(String keyName, String valueName) {
        String[] names={keyName,valueName};
        columnNames=names;
    }
    
}
