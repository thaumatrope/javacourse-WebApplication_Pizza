-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 08. Dez 2016 um 15:44
-- Server-Version: 10.1.19-MariaDB
-- PHP-Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `course_registration`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contacts`
--

CREATE TABLE `contacts` (
  `ID` int(11) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Tel` text NOT NULL,
  `Email` text NOT NULL,
  `Course_ID` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `contacts`
--

INSERT INTO `contacts` (`ID`, `Firstname`, `Lastname`, `Tel`, `Email`, `Course_ID`) VALUES
(6, 'Test', 'Test', '0123-4567', 'name@abc.de', 'ga0916'),
(7, 'Test', 'Test', '0123-4567', 'name@abc.de', 'sk0117'),
(8, 'A', 'Test', '0123-4567', 'name@abc.de', 'ws1116');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `courses`
--

CREATE TABLE `courses` (
  `ID` tinytext NOT NULL,
  `Title` text NOT NULL,
  `Description` text NOT NULL,
  `Restrictions` text,
  `Cost_Member` float NOT NULL,
  `Cost_Non` float NOT NULL,
  `Cost_Child` float NOT NULL,
  `Subject` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `courses`
--

INSERT INTO `courses` (`ID`, `Title`, `Description`, `Restrictions`, `Cost_Member`, `Cost_Non`, `Cost_Child`, `Subject`) VALUES
('ga0916', 'Ausflug zum Japangarten', 'Am Samstag, den 08.Oktober 2016 findet ein Ausflug zum „Japangarten“ in Mühlen statt.\nUm 15 Uhr treffen wir uns dort. Es erfolgt eine Führung durch den wunderschönen Garten und anschließend sitzen wir bei Kaffee und Kuchen zusammen.', 'Eine Bezahlung am Tag der Fahrt ist leider nicht möglich!', 13, 13, 13, 'Japangarten'),
('sk0117', 'Shinnenkai 2017', 'Das Shinnenkai wird dieses Jahr am x.01. ab 13:00 Uhr stattfinden. Wir treffen uns im Hotel Alexander zu einem japanischen Büffet, für Unterhaltungsprogramm ist ebenfalls gesorgt. Wir freuen uns mit euch das Jahr des Hahn willkommen zu heißen.', 'Die angegebenen Kosten sind nur für Büffet, Getränke müssen extra bezahlt werden.', 20, 20, 10, 'Shinnenkai'),
('ws1116', 'Workshop Stoff und Papier', 'Am 19.11.2016 findet unser Workshop statt: Handarbeit mit Stoff und Papier\r\nOrt: Haus der Jugend, von-Finckh-Straße/ Ecke Alexanderstraße in Oldenburg.\r\nBeginn: 15 Uhr bis ca. 20 Uhr.\r\nAnmeldung: Bitte bis zum 14.11.16 an bei Frau Szyszka', 'Bezahlung der Kursgebühr vor Ort.', 5, 7, 3, 'Workshop');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `participants`
--

CREATE TABLE `participants` (
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Typ` text NOT NULL,
  `Course_ID` tinytext NOT NULL,
  `Contact_ID` int(11) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Paid` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`ID`);

--
-- Indizes für die Tabelle `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`ID`(6));

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `contacts`
--
ALTER TABLE `contacts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
