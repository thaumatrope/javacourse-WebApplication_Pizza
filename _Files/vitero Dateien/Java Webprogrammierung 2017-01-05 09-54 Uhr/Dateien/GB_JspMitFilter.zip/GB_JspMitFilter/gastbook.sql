-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 08. Okt 2015 um 13:19
-- Server Version: 5.5.27
-- PHP-Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `gastbook`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `filterwords`
--

CREATE TABLE IF NOT EXISTS `filterwords` (
  `word` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `filterwords`
--

INSERT INTO `filterwords` (`word`) VALUES
(''),
('saupreuß');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gaestebuch`
--

CREATE TABLE IF NOT EXISTS `gaestebuch` (
  `VORNAME` varchar(50) COLLATE utf8_bin NOT NULL,
  `NACHNAME` varchar(50) COLLATE utf8_bin NOT NULL,
  `EMAIL` varchar(80) COLLATE utf8_bin NOT NULL,
  `WEB` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `AGE` int(11) DEFAULT NULL,
  `REGION` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `KOMMENTAR` mediumtext COLLATE utf8_bin NOT NULL,
  `SESSIONID` varchar(50) COLLATE utf8_bin NOT NULL,
  `INET` varchar(50) COLLATE utf8_bin NOT NULL,
  `DATUM` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Daten für Tabelle `gaestebuch`
--

INSERT INTO `gaestebuch` (`VORNAME`, `NACHNAME`, `EMAIL`, `WEB`, `AGE`, `REGION`, `KOMMENTAR`, `SESSIONID`, `INET`, `DATUM`, `ID`) VALUES
('Hans hermann', 'Meier', 'Uli@hoenes.de', 'Alles wird gut', 34, 'Bayern', 0x416c6c6573207769726420677574, '72905ecc0f019da59ea8e29525d8', '0:0:0:0:0:0:0:1', '2015-10-08 11:15:19', 2),
('Uli', 'Meier', 'Uli@hoenes.de', 'Alles wird gut', 34, 'Bayern', 0x73617570726575c39f, '72905ecc0f019da59ea8e29525d8', '0:0:0:0:0:0:0:1', '2015-10-08 11:16:09', 3),
('Uli', 'Meier', 'Uli@hoenes.de', 'Alles wird gut', 34, 'Bayern', 0x48616c6c6f2057656c74, '72af674bf0120774cf79d04e24cb', '0:0:0:0:0:0:0:1', '2015-10-08 11:16:49', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
