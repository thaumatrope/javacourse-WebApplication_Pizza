/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.Scanner;

/**
 *
 * @author Teilnehmer
 */
public class AdressDaten {

    public void meineDaten(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Gib mir bitte deinen Vornamen: ");
        String vorname = sc.next();
        
        System.out.println("und deinen Nachnamen: ");
        String nachname = sc.next();
        
        System.out.println("deine Straße: ");
        String strasse = sc.next();
        
        System.out.println("mit der Hausnummer: ");
        String hausNr = sc.next();
        
        System.out.println("sowie deine Postleitzahl: ");
        String plz = sc.next();
        
        System.out.println("mit deinem Wohnort: ");
        String ort = sc.next();
        
        System.out.println("Geburtsdatum (TT.MM.YYYY): ");
        String geburtstag = sc.next();

        String meineDaten[] = {vorname, nachname, strasse, hausNr, plz, 
            ort, geburtstag}; 

        System.out.println("Folgende Eingaben wurden getaetigt: ");
        
        for (int i=0; i<7; i++)
        {
            System.out.println(meineDaten[i].getClass()
                + "@"+Integer.toHexString
                  (System.identityHashCode(meineDaten[i])));
        }

        System.out.println("\n*********************************************\n");
        System.out.println("Danke " + meineDaten[0] 
            + " jetzt weiß ich alles ueber dich!!!\n");
        
        System.out.println("Du bist " + meineDaten[0] + " " + meineDaten[1]);
        System.out.print("und du wohnst in/im " + meineDaten[2] 
            + " in " + meineDaten[3]);
        System.out.println("in " + meineDaten[4] + " in "
            + meineDaten[5]);
         System.out.println("du bist am: " + meineDaten[6] + " geboren.");   
    }
}
