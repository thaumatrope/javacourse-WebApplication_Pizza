/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import static java.lang.Math.sqrt;


/**
 *
 * @author Teilnehmer
 */

public class PyramideBerechnung implements KoerperEigenschaften{

/**
 *  Methode zum berechnen der Pyramide
 */
    @Override
    public void berechneKoerper() {
        //super(h,b,t);
        //Referenz & neues Objekt
        HoleWerte werte = new HoleWerte();
        //Aufruf der Methode
        werte.liesWerteEin();

    //Berechnung Flächeninhalte der Rechtecke
        double h=werte.getHoehe();
        double b=werte.getBreite();
        double t=werte.getTiefe();
        double hb;
        double ht;
    
        double rechteck=b*t;
      
        System.out.println("Die Flächeninhalte der rechteckigen "
                + "Grundfläche Gf = b * t = " + rechteck + " qcm.\n");

        // Seitenflächenhöhen
        hb = sqrt ((h*h) + (t/2) * (t/2));
        ht = sqrt ((h*h) + (b/2) * (t/2));

        System.out.println("Die Seitenflächenhöhen betragen \nhb: " + hb 
                + " qcm.");
        System.out.println("ht: " + ht + " qcm.\n");
        
        double mantel = b*hb+t*ht;
        System.out.println("Der Mantel (b * hb + t * ht) beträgt: " 
                + mantel + " qcm.");
        
        //Oberflächenberechnung
        System.out.println("Die Gesamtoberfläche der Pyramide (Ao) = Rechteck "
                + "+ Mantel = " + (rechteck + mantel) + " qcm.");
        
        //Volumen
        System.out.println("\nDas Volumen V der Pyrmaide = "
                + "Grundfläche*Höhe/3 und beträgt: " 
                + rechteck * h /3 + " ccm");
    }
}
