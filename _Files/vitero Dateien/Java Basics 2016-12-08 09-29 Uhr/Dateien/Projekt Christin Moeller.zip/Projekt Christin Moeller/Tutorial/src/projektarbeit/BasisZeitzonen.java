/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.Calendar;
import java.util.TimeZone;

/**
 *
 * @author Teilnehmer
 */
public class BasisZeitzonen {
 /**
 * Gibt Zeit von der Methode getZeitVomTagFuerZone
 * @return  akteulle Zeit vom Tag für die Standart UTC-Zone
 */
    public String getZeitVomTag(){
        System.out.println("Die Standartuhrzeit UTC = ");
        return getZeitVomTagFuerZone(TimeZone.getTimeZone("UTC"));  
    }
    
/**
 * Gibt die Zeit in Millisekunden aus
 * @return Millisekunden
 */
    protected static long getZeitInMs(){
        return System.currentTimeMillis();
    }
  
/**
 * @param  timeZone Zeitzonen 
 * @return Stunden:Minuten:Sekunden und aktuelles Datum
 */
    protected static String getZeitVomTagFuerZone(TimeZone timeZone){
        Calendar now = Calendar.getInstance(timeZone);
        
        String stunde = "0" + now.get(Calendar.HOUR_OF_DAY);
        String minute = "0" + now.get(Calendar.MINUTE);
        String sekunde = "0" + now.get(Calendar.SECOND);
        String tag = "0" + now.get(Calendar.DATE);
        String monat = "" + now.get(Calendar.MONTH);
        String jahr = "" + now.get(Calendar.YEAR);
        
        return  stunde.substring(stunde.length()-2)
              + ":" + minute.substring(minute.length()-2)
              + ":" + sekunde.substring(sekunde.length()-2)
              + "\nDatum: " + tag
              + "." + monat
              + "." + jahr;
    }
}
