/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.Scanner;

/**
 *  Objekt Waehrungsumrechnung 
 */
public class Waehrungsumrechnung {

/** 
 *  Methode zur Umrechnung der Waehrungen
 */    
    public void Umrechnung(){

    double euroDollar = 1.0633;
    double euroYen = 121.5616;
    double euroPeso = 22.0838;
    
    double dollarEuro = 0.9390;
    double dollarYen = 114.0901;
    double dollarPeso = 20.7468;
    
    double pesoEuro = 0.0451;
    double pesoDollar = 0.0482;
    double pesoYen = 5.4883;
    
    System.out.println("Du kannst zwischen euro, dollar, yen und "
            + "peso wählen.\n");
 
    System.out.println("Gib die ursprüngliche Währung ein:" ); 
    Scanner gg = new Scanner(System.in);
    String eingabe = gg.next();     
    System.out.println("Du hast: " + eingabe + " gewählt!\n" );
    
    System.out.println("Gib die gesuchte Währung ein:");
    Scanner gs = new Scanner(System.in);
    String eingabeGesucht = gs.next();
    System.out.println("Du hast " + eingabeGesucht + " gewählt!\n");
    
    System.out.println("Gib den Geldbetrag ein, welcher umgerechnet "
        + "werden soll:");
    Scanner wert=new Scanner(System.in);
    double w;
    w = wert.nextDouble();
   
    switch (eingabe) {
        case "euro":
            if ("dollar".equals(eingabeGesucht)){
                System.out.println(w + " € entsprechen " + 
                        (w * euroDollar) + " Dollar zum Kurs von 1:" 
                        + euroDollar + " Dollar.");
            }  else if ("yen".equals(eingabeGesucht)){
                System.out.println(w + " € entsprechen " + 
                        (w * euroYen) + " Yen zum Kurs von 1:" 
                        + euroYen + " Yen.");
            }  else if ("peso".equals(eingabeGesucht)){
                System.out.println(w + " € entsprechen " + 
                (w * euroPeso) + " Peso zum Kurs von 1:" 
                        + euroPeso + " Peso.");
            }  else {
                System.out.println("Die gesuchte Währung ist falsch!");
            }
        break;
        
        case "dollar":
            if ("euro".equals(eingabeGesucht)){
                System.out.println(w + " $ entsprechen " + 
                        (w * dollarEuro) + " € zum Kurs von 1:" 
                        + dollarEuro + " €.");
            }  else if ("yen".equals(eingabeGesucht)){
                System.out.println(w + " $ entsprechen " + 
                        (w * dollarYen) + " Yen zum Kurs von 1:" 
                        + dollarYen + " Yen.");
            }  else if ("peso".equals(eingabeGesucht)){
                System.out.println(w + " $ entsprechen " + 
                (w * dollarPeso) + " Peso zum Kurs von 1:" 
                        + euroPeso + " Peso.");
            }  else {
                System.out.println("Die gesuchte Währung ist falsch!");
            }  
            break;
            
        case "peso":
            if ("euro".equals(eingabeGesucht)){
                System.out.println(w + " Peso entsprechen"
                        + (w * pesoEuro) + "Euro zum Kurs von 1:"
                        + pesoEuro + " Peso." );
            } else if ("dollar".equals(eingabeGesucht)){
                System.out.println(w + " $ entsprechen " 
                        + (w * pesoDollar) + " Yen zum Kurs von 1:" 
                        + pesoDollar + " Yen.");
            } else if ("yen".equals(eingabeGesucht)){
                System.out.println(w + " $ entsprechen " + 
                (w * pesoYen) + " Peso zum Kurs von 1:" 
                        + pesoYen + " Peso.");
            }  else {
                System.out.println("Die gesuchte Währung ist falsch!");
            } 
        break;

        default:
            System.out.println("Die Eingabe ist ungültig!");
        break;
        }
    }
}
