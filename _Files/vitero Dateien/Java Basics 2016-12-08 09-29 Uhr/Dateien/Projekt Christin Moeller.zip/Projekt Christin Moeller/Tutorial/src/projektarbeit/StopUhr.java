/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.TimeZone;

/**
 *
 * @author Teilnehmer
 */
public class StopUhr extends LokaleUhrzeit{
    long startTimer;
    long stopTimer;
    
/**
 * 
 * @param tz  mit gleichen Parametern aus Zeitzonen, ruft super auf
 */ 

    public StopUhr(TimeZone tz) {
        super(tz);
    }
 
/**
 *  startTimer bekommt die getZeitInMS zugewiesen
 */
    public void start(){
        startTimer = getZeitInMs();
    }
    
/**
 * StopTimer bekommt die Differenz zwischen getZeitInMs und startTimer 
 * zugewiesen
 * bekommt somit die gestoppte Zeit überliefert
 */
    public void stop (){
        stopTimer = getZeitInMs() - startTimer;
    }
 
/**
 * Liefert die gestoppte Zeit des Timers zurück
 * @return stopTimer
 */
    public long getStoppedTime() {
        return stopTimer;
    }
    
/**
 * Umrechnung von Millisekunden in Sekunden
 * @return liefert die gestoppte Zeit in Sekunden zurück
 */
    public double getStopuhInSekunden(){
        return (stopTimer * (0.001));
    }
}
