/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.TimeZone;

/**
 *
 * @author Teilnehmer
 */
public class LokaleUhrzeit extends BasisZeitzonen{
        
    TimeZone timeZone;
    
    //Konstruktor für Zeitzone
    
    public LokaleUhrzeit (){
    
    }
    
    public LokaleUhrzeit(TimeZone tz){
        this.timeZone = tz;
    }
    
 /**
 * Gibt Zeit der lokalen Uhrzeit zurück
 * @return Liefert aktuelle lokale Uhrzeit zurück
 */
    @Override
    public String getZeitVomTag(){
        return getZeitVomTagFuerZone(timeZone);     
    }
    public String getUniversalTimeOfDAy(){
        return super.getZeitVomTag();
    }
    
}
