/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.Scanner;
import java.util.TimeZone;

/**
 *
 * @author Teilnehmer
 */
public class ZeitzonenStopuhr {

/**
 * Ruft die unterschiedlichen Zeitzonen auf und die Stopuhr-Methoden
 */
    public void zeitzonenStopuhr(){
   
        BasisZeitzonen basisUhrzeit = new BasisZeitzonen();
        System.out.print(basisUhrzeit.getZeitVomTag()+ "\n");
       
        LokaleUhrzeit lokaleUhrzeit = 
                new LokaleUhrzeit(TimeZone.getTimeZone("CET"));
        System.out.println("\nDie lokale Uhrzeit ist: " 
                + lokaleUhrzeit.getZeitVomTag()+ "\n");
        
        System.out.println("*************************************************");
        
        StopUhr stopUhr = new StopUhr(TimeZone.getDefault());        
        System.out.println("\nStopuhr mit a-Taste starten: ");
        
        System.out.println("Mit a-Taste starten");
        
        Scanner sc = new Scanner(System.in);
        String eingabe = sc.next();
        
        //Beenden geht dann auch durch andere Tastatureneingaben
        //If-Abfrage

        do {
            System.out.println("Mit e-Taste beenden");
            //System.out.println(eingabe.equals("e"));
            stopUhr.stop();
            eingabe = sc.next();
 //           System.out.println(stopUhr.getStoppedTime());
        }
        while (!eingabe.equals("e"));
        stopUhr.start();

        System.out.println("\nDie gestopppte Zeit beträgt: " 
                +  stopUhr.getStoppedTime() + " ms"); 
        
        System.out.format("in Sekunden: %.4f in s.%n", 
                (stopUhr.getStopuhInSekunden()) );
    }
}
