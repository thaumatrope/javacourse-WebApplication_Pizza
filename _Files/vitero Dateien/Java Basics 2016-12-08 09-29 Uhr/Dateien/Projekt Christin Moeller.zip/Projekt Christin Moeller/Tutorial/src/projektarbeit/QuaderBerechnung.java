/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

/**
 *  Obejkt zum berechnen der Flächeninhalte eines Qauders
 */
public class QuaderBerechnung implements KoerperEigenschaften{

/**
 *  Methode zum berechnen des Quaders
 */
    @Override
    public void berechneKoerper() {
        //super(h,b,t);
        //Referenz & neues Objekt
        HoleWerte werte = new HoleWerte();
        //Aufruf der Methode
        werte.liesWerteEin();

    //Berechnung Flächeninhalte der Rechtecke
        double h=werte.getHoehe();
        double b=werte.getBreite();
        double t=werte.getTiefe();
    
        double a1=h*t;
        double a2=b*t;
        double a3=h*b;
        System.out.println("Die Flächeninhalte der einzelnen Rechtecke "
                + "betragen");
        System.out.println("- für A1= " + a1 + " qcm.");
        System.out.println("- für A2= " + a2 + " qcm.");
        System.out.println("- für A3= " + a3 + " qcm\n");
        System.out.println("Die Gesamtoberfläche (Ao) beträgt: " 
                + 2*(a1+a2+a3) + " qcm.\n");
        System.out.println("Das Volumen des Quaders beträgt: " + h*t*b + "ccm");
        System.out.println(" 	\n" +
"\n" +
"._____T_____,\n" +
"|`          :\\\n" +
"| `         : B\n" +
"|  `        :  \\\n" +
"H   +-----T-----+\n" +
"|   :       :   :\n" +
"|__ : _T____:   :\n" +
"`   :        \\  :\n" +
" `  :         B :\n" +
"  ` :          \\:\n" +
"   `:_____T_____>\n\n");
    }
}

