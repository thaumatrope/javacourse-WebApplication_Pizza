/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projektarbeit;

import java.util.Scanner;

public class HoleWerte {
    /**
     *
     * @param h ist die Höhe des Körper
     * @param b ist die Breite des Körpers
     * @param t ist die Tiefe des Körpers
     * 
     */
    private double h;
    private double b;
    private double t;

/**
 *  Methode zum einlesen der Werte ueber Nutzerinterkation
 */
    public void liesWerteEin(){
    
    //  Einlesen der Variablen zur Berechnung des Quaders       
        System.out.println("Es wird das Programm zur Berechnung des "
                + "Körpers gestartet!\n");
    
    // Breite
        System.out.println("Gib die Breite des Körpers in cm ein: ");
        Scanner eingabeBreite = new Scanner(System.in);
        this.b = eingabeBreite.nextDouble(); 

    // Tiefe
        System.out.println("Gib die Tiefe des Körpers in cm ein: ");
        Scanner eingabeTiefe = new Scanner(System.in);
        t = eingabeTiefe.nextDouble();        
    
    // Hoehe
        System.out.println("Gib die Höhe des Körpers in cm ein: ");
        Scanner eingabeHoehe = new Scanner(System.in);
        this.h = eingabeHoehe.nextDouble();
        
        System.out.println("\nDer Körper ist " + h + "cm hoch "
                + b + "cm hoch und "
                + t + "cm tief.\n"
                + "\n********************************************************"
                        + "******************\n"); 
    }  

/**
 * Methode gibt die Höhe zur Berechnung zurück
 * @return h
 */
    public double getHoehe (){
        return h;
    }
 
/**
 * Methode gibt die Breite zurück
 * @return b
 */
    public double getBreite(){
        return b;
    }

/**
 * Methode gibt die Tiefe zurück
 * @return t
 */
    public double getTiefe(){
        return t;
    }
}
