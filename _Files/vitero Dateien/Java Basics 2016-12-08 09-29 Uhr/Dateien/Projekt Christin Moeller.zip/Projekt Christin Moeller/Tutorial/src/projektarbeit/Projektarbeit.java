
package projektarbeit;

import java.util.Scanner;
/**
 *
 * @author Teilnehmer
 */

public class Projektarbeit {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
 
        System.out.println("Folgende Programme können ausgeführt werden: \n");
        System.out.println("1 - Umrechnung der Währungen mit 'geld'.");
        System.out.println("2 - Berechnung eines Quaders mit 'quader'.");
        System.out.println("3 - Berechnung einer Pyramide mit 'pyramiden'.");
        System.out.println("4 - Ueberpruefung deines Namens mit 'name'.");
        System.out.println("5 - Stopuhr mit 'uhr'.\n");
        System.out.println("Bitte gib das Schlüsselwort ein: ");
    
        Scanner sc = new Scanner(System.in);
        String eingabe = sc.next();   
        
        System.out.println("Du hast: " + eingabe + " gewählt!\n" );
 
        switch (eingabe) {
            case "geld":
/**
 *          Währungsumrechnung
 */
            // Währungsumrechner
            //Referenz & neues Objekt
            Waehrungsumrechnung waehrung = new Waehrungsumrechnung();
            //Aufruf der Methode
            waehrung.Umrechnung();
            break;

            case "quader":
/**
 *          Aufruf der Berechnung eines Qauders für den:
 */
            QuaderBerechnung quader = new QuaderBerechnung();
            quader.berechneKoerper();
                
            break;
            
            case "pyramide":
/**
 *          Aufruf der Berechnung eines Pyramide für den:
 */
            PyramideBerechnung pyramide = new PyramideBerechnung();
            pyramide.berechneKoerper();

            break;
            
            case "name":
                AdressDaten persoenlicheDaten = new AdressDaten();
                persoenlicheDaten.meineDaten();
            break;
            
            case "uhr":
                ZeitzonenStopuhr timer = new ZeitzonenStopuhr();
                timer.zeitzonenStopuhr();
            break;
            
        default:
            System.out.println("Die Stopuhr wurde beendet!");
            break;
        }         
    }
}
