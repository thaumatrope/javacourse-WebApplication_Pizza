/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

/**
 *
 * @author IBB Teilnehmer
 */
public class ExceptionFileDuplicate extends Exception {
    
//    public ExceptionFileDuplicate() {
//        super();
//    }

    public ExceptionFileDuplicate (String message) {
        super(message);
    }
}
