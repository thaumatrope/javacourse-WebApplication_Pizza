/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

import java.util.ArrayList;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author Robert
 */
public class GameWorld {

    Player player;
    ArrayList<WallObject> walls;

    public GameWorld() {
        player = new Player(new Position(10, 100));
        walls = new ArrayList<WallObject>();
        WallObject w = new WallObject(new Position(0, 0));
        walls.add(w);
        walls.add(new WallObject(32, 0));
        walls.add(new WallObject(64, 0));
        walls.add(new WallObject(96, 0));
    }

    public void DrawOnCanvas(GraphicsContext gc) {
        player.position.y--;
        if (player.position.y <= 0) {
            player.position.y = 150;
        }

        // draw map objects
        // draw map cells
        for (WallObject w : walls) {
            w.DrawOnCanvas(gc.getCanvas());
        }
        
        // draw player
        player.DrawOnCanvas(gc.getCanvas());

        gc.setFill(Color.BLACK);
        if (player.OverlapsWith(walls.get(0))) {
            gc.fillText("overlap", 0, 50);
        } else {
            gc.fillText("ok", player.position.x + 16, player.position.y + 25 + 16);
        }
    }
}
