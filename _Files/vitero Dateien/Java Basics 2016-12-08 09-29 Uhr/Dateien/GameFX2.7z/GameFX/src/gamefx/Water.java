/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

import java.awt.Point;
import javafx.scene.paint.Color;

/**
 *
 * @author IBB Teilnehmer
 */
public class Water extends MapCell {

    /**
     * Constructor: setup token and color.
     */
    public Water() {
        this.token = 'w';
        this.color = Color.BLUE;
        image = GameFX.gameLoop.imageHandler.GetImageFromFile("water.png");
    }
}
