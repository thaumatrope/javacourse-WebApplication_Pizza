/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;

/**
 *
 * @author IBB Teilnehmer
 */
class Player extends MapObject {

    // text field for name
    String name = "PLAYER";
    MapHandler currentMap = null;

    Textfield nameField = null;

    // constructor: store position
    Player(Position position) {

        // execute parent constructor
        super(position);

        // set a specific color
        color = Color.VIOLET;

        // load FX image from filesystem
        //image = new Image("file:player.png", true);
        image = GameFX.gameLoop.imageHandler.GetImageFromFile("player.png");

        nameField = new Textfield(name, position.x, position.y+40);
    }

    @Override
    public void DrawOnCanvas(Canvas canvas) {

        // draw player
        super.DrawOnCanvas(canvas);

        // draw name
        nameField.position.x = this.position.x;
        nameField.position.y = this.position.y+40;
        nameField.DrawOnCanvas(canvas);
        //GraphicsContext gc = canvas.getGraphicsContext2D();
        //gc.fillText(name, position.x, position.y+40);
    }

    /**
     * Attach player to a game map.
     *
     * @param map
     */
    void SetCurrentMap(MapHandler map) {
        currentMap = map;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * try to move player, return whether successful
     *
     * @return true = moved, false = movement impossible
     */
    public boolean MoveLeft() {
        if (currentMap == null) {
            return false;
        }

        // ask map if move is possible
        Position nextPos = getMapPosition();
        nextPos.x--;
        if (currentMap.IsEmpty(nextPos)) {
            position.x--;
            return true;
        } else {
            return false;
        }
    }

    /**
     * try to move player, return whether successful
     *
     * @return true = moved, false = movement impossible
     */
    public boolean MoveRight() {
        Position nextPos = getMapPosition();
        nextPos.x++;
        if (currentMap.IsEmpty(nextPos)) {
            position.x++;
            return true;
        } else {
            return false;
        }
    }

    /**
     * try to move player, return whether successful
     *
     * @return true = moved, false = movement impossible
     */
    public boolean MoveUp() {
        Position nextPos = getMapPosition();
        nextPos.y--;
        if (currentMap.IsEmpty(nextPos)) {
            position.y--;
            return true;
        } else {
            return false;
        }
    }

    /**
     * try to move player, return whether successful
     *
     * @return true = moved, false = movement impossible
     */
    public boolean MoveDown() {
        Position nextPos = getMapPosition();
        nextPos.y++;
        if (currentMap.IsEmpty(nextPos)) {
            position.y++;
            return true;
        } else {
            return false;
        }
    }

}
