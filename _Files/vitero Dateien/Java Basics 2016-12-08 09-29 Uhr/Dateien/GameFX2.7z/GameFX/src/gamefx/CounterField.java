/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

/**
 * CounterFields are textfields with numeric values. And can draw themselves on
 * the canvas.
 *
 * @author IBB Teilnehmer
 */
public class CounterField extends Textfield {

    // current value of the counter
    int value;

    // Name of the counter; if not empty this is shown as prefix.
    String name;

    /**
     * Create with value and position.
     *
     * @param value
     * @param x
     * @param y
     */
    public CounterField(String name, int value, int x, int y) {
        super(name, x, y);
        this.value = value;
        this.name = name;
        this.textsize = 12;
        UpdateText();
    }

    // update text field part
    public void UpdateText() {
        this.text = name + ": " + value;
    }

    // increase score by certain amount 
    public void Increase(int amount) {
        value += amount;
        UpdateText();
    }

    // decrease score by certain amount
    void Decrease(int amount) {
        value -= amount;
        UpdateText();
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // reset score to zero
    public void Reset() {
        value = 0;
        UpdateText();
    }
}
