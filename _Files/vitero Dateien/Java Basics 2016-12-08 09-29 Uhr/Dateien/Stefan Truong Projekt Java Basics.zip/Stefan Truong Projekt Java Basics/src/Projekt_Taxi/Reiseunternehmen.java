/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projekt_Taxi;

import java.util.Scanner;
/**
 * @author Stefan Truong
 * Ort Stuttgart
 * Projekt: Java Basics
 * 
 * gebe zuerst einen Namen an/Kann auch Roboter sein
 * Evtl. Gehalt
 * dann einen gültigen Zielort
 */
public class Reiseunternehmen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        String leerzeichen="";
        String robot="Roboter";
        Fahrer driver; 

        
        System.out.println("Bitte gebe den Namen des Fahrers an");
        String eingelesen=scanner.next();
             
        if ((eingelesen.equals(leerzeichen))^(eingelesen.equals(robot))){          
          driver = new Roboter();
        }
        else{
            System.out.println("Gibt bitte den Gehalt ein");
            String gehalt=scanner.next();
            driver = new Busfahrer(eingelesen,gehalt); 
        }
        System.out.println("Willkommen " +driver.getname() + "Diese Ziele Bieten wir an");
        Zielorte reiseziele1 = new Zielorte();
        reiseziele1.getanfahrtsziele();
//        System.out.println(Reiseziele.anfahrtsziele());                       // Kontrolle ob es sich um den gleichen Array handelt
//        System.out.println(Arrays.toString(Reiseziele.anfahrtsziele()));      // Alterativ wenn Reiseziele.getanfahrtsziele() kein void zurückgibt sondern String[] kann man das in der main schreiben   

        System.out.println("Die durchschnittliche Fahrtdauer betragen");
        reiseziele1.getfahrtdauer();
        
        String destination;
        do {
        System.out.println("Wähle einen gültigen Zielort aus");
         destination= scanner.next();
        }
        while((reiseziele1.meinZielort(destination))==false);
     
        System.out.println("Die durchscnittliche Fahrtdauer für "+destination+" beträgt");
        System.out.println(reiseziele1.getfahrtdauer(destination)+"h");
        
        Zielorte reiseziele2 = new Zielorte(destination);
        System.out.println("Dein Fahrer sagt:");
        System.out.println(driver.arbeiten(reiseziele2));
    }
                

} 


    

