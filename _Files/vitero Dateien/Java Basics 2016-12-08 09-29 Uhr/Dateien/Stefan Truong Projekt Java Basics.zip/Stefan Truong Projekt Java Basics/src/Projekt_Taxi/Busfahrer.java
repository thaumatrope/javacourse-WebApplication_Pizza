/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projekt_Taxi;

/**
 *BusfahrerKlasse
 * @author Stefan Truong
 * 
 */
public class Busfahrer extends Person implements Fahrer{
    
    public Busfahrer(String name,String gehalt){
        super(name, gehalt);
    }
    
 
    
  
    public double arbeiten(Zielorte reiseziel){
       
        System.out.println("Ich habe eine rot-grün Schwäche"+"\n");
        System.out.println("Um nach "+reiseziel.getMeinWunschZiel()+" zu kommen, brauche ich");
        /*
         *1.1 ist frei gewählt 
         */
        return 1.1 * reiseziel.getdauer();
        
        
    }
    
    public void pause(){
        System.out.println("Mahlzeit");
    }
    
}
