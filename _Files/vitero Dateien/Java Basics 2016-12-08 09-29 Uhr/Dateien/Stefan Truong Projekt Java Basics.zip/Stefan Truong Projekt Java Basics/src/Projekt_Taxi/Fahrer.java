/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projekt_Taxi;

/**
 *Ein Interface
 * @author IBB Teilnehmer
 */
public interface Fahrer {
    public double arbeiten(Zielorte reiseziel);
    public void pause();
    public String getname();
    
}
