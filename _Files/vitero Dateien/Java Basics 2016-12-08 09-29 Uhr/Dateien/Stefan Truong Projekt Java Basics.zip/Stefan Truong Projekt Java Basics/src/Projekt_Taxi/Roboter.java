/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projekt_Taxi;

/**
 *
 * @author IBB Teilnehmer
 */
public class Roboter implements Fahrer{
    private final String name="Roboter";
    
    public Roboter(){    
    }
    @Override
    public double arbeiten(Zielorte Fahrtziel){
//        System.out.println("ReferenceError: Fußgaenger is not defined");
//        Zielorte Anfahrziele = new Zielorte();
//        return Anfahrziele.getfahrtdauer(Fahrtziel);
            return 2.2;
    }
    
    @Override
    public void pause(){
        System.out.println("Back to work!");
    }
  
    @Override
    public String getname(){
        return name;
    }
}
