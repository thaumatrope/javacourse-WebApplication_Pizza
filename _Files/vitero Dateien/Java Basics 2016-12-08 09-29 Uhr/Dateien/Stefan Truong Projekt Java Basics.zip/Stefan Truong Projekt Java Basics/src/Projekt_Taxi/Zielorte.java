/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projekt_Taxi;

import java.util.Arrays;

/**
 *
 * @author IBB Teilnehmer
 */
public class Zielorte {
   private final String[] Ziele = new String[5];
   private final int[] Fahrtdauer = new int[5];
   private String meinWunschZiel;
   private int meinWunschZielindex;
   

    
    public Zielorte(){
    } 
    public Zielorte(String destination){
        
    this.Ziele[0] = "Stuttgart"; 
    this.Ziele[1] = "München";    
    this.Ziele[2] = "Dresden";    
    this.Ziele[3] = "Berlin";     
    this.Ziele[4] = "Hamburg"; 
    
    this.Fahrtdauer[0] = 1;
    this.Fahrtdauer[1] = 3;
    this.Fahrtdauer[2] = 6;
    this.Fahrtdauer[3] = 10;
    this.Fahrtdauer[4] = 9;
        

        this.meinWunschZiel = destination;
        int i;
        for (i=0; i<Ziele.length; i++){
        
            if(Ziele[i].equals(destination)){

                this.meinWunschZielindex = i;  
        break;
        }
        else {}
            
        }
        
    }
 
    
    public void getanfahrtsziele(){ 
    Ziele[0] = "Stuttgart"; 
    Ziele[1] = "München";    
    Ziele[2] = "Dresden";    
    Ziele[3] = "Berlin";     
    Ziele[4] = "Hamburg"; 
    
    System.out.println(Ziele);                                                  // zeigt die Speicerstelle des Arrays
    System.out.println(Arrays.toString(Ziele));                                 // Arrays.toString(Objekt) zeigt den Inhalt des Arrays           
    }
    
    public void getfahrtdauer(){
    Fahrtdauer[0] = 1;
    Fahrtdauer[1] = 3;
    Fahrtdauer[2] = 6;
    Fahrtdauer[3] = 10;
    Fahrtdauer[4] = 9;
    
    System.out.println(Arrays.toString(Fahrtdauer));
    }
    
    public boolean meinZielort(String target){
        boolean existiert=true;                                                 // Achtung ein boolean muss immer vorinitialisiert werden!
        int i;
        for (i=0; i<Ziele.length; i++){
        
            if(Ziele[i].equals(target)){

                existiert=true;  
               
        break;
        }
        else {
                existiert=false;
                }
    }   

        return existiert;
    }
    
    public String getMeinWunschZiel(){
        return meinWunschZiel;
    }
    
    public int getfahrtdauer(String Zielort){
        
        int dauer=Fahrtdauer[meinWunschZielindex];
        return dauer;
    }
    public int getdauer(){
        return Fahrtdauer[meinWunschZielindex];
    }
}

