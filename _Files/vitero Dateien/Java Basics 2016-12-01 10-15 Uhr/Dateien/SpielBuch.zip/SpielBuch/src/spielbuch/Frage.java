/**
 * Package spielbuch 
 * Repräsentiert die KLasse Frage
 * @class Frage
 */
package spielbuch;

/**
 * Klasse Frage
 * Repräsentiert eine Frage für eien Textabschnitt
 * @author Silvan Kolb
 */
public class Frage {
 
    /**
     * Hier wird die aktuelle Frage gestellt 
     */    
    private final String frage;
    
    /**
     * Hier wird der Abschnitt als Sprungmerke angegeben
     */
    private final int id;
      
    /**
     * Setzt eine Frage und eine Sprungmarke zu einem Abschnitt
     * @param frage     Fragestellung
     * @param abschnitt Sprungmarke    
     */
    public Frage(String frage, int id){
        
        this.frage = frage;
        this.id = id; 
    }    
    
    /**
     * Liest die aktuelle Frage
     */
    public String getFrage(){
        return this.frage;
    }    
    
    /**
     * Liest die aktuelle Sprungmarke zum nächsten Abschnitt
     */
    public int getAbschnitt(){
        return this.id;
    }
}
