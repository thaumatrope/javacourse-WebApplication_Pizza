/**
 * Package spielbuch 
 * Spieldefinition für ein textbasiertes Abenteuer
 * @class Spiel
 */
package spielbuch;

/**
 * Dies ist die Dokumentation der Klasse Spiel. 
 * Diese Klasse dient dem Aufbau eines textbasierten Abenteuer.
 * Das Spiel ist in Textabschnitte unterteilt. Am Ende jeden
 * Abschnittes werden zwei Fragen gestellt. Die Fragen sind
 * als Entscheidungen nur mit 1 oder 2 zu beantworten. 
 * 
 * @author  Silvan Kolb
 * @version 1.1 
 */
public class Spiel {
    
    /**
     * Array spielSteps 
     * Beinhaltet sämtliche textbasierten Abschnitte des Spiels
     */
    private final Abschnitt[] spielSteps = new Abschnitt[6];
    /**
     * Array abschnittFragen
     * Beinhaltet jeweils 2 Fragen pro Abschnitt
     */
    private Frage[] abschnittFragen = new Frage[2]; 
    
    /**
     * Initialisierung des Spiels und Aufbau aller Textabschnitte
     */
    public void ladeSpiel(){        
        
        /**
         * Willkommen
         * Einführungstext
         * Abschnitts-ID :: 0
         */        
        Abschnitt a0 = new Abschnitt(0,"Willkommen im Textadventure \"Die verlassene Burg\""
                        ,"In diesem Abenteuer der verlassenen Burg bist du auf dich allein gestellt.\n"
                        +"Du allein mußt den Ausgang finden um der Burg zu entkommen. \nDas Abenteuer beginnt jetzt in der Eingangshalle der Burg."
                       );       
        
        // Entscheidungen
        Frage f0 = new Frage("Dummy",1);
        
        
        // Init und Fragestellungen
        abschnittFragen = new Frage[2];
        abschnittFragen[0] = f0;
        abschnittFragen[1] = f0;
        
        // Fragenset an Abschnitt hängen
        a0.setFragen(abschnittFragen);
        
        
        /**
         * EINGANGSHALLE
         * Hier beginnt das Abenteuer
         * Abschnitts-ID :: 1
         */
        Abschnitt a1 = new Abschnitt(1,"EINGANGSHALLE"
        ,"Du stehst in der dachlosen Eingangshalle der verlassenen Burg. Die alten und verwitterten Wände sind mit Moos und Grünspan bedeckt.\n" 
        +"Die Luft ist feucht und muffig, du hörst den Wind durch entfernte Fenster heulen. \nWas machst du?"
        );
        
        // Entscheidungen
        Frage f1 = new Frage("1. Ich gehe durch das Burgtor",2);
        Frage f2 = new Frage("2. Ich gehe durch den Schildgang in das Innere der Burg",4);        
        
        // Init und Fragestellungen
        abschnittFragen = new Frage[2];
        abschnittFragen[0] = f1;
        abschnittFragen[1] = f2;
        
        // Fragenset an Abschnitt hängen
        a1.setFragen(abschnittFragen);
        
        /**
         * BURGTOR
         * Das Tor in der Eingangshalle
         * Abschnitts-ID :: 2
         */
        Abschnitt a2 = new Abschnitt(2,"BURGTOR"
                ,"Das Tor in der Eingangshalle ist ein großer, halbrunder Bogen.\n" 
                +"Es ist mit einem mächtigem Fallgitter verschlossen. Die Sicht durch das Gitter ist versperrt, " 
                +"\ndurch das Gitter hindurch kannst du Holzplanken ausmachen, die zu einer Zugbrücke gehören." 
                +"\nAuf der linken Seite ist am Boden eine Kurbelvorrichtung eingelassen, mit der das Fallgitter bewegt werden könnte." 
                +"\nWie entscheidest du dich?"
        );
        
        // Entscheidungen
        Frage f3 = new Frage("1. Ich gehe zurück zur Eingangshalle",1);
        Frage f4 = new Frage("2. Ich betätige die Kurbelvorrichtung",3);
        
        // Init und Fragestellungen
        abschnittFragen = new Frage[2];
        abschnittFragen[0] = f3;
        abschnittFragen[1] = f4;
        
        // Fragenset an Abschnitt hängen
        a2.setFragen(abschnittFragen);
        

        /**
         * KURBELVORRICHTUNG
         * Kette an Winde
         * Abschnitts-ID :: 3
         */
        Abschnitt a3 = new Abschnitt(3,"KURBELVORRICHTUNG"
                ,"Im Boden ist eine große Vorrichtung eingelassen, an der eine Winde befestigt ist. \n"
                + "Eine rostige Kette kommt aus einer schmalen Öffnung neben dem Burgtor.\n" 
                + "An der Winde ist eine Kurbel aufgesteckt. Die Kette ist mit der Winde verbunden." 
                +"\nWas gedenkst du zu tun?" );
        
        // Entscheidungen
        Frage f5 = new Frage("1. Ich gehe zurück zum Burgtor",2);
        Frage f6 = new Frage("2. Ich ziehe an der Kette",999);
        
        // Init und Fragestellungen
        abschnittFragen = new Frage[2];
        abschnittFragen[0] = f5;
        abschnittFragen[1] = f6;
        
        // Fragenset an Abschnitt hängen
        a3.setFragen(abschnittFragen);
        
        /**
         * SCHILDGANG
         * Schildgang mit Waffen und schmaler Tür
         * Abschnitts-ID :: 4
         */
        Abschnitt a4 = new Abschnitt(4,"SCHILDGANG",
             "An den Wänden hängen verwitterte Schilde, die einst wohl mit prächtigen Wappen verziehrt waren.\n" +
"An der Wand ist eine schmale Tür eingelassen.\n" +
"\n" +
"Der Gang führt in die Eingangshalle und in die Empfangshalle." 
                +"\nWohin gehst du?" );
        
        // Entscheidungen
        Frage f7 = new Frage("1. Ich gehe zurück zur Eingangshalle",1);
        Frage f8 = new Frage("2. Ich gehe zur schmalen Tür",5);
        
        // Init und Fragestellungen
        abschnittFragen = new Frage[2];
        abschnittFragen[0] = f7;
        abschnittFragen[1] = f8;
        
        // Fragenset an Abschnitt hängen
        a4.setFragen(abschnittFragen);
        
 
         /**
         * SCHMALE TÜR
         * Schmale Tür, die verschlossen ist
         * Abschnitts-ID :: 5
         */
        Abschnitt a5 = new Abschnitt(5,"SCHMALE TÜR"
                ,"Die Tür des Schildgangs ist aus massiven Holzbalken und du kannst keine Klinke entdecken. Einzig ein Schlüsselloch ist zu erkennen.\n" 
                + "Du drückst gegen die Tür, aber sie scheint fest verschlossen zu sein." 
                +"\nWas nun?" );
        
        // Entscheidungen
        Frage f9  = new Frage("1. Ich gehe zurück zur Eingangshalle",1);
        Frage f10 = new Frage("2. Ich gehe durch den Schildgang zurück",4);
        
        // Init und Fragestellungen
        abschnittFragen = new Frage[2];
        abschnittFragen[0] = f9;
        abschnittFragen[1] = f10;
        
        // Fragenset an Abschnitt hängen
        a5.setFragen(abschnittFragen);
        
        /**
         * Liste aller Abschnitte
         * @array spielSteps
         */
        spielSteps[0] = a0;    
        spielSteps[1] = a1; 
        spielSteps[2] = a2; 
        spielSteps[3] = a3;
        spielSteps[4] = a4;
        spielSteps[5] = a5;
    }    
    /**
     * findeSpielAbschnitt
     * Sucht einen Textabschnitt über die Abschnitts-ID 
     * (siehe auch Methode "getAbschnittsID" in der Klasse "Abschnitt", 
     * die über die Benutzereingabe aus der Frage ermittelt wird)
     * Zurückgegeben wird das gesamte Objekt 
     * 
     * @param abschnittID
     * @return 
     */
    public Abschnitt findeSpielAbschnitt(int abschnittID){        
        for(int i=0;i<spielSteps.length;i++){
            if( spielSteps[i].getID() == abschnittID){
                return spielSteps[i];
            }
        }
        return null;
    }
    /**
     * output
     * Impliziert die Ausgabe über SOUT    
     * @param Ausgabe
     * @return 
     */
    public String output(String Ausgabe){        
        System.out.println(Ausgabe); 
        return null;
    }
    
}
