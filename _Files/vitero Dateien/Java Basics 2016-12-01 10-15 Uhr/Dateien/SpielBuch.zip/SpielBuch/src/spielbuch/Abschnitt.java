/**
 * Package spielbuch 
 * Textabschnitt für ein textbasiertes adventure
 * @class Abschnitt
 */
package spielbuch;

/**
 * Dies ist die Dokumentation der Klasse Abschnitt. 
 * Ein Abschnitt repräsentiert einen Textabschnitt im Adventure
 * 
 * Vererbung der Klasse Einheit
 * @author  Silvan Kolb
 * @version 1.1 
 */
public class Abschnitt extends Einheit{
    
    /**
     * Array, welches 2 Fragen repräsentiert
     */
    private Frage[] fragenList = new Frage[2];
    
    /**
     * Abschnitt constructor
     * 
     * @param id    id Abschnitt
     * @param name  Titel
     * @param desc  Beschreibung
     */
    public Abschnitt(int id, String name, String desc ) {
        super(id, name, desc);
    }

    /**
     * setFragen
     * sample fragenList[1].getFrage();
     * @param fragen liste der Fragen eines Abschnittes
     */
    public void setFragen(Frage[] fragen){
         fragenList = fragen;
    }
     
    /**
     * getFragen
     * Ausgabe aller Fragen des Abschnittes
     */    
    public void getFragen(){
        for (Frage fragenList1 : fragenList) {
            System.out.println(fragenList1.getFrage());
        }
    }
    
    /**
     * getAbschnittsID
     * Suche über Benutzereingabe von 1 oder 2 in der Frage
     * die Abschnitts-ID, auf die verzweigt werden soll
     * @param userInput Benutzereingabe
     * @return Sprungmarke zurückgeben
     */    
    public int getAbschnittsID(int userInput){
        userInput--;
        if(userInput==0 || userInput==1){
            return fragenList[userInput].getAbschnitt();
        }
        else 
            return -1;
    }
            
}
