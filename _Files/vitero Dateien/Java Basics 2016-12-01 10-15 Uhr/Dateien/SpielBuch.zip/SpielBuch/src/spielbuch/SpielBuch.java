/**
* "Die verlassene Burg"
* SpielBuch ist die MAIN Klasse des textbasierten Adventure 
* @author  Silvan Kolb
* @version 1.1
*/
package spielbuch;

import java.util.Scanner;

/**
 * Klasse SpielBuch 
 * Main Klasse des Spiels
 * 
 * @author  Silvan Kolb
 * @version 1.1 
 */
public class SpielBuch {

    /**
     * @param args the command line arguments
     */    
    public static void main(String[] args) {       
        // Scanner einbinden 
        Scanner eingabe =   new Scanner(System.in);
        
        // userInput    Benutzereingabe
        // nextID       nächste Abschnitts-ID
        int userInput   = 0;
        int nextID      = 1;
         
        // Object Spiel
        Spiel burg = new Spiel(); 
        
        // Lade Spiel
        burg.ladeSpiel();
        
        // Einleitung ausgeben
        Abschnitt abschnitt = burg.findeSpielAbschnitt(userInput);
                              burg.output(abschnitt.getName());
                              burg.output(abschnitt.getDesc());
        // Nächster Abschnitt
        userInput++;
        
        /**
         * Schleife über sämtliche Textabschnitte
         * Grundsätzlich wird eine Benutzereingabe erwartet, bei dem 
         * der Benutzer eine von zwei möglichen Entscheidungen treffen muss.
         * 
         * Mögliche Antworten sind:
         *  1 = Entscheidung für die erste Frage
         *  2 = Entscheidung für die zweite Frage
         * -1 = Spielabbruch (Game over)
         */
        do{
            // Grundsätzlich eine Zeile vor jedem Abschnitt
            System.out.println("-------------------------------------------------------------------");    

            // Ist die Benutzereingabe korrekt und auswertbar?
            if(userInput == 1 || userInput == 2){                    
                
                // Suche die ID des Abschnittes anhand der Benutezreingabe
                // Problem: Der Benutzer gibt nur 1 oder 2 ein.
                // Jede Frage impliziert jedoch die nächste Sprungmarke.
                // Diese wird in der Methode "getAbschnittsID" ermittelt
                nextID = abschnitt.getAbschnittsID(userInput);

                // Abschnitt: Finde den Spielabschnitt mit der angegeben ID
                // Die ID ist bereits die ID des Abschnittes
                abschnitt = burg.findeSpielAbschnitt(nextID);
                
                if(abschnitt != null){
                // Der Abschnitt kann ausgegeben werde 
                // Name (Titel in Großbuchstaben)
                // Desc (Beschreibung der Ausgabe oder Umgebung)
                burg.output(abschnitt.getName());
                burg.output(abschnitt.getDesc());
                
                // Gib alle Fragestelungen des Abschnittes aus
                abschnitt.getFragen();         
                }
                else{
                    System.out.println("Du bist in den Brunnen gefallen...");
                    break;
                }
   
            }
            
            // Benutzeraufforderung
            System.out.println("\nBenutzereingabe: " );    
            // Eingabe über Console            
            userInput = eingabe.nextInt();           
                     
            // Ist die Benutezreingabe korrekt und auswertbar?
            if(userInput!=1 && userInput != 2 && userInput != -1){
               System.out.println("Folgende Eingaben sind möglich: 1, 2 oder -1");                  
            }
                
        // Abbruch durch -1=Exit   
        }while( userInput != -1 );
        
        /**
         * GAME OVER :: Abbruch durch USER
         */
        System.out.println("Game over");
    }   
}
