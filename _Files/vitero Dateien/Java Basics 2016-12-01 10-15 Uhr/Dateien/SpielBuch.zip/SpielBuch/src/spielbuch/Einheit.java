/**
 * Package spielbuch 
 * Repräsentiert Vererbungsklasse Einheit für einen Textabschnitt
 * @class Einheit
 */
package spielbuch;

/**
 * Vererbungsklasse für eine Texteinheit
 * @author Silvan Kolb
 */
public class Einheit {
    
    int id;
    String name;
    String desc;  
  
    /**
    * Contructor
    * @param uName Name der Texteinheit
    * @param uDesc Beschreibung
    */    
    public Einheit(int id, String name, String desc){
        this.id = id;
        this.name = name;
        this.desc = desc;
    }
    
    /**
    * getID
    * Liefert die ID der Texteinheit
    * @return ID
    */    
    public int getID(){
        return id;
    }
    
    /**
    * getName
    * Liefert den Namen einer Texteinheit
    * @return name
    */    
    public String getName(){
        return name;
    }
    
    /**
    * getDesc
    * Liefert die Beschreibung einer Texteinheit
    * @return desc
    */    
    public String getDesc(){
        return desc;
    }         
}