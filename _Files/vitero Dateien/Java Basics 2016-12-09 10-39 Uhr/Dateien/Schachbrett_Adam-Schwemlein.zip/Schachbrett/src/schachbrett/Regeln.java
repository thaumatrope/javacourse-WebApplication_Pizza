/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schachbrett;

/**
 *
 * @author User705
 */
public class Regeln extends Spielbrett {

    /**
     * Feststellen mit welcher Figur gezogen werden soll. Dann wird
     * festgestellt, ob die Regeln für dies Figur eingehalten werden.
     *
     * @param zugInput
     * @param figur_zugFrom
     * @param figur_zugTo
     * @return
     */
    public static boolean CheckRegeln(String zugInput, String figur_zugFrom, String figur_zugTo) {
        boolean feldPrüfen = false;

        // Mit welcher Figur soll gezogen werden? Für die ermittelte Figur werden die Spielzug-Regeln überprüft.
        switch (figur_zugFrom) {
            case "b":
                // Regeln für weiße Bauern
                if (Figur.Freiesfeld(figur_zugFrom, figur_zugTo)) {                   // Prüfen von Ausgangsfeld und Zielfeld
                    if (Bauer.WeißeBauern(zugInput)) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

            case "B":
                // Regeln für schwarze Bauern
                if (Figur.Freiesfeld(figur_zugFrom, figur_zugTo)) {                   // Prüfen von Ausgangsfeld und Zielfeld
                    if (Bauer.SchwarzeBauern(zugInput)) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

            default:
                // Prüfe, ob auf den Zubpositionen Figuren stehen
                if (!(Figur.Freiesfeld(figur_zugFrom, figur_zugTo))) {               // Prüfen von Ausgangsfeld und Zielfeld
                    return false;
                }
                // Für diese Figur gibt es noch keine Regel. Aber der Zug soll derzeit trotzdem zugelassen werden.
                // später weiter   ???
                System.out.println("Diese Regel ist noch nicht implementiert");
                return true;
        }
    }
}
