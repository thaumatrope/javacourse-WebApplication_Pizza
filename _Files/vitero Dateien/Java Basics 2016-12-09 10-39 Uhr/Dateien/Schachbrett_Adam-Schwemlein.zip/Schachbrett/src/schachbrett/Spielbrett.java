/**
 */
package schachbrett;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Spielbrett-Initialisierung
 * 
 * @author User705
 */
public class Spielbrett {
    
    String zugEingabe = "a1b2";                     // Initialisierung, mit einer Beispielseingabe
    boolean checkEingabe = true;
    boolean neuerZug = true;
    boolean requestText = true;
    String letzterZug = "X";                        // Initialisierung, mit einer Beispielseingabe
    String figur_zugVon = "K";                      // Initialisierung, mit einer Beispielseingabe
    String figur_zugNach = "T";                     // Initialisierung, mit einer Beispielseingabe
    char farbeEingabe_von = ' ';                    // Feldfarbe der Startpositions-Eingabe
   
    String[][] schachbrett
            = {
                // Grundstellung auf dem Schachbrett
                {" ", " ", " ", " ", " ", " ", " ", " ", " ", " "},
                {" ", "T", "P", "L", "D", "K", "L", "P", "T", " "}, // schwarze Figuren, große Buchstaben
                {" ", "B", "B", "B", "B", "B", "B", "B", "B", " "},
                {" ", "w", " ", "w", " ", "w", " ", "w", " ", " "},
                {" ", " ", "w", " ", "w", " ", "w", " ", "w", " "},
                {" ", "w", " ", "w", " ", "w", " ", "w", " ", " "},
                {" ", " ", "w", " ", "w", " ", "w", " ", "w", " "},
                {" ", "b", "b", "b", "b", "b", "b", "b", "b", " "},
                {" ", "t", "p", "l", "d", "k", "l", "p", "t", " "}, // weiße Figuren, kleine Buchstaben
                {" ", " ", " ", " ", " ", " ", " ", " ", " ", " "}
            };

    /**
     * Ersetze die Schachbrett-Initialisierung ('w',' ') durch weiße und schwarze Felder
     */
    public void setSchachbrett() {
        for (int zeile = 3; zeile <= 6; zeile++) {
            for (int spalte = 1; spalte <= 8; spalte++) {

                // weißer Block oder Leerzeichen (schwarzer Block)
                schachbrett[zeile][spalte] = "" + (9 - zeile);                             // Zeilennummerierung, "" erzwingt String-Umwandlung für den folgenden int-Wert
                schachbrett[zeile][spalte] = "" + (((((zeile - 1) + spalte) % 2) != 0) ? (char) 0x258C : ' ');    // 0x258C halber Block (weißes Feld), ' ' schwarzes Feld
            }
        }
    }
    
    /**
     * Zugriff auf Schachbrett
     * @return 
     */
    public String[][] getSchachbrett(){
        return schachbrett;
    }
            
    // Historieliste mit den ausgeführten Spielzügen
    ArrayList spielzüge = new ArrayList();
    
    /**
     * Eingabe eines Spielzuges und Überprüfung der Zugeingabe
     */
    public void PruefeZugeingabe() {
        Scanner eingabe = new Scanner(System.in);

        while (neuerZug) {                                                    // Eingabe von Spielzügen)
            checkEingabe = true;
            
            // Eingabe und Eingabe-Prüfung
            while (checkEingabe) {
                boolean resultFehler = false;
                if (requestText) {
                    System.out.println("Bitte geben Sie einen Spielzug ein:     ");
                    zugEingabe = new String(eingabe.next());
                    zugEingabe = zugEingabe.toLowerCase();
                }
                
                // Eingabe prüfen
                if (zugEingabe.length() != 4) {
                    System.out.println("Es muessen vier Zeichen eingegeben werden z.B. b2b4");
                    checkEingabe = true;
                }
                else {
                    for (int i = 0; i < 4; i++) {
                        if (i % 2 > 0)                          // Prüfen der Zeilennummer
                        {
                            //if (!((zugEingabe[i] >= '1') && (zugEingabe[i] <= '8')))
                            if (!((zugEingabe.charAt(i) >= '1') && (zugEingabe.charAt(i) <= '8')))
                            {
                                System.out.println(zugEingabe.charAt(i)+" : Zeichen ist falsch" );
                                resultFehler = true;
                            }
                        }
                        else                                    // Prüfen der Spaltennummer
                        {
                            if (!((zugEingabe.charAt(i) >= 'a') && (zugEingabe.charAt(i) <= 'h')))
                            {
                                //System.out.println("Zeichen ist falsch" +zugEingabe.charAt(i));
                                System.out.println(zugEingabe.charAt(i)+ " : Zeichen ist falsch" );
                                resultFehler = true;
                            }
                        }

                        if (resultFehler) {                         // Eingabe des nächsten Zugs war nicht korrekt
                            checkEingabe = true;                    // Die Eingabe muss wiederholt werden
                        }                
                        else { 
                            checkEingabe = false;                   // Die Zug-Eingabe ist richtig. Eingabeprüfung beenden.
                        }          
                    }
                }
            }   // Ende von: while (checkEingabe)
            
            PruefeSpielzug();
            
            //regel1.CheckRegeln(spBrett.zugEingabe, spBrett.figur_zugVon, spBrett.figur_zugNach);
            if (Regeln.CheckRegeln(zugEingabe, figur_zugVon, figur_zugNach)) {
                // Der Zug ist zulässig
                // Setze die Figur von Ausgangs- auf Zielposition
                String strFarbeEingabe_von = ""+farbeEingabe_von;                                   // Leeres Feld; char in String wandeln
                schachbrett[this.getZielfeld(zugEingabe)] [this.holeSpalte(zugEingabe, 2)] = 
                        schachbrett[this.getAusgangsfeld(zugEingabe)] [this.holeSpalte(zugEingabe, 0)];
                schachbrett[this.getAusgangsfeld(zugEingabe)] [this.holeSpalte(zugEingabe, 0)] = strFarbeEingabe_von;      // Feld als frei markieren
                
                // Schachbrettanzeige mit ausgeführtem Spielzug
                Ausgabe(getSchachbrett());
                System.out.println("");             // Leerzeile
                
                 // Spielzug in die Historieliste eintragen
                spielzüge.add(zugEingabe);
            }
            else {
                // Der Zug ist nicht zulässig
                System.out.println("Der Zug ist nicht erlaubt");
            }
            
            System.out.println("Bitte geben Sie einen Spielzug ein oder beenden Sie mit x:   ");
 
            letzterZug = new String(eingabe.next());
            letzterZug = zugEingabe.toLowerCase();                      // Eingabe in Kleinbuchstaben wandeln
            
            if (letzterZug == "x"){
                neuerZug = false;
            }
            else {
                requestText = false;                                // Die Spielzug-Eingabeaufforderung muss nicht mehr ausgegeben werden
                zugEingabe = letzterZug;
            }
        }   // Ende von: while (neuerZug)
        
        System.out.println("Bitte geben Sie eine Auswahl ein     ");
        System.out.println("- Historieliste ausgeben mit H     > ");
        System.out.println("- Beenden mit X                    > ");
        zugEingabe = new String(eingabe.next());
        zugEingabe = zugEingabe.toLowerCase();                      // Eingabe in Kleinbuchstaben wandeln
        if (zugEingabe == "h") {
            for (Object e : spielzüge) {                            // ArrayList spielzüge
                System.out.println("" + e);
            }
        } else if (zugEingabe == "x") {
            /* Beenden */ }

        System.out.println(">> Ende <<   ");
        System.out.println("");
     }   //  Ende von: public void Spielzug()
    
    /**
     * Überprüfung des Spielzugs
     */
    public void PruefeSpielzug() {
        // Selektierung von Spalten und Zeilen aus der Spielzugeingabe (Ausgangsfeld und Zielfeld)
        // Ausgangsfeld: figur_zugVon, indexZeileVon
        int indexZeileVon = new Integer(zugEingabe.substring(1, 2));        // Eingabe-Zeile, zugEingabe = "a1b2", substring = "1", Wrapper Klasse
        indexZeileVon = (9 - indexZeileVon);                                // Schachbrett-Zeile
        String spalte_zugVon = zugEingabe.substring(0, 1);                  // Eingabe-Zeile, zugEingabe = "a1b2", substring = "a"
        int indexSpalteVon = 0;                                             // Schachbrett-Spalte
        indexSpalteVon = holeSpalte(zugEingabe, 0);
        
        // Figur vom Ausgangsfeld aus dem Schachbrett-Array holen
        figur_zugVon = schachbrett[indexZeileVon][indexSpalteVon];          // schachbrett[schachZeile][schachSpalte];

        // Zielfeld: figur_zugNach, indexZeileNach
        int indexZeileNach = new Integer(zugEingabe.substring(3, 4));       // Eingabe-Zeile, zugEingabe = "a1b2", substring = "2"
        indexZeileNach = (9 - indexZeileNach);                              // Schachbrett-Zeile
        String spalte_zugNach = zugEingabe.substring(2, 3);                 // Eingabe-Zeile, zugEingabe = "a1b2", substring = "b"
        int indexSpalteNach = 0;                                            // Schachbrett-Spalte
        indexSpalteNach = holeSpalte(zugEingabe, 2);
        figur_zugNach = schachbrett[indexZeileNach][indexSpalteNach];       // schachbrett[schachZeile][schachSpalte];
    }   // Ende von: public void PruefeSpielzug
    
    /**
     * Ermittlung des Schachbrett-Spalten-Indexes
     * 
     * @param spalteZug
     * @param indexSpalte
     * @return 
     */
    public int holeSpalte(String zugeingabe, int index) { // a1b3
        char c = zugeingabe.charAt(index);
        switch (c) {
            case 'a': case 'A':
                return 1;
            case 'b': case 'B':
                return 2;
            case 'c': case 'C':
                return 3;
            case 'd': case 'D':
                return 4;
            case 'e': case 'E':
                return 5;
            case 'f': case 'F':
                return 6;
            case'g': case 'G':
                return 7;
            case 'h': case 'H':
                return 8;
            default:
                System.out.println("==> spalte_zugVon ist unbekannt" + zugeingabe);    // wird nicht erreicht, ist vorher abgefangen
                return 0;
        }
    }   // Ende von: public int HoleSpalte
     
        // Prüfe Regeln
    
    /**
     * Konsolen-Ausgabe des Schachbretts
     * @param schachbrett 
     */
     public static void Ausgabe(String[][] schachbrett) {
         System.out.println("  abcdefgh ");                          // obere Spaltenbeschriftung
         for (int row = 1; row < 9; row++) {
             System.out.print(9 - row);                              // vordere Feldnummerierung mit folgendem Leerzeichen
             for (int col = 0; col < 9; col++) {
                 System.out.print(schachbrett[row][col]);
             }
             System.out.print(" " + (9 - row));                      // Leerzeichen und hintere Feldnummerierung
             System.out.println();
         }
         System.out.println("  abcdefgh ");                          // untere Spaltenbeschriftung
     }
     
     /**
      * Umwandlung der Zugeingabe für das Ausgangsfeld in einen Integer-Wert
      * 
      * @param str
      * @return 
      */
     public int getAusgangsfeld (String str){
         return ( 9 - Integer.parseInt(str.substring(1,2))); 
     }
     
     /**
      * Umwandlung der Zugeingabe für das Zielfeld in einen Integer-Wert
      * 
      * @param str
      * @return 
      */
     public int getZielfeld (String str){ 
         return ( 9 - Integer.parseInt(str.substring(3))); 
     }
}