package schachbrett;

//import java.util.Scanner;                                   // notwendig für die Eingabe mit Scanner

/**
 * Schachprogramm 
 * Dies ist ein einfaches Programm, das ein Schachbrett darstellt. 
 * Es können Züge eingegeben werden, die dann auf ihre richtige Eingabe überprüft werden. 
 * Bei falscher Eingabe soll der Zug wiederholt werden. Auch werden Zug-Regeln überprüft.
 * Allerdings sind derzeit nur einige wenige Regeln implementiert. Nach Spiel-Ende kann
 * wahlweise eine Historieliste mit den ausgeführten Spielzügen angezeigt werden.
 *
 * @author User705
 */

public class Schachspiel {

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Spielbrett spBrett = new Spielbrett();
        Figur figur1= new Figur();
        
        // Ersetze die Schachbrett-Initialisierung ('w',' ') durch weiße und schwarze Felder
        spBrett.setSchachbrett();

        //Zeige das Schachbrett mit Figuren sowie weißen und schwarzen Feldern in Ausgangslage an
        spBrett.Ausgabe(spBrett.getSchachbrett()); 
        
        // Eingabe eines Spielzuges und Überprüfung der Zugeingabe
        spBrett.PruefeZugeingabe();
    }
}

