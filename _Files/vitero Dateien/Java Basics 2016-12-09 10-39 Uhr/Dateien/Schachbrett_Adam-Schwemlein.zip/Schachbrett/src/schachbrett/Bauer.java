/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schachbrett;

/**
 * Spielzug Bauern prüfen
 * Wenn Bauer auf Grundlinie steht, darf er zwei Felder ziehen, sonst ein Feld
 * 
 * @author User705
 */
public class Bauer extends Figur {
    /**
     * Spielzug für weiße Bauern überprüfen
     * 
     * @param zugInput
     * @return 
     */
    public static boolean WeißeBauern(String zugInput) {
        int indexZeileVon  = new Integer(zugInput.substring(1, 2));     // zugEingabe = "a1b2", substring = "1"
        int indexZeileNach = new Integer(zugInput.substring(3, 4));     // zugEingabe = "a1b2", substring = "2"
        
        if (indexZeileVon == 2) {                           // Grundlinie, max. zwei Plätze ziehen
            if ((indexZeileNach <= (indexZeileVon) + 2)) {
                return true;                                // Zug (2 Felder) ist erlaubt
            }
            else {
                System.out.println("-> Zug ist nicht erlaubt, da mehr als 2 Felder");
                return false;                               // Zug ist nicht erlaubt
            }
        }
        else if ((indexZeileNach <= (indexZeileVon) + 1)) {
            return true;                                    // Zug (1 Feld) ist erlaubt
        }
        else {
            System.out.println("-> Nicht erlaubte Sprungweite");
            return false;                                   // Zug ist nicht erlaubt
        }
    }
    
    public static boolean SchwarzeBauern(String zugInput) {
        int indexZeileVon  = new Integer(zugInput.substring(1, 2));     // zugEingabe = "a1b2", substring = "1"
        int indexZeileNach = new Integer(zugInput.substring(3, 4));     // zugEingabe = "a1b2", substring = "2"

        if (indexZeileVon == 7) {                           // Grundlinie, max. zwei Plätze ziehen
            if ((indexZeileNach >= (indexZeileVon) -2)) {
                return true;                                // Zug (2 Felder) ist erlaubt
            } else {
                System.out.println("-> Zug ist nicht erlaubt, da mehr als 2 Felder");
                return false;                               // Zug ist nicht erlaubt
            }
        } else if ((indexZeileNach >= (indexZeileVon) - 1)) {
            return true;                                    // Zug (1 Feld) ist erlaubt
        } else {
            System.out.println("-> Nicht erlaubte Sprungweite");
            return false;                                   // Zug ist nicht erlaubt
        }
    }
}
