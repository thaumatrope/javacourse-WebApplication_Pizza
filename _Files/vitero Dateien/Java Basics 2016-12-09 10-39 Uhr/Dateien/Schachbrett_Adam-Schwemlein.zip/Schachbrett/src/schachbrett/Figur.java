/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schachbrett;

/**
 *
 * 
 * @author Adam
 */
public class Figur extends Spielbrett {
    
    /**
     * 
     * Prüfen,ob Ausgangsfeld und Zielfeld frei oder mit einer Figur belegt sind. Das Ausgangsfeld muss mit einer Figur 
     * belegt sein. Das Zielfeld muss frei sein.
     * 
     * @param figur_zugFrom
     * @param figur_zugTo
     * @return 
     */
        public static boolean Freiesfeld(String figur_zugFrom, String figur_zugTo) { 
        if ((figur_zugFrom.equals(" ")) || ((figur_zugFrom.charAt(0) == 0x258C) )) {        // Vergleich Ausgangsfeld mit schwarzem und weißem Feld
            // Auf dem Startfeld steht keine Figur
            System.out.println("-> Das Startfeld ist ohne Figur");
            return false;
        }
        else if (! ((figur_zugTo.equals(" ")) || ((figur_zugTo.charAt(0) == 0x258C) ))) {    // Vergleich Zielfeld mit schwarzem und weißem Feld
           // Das Zielfeld muss frei sein
            System.out.println("-> Das Zielfeld ist nicht frei");
            return false;
        }
        else {
            return true;
        }
    }   // ende von: public boolean Freiesfeld
        
    // später ergänzen:         ???
    // Prüfe ob die Figuren auf Ausgangs- und Zielfeld zur gleichen Spielfarbe gehören oder ob sie Gegenspieler sind.
   
}
