/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projekt_Taxi;

import java.util.Scanner;

/**
 *
 * @author IBB Teilnehmer
 */
public class Person {
    private String name;
    private boolean pause=true;
    private String gehalt;
    private int richtigerGehalt;
    private boolean bestaetigung;
    
    public Person(String name, String gehalt){
        this.name = name;
        this.gehalt = gehalt;
        
        
           do{
        try{             
            int umwandeln = Integer.parseInt(gehalt);                           // wandelt String gehalt in einen int um. Wirft ein NumberformatException wenn ein Problem ergibt. 
            bestaetigung = false;
            this.name=name;
            this.richtigerGehalt=umwandeln;
//            System.out.println("1"+this.name);
//            System.out.println("2"+this.richtigerGehalt);
        }
        catch (NumberFormatException wf) {                                      //wenn eder Fehler auftaucht springe hierher                                              
            System.out.println("Falsches Format eingegeben? Gebe neues Gehalt ein");
            Scanner scanner=new Scanner(System.in);
            gehalt= scanner.next();
            bestaetigung = true;
//            System.out.println("3"+this.name);
//            System.out.println("4"+Gehalt);
        }
        }
        while(bestaetigung==true);    
    }


public String getname(){
return name;
}

public int getgehalt(){
return richtigerGehalt;
}
}