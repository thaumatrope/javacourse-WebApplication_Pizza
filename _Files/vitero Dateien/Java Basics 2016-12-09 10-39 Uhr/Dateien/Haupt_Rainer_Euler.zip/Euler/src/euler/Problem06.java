/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 6: Summe-Quadrat-Differenz
 * @author RH
 */
public class Problem06 implements Durchfuehren {

    private String rueckgabe;
    boolean debugMode;

    int summeVonQuadrat;
    int quadratVonSumme;
    int i;

    /**
     * Initialisierung der verwendeten Parameter
     */
    @Override
    public void init() {
        summeVonQuadrat = 0;
        quadratVonSumme = 0;
        rueckgabe = "";
    }

    /**
     * Berechnung von Summe der Quadrate, Quadrat der Summe und der Differenz der beiden
     */
    @Override
    public void calculate() {
        for (i=1;i<=100;i++) {
            summeVonQuadrat += i*i;
        }
        
        for (i=1;i<=100;i++) {
            quadratVonSumme += i;
        }
        quadratVonSumme *= quadratVonSumme;
        
        rueckgabe = Integer.toString(quadratVonSumme-summeVonQuadrat);
    }

    /**
     * Rückgabe der Differenz von Quadratsumme und Summenquadrat
     * @return ruckgabe
     */
    @Override
    public String returnResult() {
        return rueckgabe;
    }

    public String dev() {
        
        
        return rueckgabe;
    }

}
