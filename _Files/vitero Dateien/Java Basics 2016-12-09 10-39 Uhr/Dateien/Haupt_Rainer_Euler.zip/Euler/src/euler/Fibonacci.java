/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Klasse mit Methode zum Umgang mit Fibonacci-Zahlen für Eulerprojekt
 * @author RH
 */
public class Fibonacci {

    /**
     * Summe aller Fibonacci-Zahlen einschließlich des übergebenen Grenzwertes
     * 
     * @param ziel grenzwert
     * @param teiler durch den die Fibonaccizahlen teilbar sein sollen
     * @return fiboSumme int Wert 
     */
    public int summeBis(int ziel, int teiler) {
        int z1 = 0;
        int z2 = 1;
        int z3 = z1 + z2;
        int fiboSumme = 0;

        while (z3 <= ziel) {
            z1 = z2;
            z2 = z3;
            z3 = z1 + z2;
            if (teiler != 0) {
                if (z3 % teiler == 0) {
                    fiboSumme += z3;
                }
            } else {
                fiboSumme += z3;
            }
        }
        return fiboSumme;
    }

    /**
     * Produkt aller Fibonacci-Zahlen einschließlich des übergebenen Grenzwertes
     * 
     * @param ziel Grenzwert bis zu dem die Fibonaccizahlen aufmultipliziert werden sollen
     * @return fiboProdukt long Wert
     */
    public long produktBis(int ziel) {
        int z1 = 1;
        int z2 = 1;
        int z3 = z1 + z2;

        long fiboProdukt = z1 * z2 * z3;
        while (z3 <= ziel) {
            z1 = z2;
            z2 = z3;
            z3 = z1 + z2;
            fiboProdukt *= z3;
        }

        return fiboProdukt;
    }
}
