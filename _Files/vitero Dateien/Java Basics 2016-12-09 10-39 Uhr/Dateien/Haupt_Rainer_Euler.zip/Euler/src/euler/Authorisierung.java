/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Klasse Zur Prüfung der Authorisierung eines Anwenders anhand einer
 * festprogrammierten PIN(checkPin)
 *
 * @author RH
 */
public class Authorisierung {

    private String checkPin = "1611";
    private int versuche;
    private String authorisiert;
    //int pin = 0;

    public Authorisierung() {
        versuche = 1;
        authorisiert = "NO";
    }

    /**
     * Methode überprüft 3 mal auf zulässige PIN und wirft bei nehrfacher
     * Fehleingabe WrongIdException. Der übergebene Eingabe-String wird
     * überprüft ob er sich auf eine Zahl konvertieren lässt und gibt im
     * Fehlerfall eine passende Fehlermeldugn zurück.
     *
     * @param pin zu prüfender PIN-Code
     * @return authorisiert - gibt String mit Zustand zurück OK für authorisiert
     * @throws WrongIdException Exception für mehrmalige falsche Eingabe
     */
    public String checkAuthorisierung(String pin) throws WrongIdException {  //todo pin auf int prüfen
        if (checkPin.equals(pin)) {
            authorisiert = "OK";
        } else if (versuche < 3) {
            System.out.println("Falsche Pin");
            versuche++;
            authorisiert = "NO";
        } else {
            throw new WrongIdException();
        }

        try {
            int zahlPin = Integer.valueOf(pin);
        } catch (java.lang.NumberFormatException ne) {
            System.out.println("Falsches Format, nur Zahlen zugelassen!");
        }
        return authorisiert;
    }
}
