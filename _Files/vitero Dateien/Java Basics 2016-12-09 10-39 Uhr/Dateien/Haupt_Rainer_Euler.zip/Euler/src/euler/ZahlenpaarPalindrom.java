/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Erweiterung des Zahlenpaar um eine Methode zur Überprüfung ob das Produkt 
 * desselben ein Palindrom ist und einen int Wert mit dem Produkt falls dem so ist
 * für Lösung der Problem 4
 * @author RH
 */
public class ZahlenpaarPalindrom extends Zahlenpaar {
    private int produkt = 0;

    public int getProdukt() {
        return produkt;
    }
    public void setProdukt(int produkt) {
        this.produkt = produkt;
    }

    /**
     * Überprüfe ob Produkt des Zahlenpaares ein Palindrom ist
     * @return palindrom - gibt zahlenwert von Palindrom zurück wenn Produkt aus zahl1 und zahl2 ist Palindrom, sonst 0
     */
    public int prodIstPalindrom() {
        int palindrom = 0;
        int prod;
        String prodStr;
        String reverseStr;

        prod = this.zahl1 * this.zahl2;

        if (prod != 0) {
            prodStr = Integer.toString(prod);
            reverseStr = new StringBuffer(prodStr).reverse().toString();
            if (prodStr.equals(reverseStr)) {
                palindrom = prod;
            }
        } else {
            palindrom = 0;
        }

        return palindrom;
    }
}
