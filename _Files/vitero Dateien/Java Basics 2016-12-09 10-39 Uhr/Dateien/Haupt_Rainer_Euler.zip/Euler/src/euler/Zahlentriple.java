/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Zahlentriple für Problem 8 mit den Parametern position, Ziffern und Produkt (der Ziffern)
 * @author rh
 */
public class Zahlentriple {

    private long position;
    private long ziffern;
    private long produkt;

    public Zahlentriple() {
    }

    public Zahlentriple(long position) {
        this.position = position;
    }

    public long getPosition() {
        return position;
    }

    public void setPosition(long position) {
        this.position = position;
    }

    public long getZiffern(){
        return this.ziffern;
    }
    
    public void setZiffern(long ziffern) {
        this.ziffern = ziffern;
    }
    
    public long getProdukt() {
        return produkt;
    }

    public void setProdukt(long produkt) {
        this.produkt = produkt;
    }
}
