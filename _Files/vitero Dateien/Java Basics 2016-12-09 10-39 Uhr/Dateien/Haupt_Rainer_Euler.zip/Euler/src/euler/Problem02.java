/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 2: Summe der geraden Fibonacci Zahlen unter 4 Mio
 * @author RH
 */
public class Problem02 implements Durchfuehren {

    private String rueckgabe;
    boolean debugMode;
    Fibonacci fibo;

    int zahlVergleich;
    int teiler;

    /**
     * Initialisierung der Parameter
     */
    @Override
    public void init() {
        fibo = new Fibonacci();
        debugMode = false;
        rueckgabe = "";
        zahlVergleich = 4000000;
        teiler = 2;
    }

    /**
     * Berechnung der Summe aller geraden Fibonaccizahlen unter 4Mio
     */
    @Override
    public void calculate() {
        rueckgabe = Integer.toString(fibo.summeBis(zahlVergleich, teiler));
    }

    /**
     * Berechneter Wert zum EP 2 wird zurückgegeben
     * @return rueckgabe 
     */
    @Override
    public String returnResult() {
        return rueckgabe;
    }
}
