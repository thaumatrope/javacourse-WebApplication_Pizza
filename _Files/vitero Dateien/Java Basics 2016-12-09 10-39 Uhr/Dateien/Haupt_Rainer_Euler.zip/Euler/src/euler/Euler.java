/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

import java.util.Scanner;

/**
 * Main Klasse für Eulerprojekt Lösung zu einzelne Projekten der Seite
 * www.projecteuler.net. Alle berechneten Ergebnisse wurden auf der Seite 
 * auf Richtigkeit überprüpft.
 *
 * ibb Kurs: Java Basics E-224-1
 *
 * @author RH
 */
public class Euler {

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
         * Deklaration der Variablen in main
         */
        String pin;
        String antwortStr;
        Scanner eingabe;
        Authorisierung auth = new Authorisierung();
        String authStr;
        int problemId;
        boolean loesungGefunden;

        /*
         * Initialisierung der Variablen in main
         */
        antwortStr = "";
        authStr = "";
        loesungGefunden = true;
        eingabe = new Scanner(System.in);
        pin = "";

        /*
         * Authentifizierung (zur Anwendung des Exceptionhandling)
         */
        System.out.println("Zur Aktivierung bitte 4stellige PIN eingeben");
        while (!authStr.equals("OK")) {
            try {
                pin = eingabe.next();
                authStr = auth.checkAuthorisierung(pin);
            } catch (WrongIdException we) {
                System.out.println(we.getMessage());
                return;  //alternativ: System.exit(0);
            }
        }

        /*
         * Haupt Seite der Anwendung: Menü
         */
        System.out.println("Aktuell umgesetzt ist die Ausgabe zu ");
        System.out.println("- Problem 1: Summe der Vielfachen von 3 und 5 unter 1 Mio ");
        System.out.println("- Problem 2: Summe der geraden Fibonacci Zahlen unter 4 Mio ");
        System.out.println("- Problem 3: Bestimmung des groessten Primfaktor der Zahl 600851475143 ");
        System.out.println("- Problem 4: Groesstes Palindrom eines Produktes 2er 3stelliger Zahlen ");
        System.out.println("...");
        System.out.println("- Problem 6: Summe-Quadrat-Differenz ");
        System.out.println("...");
        System.out.println("- Problem 8: Groesstes Produkt einer Reihe ");
        System.out.println("...");
        System.out.println("- Problem 33: Ziffern kürzende Brüche ");
        System.out.println("to be continued ...");
        System.out.println("-------------------");
        System.out.println("Die Antwort zu welchem Euler-Problem willst du anzeigen? ");

        problemId = eingabe.nextInt();
        System.out.println("-------------------");
        System.out.println("Du hast die " + problemId + " gewählt.");

        switch (problemId) {
            case 1:
                Problem01 prob1 = new Problem01();
                prob1.init();
                prob1.calculate();
                antwortStr = prob1.returnResult();
                break;
            case 2:
                Problem02 prob2 = new Problem02();
                prob2.init();
                prob2.calculate();
                antwortStr = prob2.returnResult();
                break;
            case 3:
                Problem03 prob3 = new Problem03();
                prob3.init();
                prob3.calculate();
                antwortStr = prob3.returnResult();
                break;
            case 4:
                Problem04 prob4 = new Problem04();
                prob4.init();
                prob4.calculate();
                antwortStr = prob4.returnResult();
                break;
            case 6:
                Problem06 prob6 = new Problem06();
                prob6.init();
                prob6.calculate();
                antwortStr = prob6.returnResult();
                break;
            case 8:
                Problem08 prob8 = new Problem08();
                prob8.init();
                prob8.calculate();
                antwortStr = prob8.returnResult();
                break;
            case 33:
                Problem33 prob33 = new Problem33();
                prob33.init();
                prob33.calculate();
                antwortStr = prob33.returnResult();
                break;
            default:
                loesungGefunden = false;
        }

        /*
         * Hauptseite der Anwendung: Ausgabe des Ergebnisses
         */
        if (loesungGefunden) {
            System.out.println("-------------------");
            System.out.println("Loesung = " + antwortStr);
        } else {
            System.out.println("-------------------");
            System.out.println("Problem wurde noch nicht umgesetzt ");
        }
    }
}
