/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Klasse mit 2 int -Zahlen, getter- und setter-Methoden und einer Ausgabe des Zahlenpaars als String
 * @author RH
 */
public class Zahlenpaar {
    protected int zahl1 = 0;
    protected int zahl2 = 0;

    public Zahlenpaar() {
    }
    
    public Zahlenpaar(int zahl1, int zahl2) {
        this.zahl1 = zahl1;
        this.zahl1 = zahl2;
    }

    /*
     * Getter und Setter für die Parameter 
     */
    public int getZahl1() {
        return zahl1;
    }

    public void setZahl1(int zahl1) {
        this.zahl1 = zahl1;
    }

    public int getZahl2() {
        return zahl2;
    }

    public void setZahl2(int zahl2) {
        this.zahl2 = zahl2;
    }
    
    /**
     * Anzeige der beiden aktuellen Zahlen
     * @return ausgabe - Zahlenpaar ausgeben als String in Klammern
     */
    public String getZahlenpaarStr(){
        String ausgabe = "(" + Integer.toString(zahl1) + " & " + Integer.toString(zahl2) + ")";
        return ausgabe;
    }
}
