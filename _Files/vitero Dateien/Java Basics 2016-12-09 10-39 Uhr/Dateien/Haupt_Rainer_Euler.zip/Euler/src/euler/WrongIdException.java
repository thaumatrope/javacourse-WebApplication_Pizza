/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Exception für den Authorisierungsvorgang 
 * @author RH
 */
public class WrongIdException extends Exception{
    WrongIdException(){
        super("Nicht zur Nutzung authorisiert!");
    }
}
