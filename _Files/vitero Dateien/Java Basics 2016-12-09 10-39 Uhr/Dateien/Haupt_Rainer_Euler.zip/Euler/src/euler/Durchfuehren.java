/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * Interface zum Einheitlichen Aufbau der Berechnungsklassen für die einzelnen Euler-Probleme
 * @author RH
 */
public interface Durchfuehren {

    /**
     * Initialisierung des Objektes
     */
    public void init();

    /**
     * Berechnung der Antwort für das Eulerproblem
     */
    public void calculate();

    /**
     * Es ist zu gewährleisten, dass Rückgabe zur Anzeige immer als String kommt
     * @return Rueckgabewert 
     */
    public String returnResult();

}
