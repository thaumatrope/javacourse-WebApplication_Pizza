/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 1: Summe aller Vielfacher von 3 und 5 unter 1000
 * @author RH
 */
public class Problem01 implements Durchfuehren {

    private String rueckgabe;
    boolean debugMode;
    int zaehler;
    int ausgabe;

    /**
     * Initialisierung der Parameter
     */
    @Override
    public void init() {
        debugMode = false;
        zaehler = 0;
        ausgabe = 0;
        rueckgabe = "";
    }

    /**
     * Berechnung der Summe aller Vielfacher von 3 und 5 unter 1000
     */
    @Override
    public void calculate() {
        while (zaehler < 1000) {
            if ((zaehler % 3 == 0) || (zaehler % 5 == 0)) {   // || entspricht OR , ^ entspricht XOR
                ausgabe += zaehler;                           // zahl++ entspricht zahl=zahl+1 entspricht zahl+=1
            }
            if (debugMode) {
                System.out.println(" Problem1 - zaehler: " + zaehler);
            }
            zaehler++;
        }
        rueckgabe = Integer.toString(ausgabe);
    }

    /**
     * Rückgabe des berechneten Wertes
     * @return rueckgabe 
     */
    @Override
    public String returnResult() {
        return rueckgabe;
    }
}
