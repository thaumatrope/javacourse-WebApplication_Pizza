/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 33: Ziffern kürzende Brüche
 * @author RainerHaupt
 */
public class Problem33 implements Durchfuehren {

    private String rueckgabe;
    boolean debugMode;

    int a, b, c;
    float abI, bcI, aF, cF;
    float quot1, quot2;
    int zaehler, nenner;
    int q1, q2;

    /**
     * Initialisierung der verwendeten Parameter
     */
    @Override
    public void init() {
        a = 1;
        b = 1;
        c = 1;
        q1 = 1;
        q2 = 1;
        zaehler = 1;
        nenner = 1;
        debugMode = false;
    }

    /**
     * Berechnung für 2stellige Zahlen ohne Ziffer0, zB 20/40 lässt sich auch um eine gemeinsame Ziffer 
     * kürzen und führt zu einem korrekten Ergebnis. Diese trivialen Ergebnisse sind ausgeschlossen.
     */
    @Override
    public void calculate() {
        for (a = 1; a <= 9; a++) {
            for (b = 1; b <= 9; b++) {
                for (c = 1; c <= 9; c++) {
                    abI = Float.valueOf(Integer.toString(a) + Integer.toString(b));//.valueOf(abS);
                    bcI = Float.valueOf(Integer.toString(b) + Integer.toString(c));
                    aF = Float.valueOf(Integer.toString(a));
                    cF = Float.valueOf(Integer.toString(c));
                    quot2 = abI / bcI;
                    quot1 = aF / cF;

                    if ((quot1 - quot2 == 0) && (abI != bcI)) {
                        if (debugMode) {
                            System.out.println("ab " + abI + " :bc " + bcI + ":a " + a + ":c " + c + ":quot2 " + quot2 + ":quot1 " + quot1);
                        }
                        zaehler *= aF;
                        nenner *= cF;
                    }
                }
            }
        }
        if (debugMode) {
            System.out.println("zaehler " + zaehler + " nenner " + nenner);
            System.out.println("zaehler " + zaehler / getGGT(zaehler, nenner)
                    + " nenner " + nenner / getGGT(zaehler, nenner));
        }
        rueckgabe = Long.toString(nenner / getGGT(zaehler, nenner));

    }

    /**
     * Rückgabe des Ergebnisses an aufrufende Klasse
     * return rueckgabe
     */
    @Override
    public String returnResult() {
        return rueckgabe;
    }

    /**
     * Bestimmung des grössten gemeinsamen Teilers 2er Zahlen
     */
    private static long getGGT(long a, long b) {
        if (a == 0) {
            return 1;
        }
        if (a == b) {
            return a;
        } else if (a < b) {
            return getGGT(a, b - a);
        } else {
            return getGGT(a - b, b);
        }
    }
}
