/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 4: Groesstes Palindromprodukt 2er dreistelliger Zahlen
 * @author RH
 */
public class Problem04 implements Durchfuehren {

    private String rueckgabe = "";
    boolean debugMode = true;

    int untergrenze;
    int obergrenze;
    int palindrom;
    int produkt;

    /**
     * Initialisierung der verwendeten Variablen
     */
    @Override
    public void init() {
        untergrenze = 100;
        obergrenze = 999;
        palindrom = 0;
        produkt = 0;
    }

    /**
     * Berechnung des maximalen Palindroms für das Produkt 2er 3stelliger Zahlen
     */
    @Override
    public void calculate() {
        ZahlenpaarPalindrom zp = new ZahlenpaarPalindrom();
        ZahlenpaarPalindrom maxZp = new ZahlenpaarPalindrom();
        int i;
        int j;

        if (debugMode) {
            System.out.println("Vor Schleifen");
        }

        for (i = untergrenze; i <= obergrenze; i++) {
            for (j = untergrenze; j <= obergrenze; j++) {
                zp.setZahl1(i);
                zp.setZahl2(j);
                produkt = zp.prodIstPalindrom();
                if (produkt != 0) {
                    palindrom = Math.max(palindrom, produkt);
                    if ((palindrom == produkt) && (maxZp.getZahl1()!=j)){
                        maxZp.setZahl1(i);
                        maxZp.setZahl2(j);
                        maxZp.setProdukt(palindrom);
                    }
                    if (debugMode) {
                        System.out.print("max Zahlenpaar " + maxZp.getZahlenpaarStr());
                        System.out.print(" mit Produkt " + maxZp.getProdukt());
                        System.out.print(" -- Zahlenpaar " + zp.getZahlenpaarStr());
                        System.out.println(" mit Produkt " + produkt);
                    }
                }
            }
        }
        if (debugMode && (palindrom != 0)) {
            System.out.println("maximales palindrom " + palindrom);
        }
        rueckgabe = Integer.toString(palindrom);
    }

    /**
     * Rückgabe des berechneten Palindroms an die Aufrufstelle
     * @return rueckgabe 
     */
    @Override
    public String returnResult() {
        return rueckgabe;
    }

}
