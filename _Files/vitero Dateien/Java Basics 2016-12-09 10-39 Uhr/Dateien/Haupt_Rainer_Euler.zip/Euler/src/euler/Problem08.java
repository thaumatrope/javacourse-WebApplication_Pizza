/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 8: groesstes Produkts 13 aufeinanderfolgender Ziffern einer 1000 stelligen Ziffernfolge
 * @author RH
 */
public class Problem08 implements Durchfuehren {

    private String zahl = new String();
    private String rueckgabe = "";
    boolean debugMode = false;

    /**
     * Initialisieren eines 1000stelligen String als Abbild der 1000stelligen Zahl
     */
    @Override
    public void init() {
        this.zahl = "73167176531330624919225119674426574742355349194934";
        this.zahl += "96983520312774506326239578318016984801869478851843";
        this.zahl += "85861560789112949495459501737958331952853208805511";
        this.zahl += "12540698747158523863050715693290963295227443043557";
        this.zahl += "66896648950445244523161731856403098711121722383113";
        this.zahl += "62229893423380308135336276614282806444486645238749";
        this.zahl += "30358907296290491560440772390713810515859307960866";
        this.zahl += "70172427121883998797908792274921901699720888093776";
        this.zahl += "65727333001053367881220235421809751254540594752243";
        this.zahl += "52584907711670556013604839586446706324415722155397";
        this.zahl += "53697817977846174064955149290862569321978468622482";
        this.zahl += "83972241375657056057490261407972968652414535100474";
        this.zahl += "82166370484403199890008895243450658541227588666881";
        this.zahl += "16427171479924442928230863465674813919123162824586";
        this.zahl += "17866458359124566529476545682848912883142607690042";
        this.zahl += "24219022671055626321111109370544217506941658960408";
        this.zahl += "07198403850962455444362981230987879927244284909188";
        this.zahl += "84580156166097919133875499200524063689912560717606";
        this.zahl += "05886116467109405077541002256983155200055935729725";
        this.zahl += "71636269561882670428252483600823257530420752963450";
    }

    /**
     * 
     */
    @Override
    public void calculate() {
        Zahlentriple[] zt = new Zahlentriple[988];
        String abschnitt;
        long produktIntern;
        long grProdukt = 0;
        String maxAbschnitt = "";
        long maxPosition = 0;

        for (int i = 0; i <= zt.length - 1; i++) {
            zt[i] = new Zahlentriple(i);
        }
        for (int i = 0; i <= zt.length - 1; i++) {
            produktIntern = 1;
            abschnitt = zahl.substring(i, i + 13);//Long.parseLong(zahl.substring(i, i+13));
            zt[i].setZiffern(Long.parseLong(abschnitt));
            if (debugMode) {
                System.out.print(i + " " + abschnitt + " ");//zahl.substring(i, i+13)
            }
            for (int j = 0; j < 13; j++) {
                produktIntern *= Integer.parseInt(abschnitt.substring(j, j + 1));
                if (debugMode) {
                    System.out.print(abschnitt.substring(j, j + 1) + "/");
                }
            }
            zt[i].setProdukt(produktIntern);

            if (debugMode) {
                System.out.println(produktIntern);
            }
        }

        for (int i = 0; i <= 987; i++) {
            grProdukt = Math.max(grProdukt, zt[i].getProdukt());
            if (grProdukt == zt[i].getProdukt()) {
                maxAbschnitt = Long.toString(zt[i].getZiffern());
                maxPosition = zt[i].getPosition();
                if (debugMode) {
                    System.out.println("Ziffern " + maxAbschnitt + " von Position " + maxPosition + " liefern Produkt " + grProdukt);
                }
            }
        }

        if (debugMode) {
            System.out.print("Ziffern " + maxAbschnitt + " von Position " + maxPosition + " liefern ");
            System.out.println("groesstes Produkt " + grProdukt);
        }
        this.rueckgabe = maxAbschnitt;
    }

    /**
     * Rückgabe des Ergebnisses an aufrufendes Programm
     * return rueckgabe
     */
    @Override
    public String returnResult() {
        return this.rueckgabe;
    }
}
