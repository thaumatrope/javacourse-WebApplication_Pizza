/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euler;

/**
 * EP 3: Groesster Primfaktor für Zahl 600851475143
 * @author RH
 */
public class Problem03 implements Durchfuehren {

    private String rueckgabe = "";
    boolean debugMode = false;

    private long groesste;
    private long faktor;
    private long zahl;

    /**
     * Initialisierung der verwendeten Parameter
     */
    @Override
    public void init() {
        groesste = 1L;
        faktor = 2L;
        zahl = 600851475143L;
    }

    /**
     * Berechnung, Primfaktorzerlegung und Bestimmung des größten Primfaktor
     */
    @Override
    public void calculate() {

        if (debugMode) {
            System.out.print("\t" + zahl + " = ");
        }
        while (faktor * faktor <= zahl) {
            while (zahl % faktor == 0) {
                zahl = zahl / faktor;
                groesste = Math.max(groesste, faktor);
                if (debugMode) {
                    System.out.print("" + faktor + "*");
                    System.out.print("" + faktor + "*");
                }
            }
            faktor++;
        }
        if (debugMode) {
            System.out.println("" + zahl);
        }
        groesste = Math.max(groesste, zahl);
        rueckgabe = Long.toString(groesste);
    }

    /**
     * Berechneten Wert als String an aufrufende Klasse zurück
     * @return rueckgabe
     */
    @Override
    public String returnResult() {
        return rueckgabe;
    }

}
