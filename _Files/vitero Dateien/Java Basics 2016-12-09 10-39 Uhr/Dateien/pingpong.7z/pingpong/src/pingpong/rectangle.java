/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 
 

/**
 *
 * @author Teilnehmer2
 */
 
package pingpong ;

 import packagepp.* ;
 
 
 
public class rectangle  extends figure  {
  
   
 // dimensions of rectangle   
    
    float a ;
    float b ;
    
   
    public  rectangle (float c1, float c2 , float s1, float s2, String color, float a,
            float b )
    {
      super ( c1, c2, s1, s2,  color) ;
        this.a = a ;
        this.b = b ;
       
              } 
    
    
    
    public float geta ()
    { return a ; }
    
    public float getb ()
    { return b ; }

    public void seta (float newa)
    {  a = newa ; }
    
 public void setb (float newb)
    {  a = newb ; }
    



public void resize (float p , float q)
 {
     if( region(p,q) == true )  
 
     {    a =  1.1f*a ;
         b = 1.1f*b ;   }
       
        else
 
     {       a = 0.8f*a ;
         b =  0.8f*b ;     }
         
 }

   public void simulation (int steps ,float p, float q) {
 
      for ( int i = 1; i<= steps; i++) 
    {
         
     
     if (  Math.abs(c1) < p & Math.abs(c2) < q)    
     
     move() ;
     
     else 
     {
         setcoordinate(c1-s1,c2-s2 ) ;
         reflect(p,q);
          resize(p,q);
    }
      }
  }

}




