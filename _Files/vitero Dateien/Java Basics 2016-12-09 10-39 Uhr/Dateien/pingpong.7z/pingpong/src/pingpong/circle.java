package pingpong ;

 import packagepp.* ;
 
 
 
public class circle  extends figure  {
  
   
    
    
    float r ;
    
    
   
    public  circle (float c1, float c2 , float s1, float s2, String color, float r )
            
    {  super ( c1, c2 , s1, s2,   color) ;
        this.r = r ;
        
       
              } 
    
    
    
    public float getr ()
    { return r ; }
    
  
    public void setr (float newr)
    {  r = newr ; }
    
 public void resize (float p , float q)
 {
     if( region(p,q) == true )  
 
     {    r =  1.1f*r ;
            }
       
        else
 
     {       r = 0.8f*r ;
              }
         
 }
 
public void simulation (int steps ,float p, float q) {
 
      for ( int i = 1; i<= steps; i++) 
    {
         
     
     if (  Math.abs(c1) < p & Math.abs(c2) < q)    
     
     move() ;
     
     else 
     {
         setcoordinate(c1-s1,c2-s2 ) ;
         reflect(p,q);
          resize(p,q);
    }
      }
  }
}




