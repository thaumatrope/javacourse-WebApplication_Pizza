/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

/**
 *
 * @author IBB Teilnehmer
 */
public class ExceptionFileNotFound extends Exception {

//    public ExceptionFileNotFound() {
//        super();
//    }

    public ExceptionFileNotFound(String message) {
        super(message);
    }
}
