/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamefx;

/**
 * Class for size data. 
 * Member variables are public on purpose, for easy access.
 * Member variables have short names on purpose, for easy access.
 * 
 * @author Robert
 */
public class Size {
    
    // width
    public int w;
    
    // height
    public int h;
    
    public Size(int w, int h)
    {
        this.w = w;
        this.h =h;
    }
}
