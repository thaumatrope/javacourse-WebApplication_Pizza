/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chars;

import java.util.Vector;

/**
 * Die Überklasse für alles was kreucht und fleucht und Käckerchen macht...
 * @author Teilnehmer
 */
public class Chars 
{
    String name; // Der Name des Chars
    String haare; // Die Fell-/ Oder Haarfarbe des Chars
    String augen; // Die Augenfarbe des Chars
    boolean hostile; // Gibt an, ob der Char feindseelig ist.
    int hp; // Die Hitpoints
    int st; // Die Stärke
    int maxHp; //Die maximalen hitpoints
    
    /**
     * Gibt dem Char seine Eigenschaften
     * @param name Der Name
     * @param haare Die Haar/Fellfarbe
     * @param augen Die Augen
     * @param hostile Ist der Char feindseelig?
     * @param hp die hitpoints
     * @param st die stärke
     * @param maxhp die maximalen hp
     */
    public Chars(String name, String haare, String augen, boolean hostile,int hp,int st,int maxhp)
    {
        this.name=name;
        this.haare=haare;
        this.augen=augen;
        this.hostile =hostile;
        this.hp = hp;
        this.st = st;
        this.maxHp = maxhp;
        
    }
    /**
     * gibt den Namen zurück
     * @return name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * gibt die Fell-/Haarfarbezurück
     * @return haare
     */
    public String getHaare()
    {
        return haare;
    }
    
    /**
     * Gibt die augenfarbe zurück
     * @return augen
     */
    public String getAugen()
    {
        return augen;
    }
    /**
     * Gibt den Wert zurück ob dert char feindseelig ist.
     * @return hostile
     */
    public boolean getHostile()
    {
        return hostile;
    }
    /**
     * Gibt die hp zurück.
     * @return hp
     */
    public int getHp()
    {
        return hp;
    }
    /**
     * Gibt die Stärke zurück.
     * @return st
     */
    public int getSt()
    {
        return st;
    }
    /**
     * gibt die Maxhp zurück
     * @return maxHp
     */
    public int getMaxHp()
    {
        return maxHp;
    }
    
    /**
     * heilt den charakter um den faktor
     * @param factor 
     */
    public void heal(int factor)
    {
        
        hp+=factor;
    }
    /**
     * verletzt den charakter um den faktor
     * @param factor 
     */
    public void hit(int factor)
    {
        
      hp-=factor;
    }
    
    /**
     * verstärkt den charakter um den faktor
     * @param factor 
     */
    public void stronger(int factor)
    {
        st+=factor;
    }
    
    /**
     * schwächt den charakter um den faktor
     * @param factor 
     */
    public void weaker(int factor)
    {
        
        st-=factor;
    }
    
    public void moreMaxHp(int factor)
    {
        maxHp+=factor;
    }
}
