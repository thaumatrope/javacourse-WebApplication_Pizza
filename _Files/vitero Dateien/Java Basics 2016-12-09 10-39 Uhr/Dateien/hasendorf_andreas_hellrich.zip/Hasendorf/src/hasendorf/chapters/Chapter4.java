/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.fightingSystem.Fight;
import hasendorf.chars.Gegner;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;
/**
 * Das vierte Kapitel
 * @author Teilnehmer
 */
public class Chapter4 extends Chapters implements CanBeTold
{
    /**
     * legt das vierte Kapitel an
     */
    public Chapter4()
    {
        
    id =4;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        
	Create gegner = new Create();
        Gegner baer = gegner.gegner()[1];
	Spieler spieler = gibdas.getSpieler();
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String baerText = dict.get("Bär").toString();
        String harryText = dict.get("Harry").toString();
	System.out.println(gibdas.getHasGem());	
        story = "*****************************************************************\n";
        story += "Du hast den Biber seinem Schicksal überlassen und gehst weiter.\n";
        story += "Du kommst an einer Höhle an.\n";
        story += "Vor der Höhle steht ein Bär.\n";
        story += "Er hat "+baer.getHaare()+"Fell und "+baer.getAugen()+"Augen.";
        story += "\nEr begrüßt dich mit "+baer.talk(baerText);
        if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
       
        story += "\n_________________________________________________________________";
              
        
    
    }
    
    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Rückgabe zurück
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        this.setStory(gibdas);
        System.out.println(this.getStory());
        Fight fight = new Fight(gibdas,2);
	fight.fight(gibdas,2);
        System.out.println("Du hast den Bären besiegt und gehst weiter.");
	
        // Auf zum nächsten Kapitel!
        Chapter5 chap5 = new Chapter5();
	gibdas = chap5.tell(gibdas);
        return gibdas;
         
    
    }
    
    
}
