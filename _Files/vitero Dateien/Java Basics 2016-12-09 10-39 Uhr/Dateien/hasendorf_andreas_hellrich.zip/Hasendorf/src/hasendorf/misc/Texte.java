/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.misc;

import java.util.HashMap;
import java.util.Map;

/**
 *Dient zum Laden der Texte
 * @author Teilnehmer
 */
public class Texte 

{
    /**
     * Hier werden die einzelnen Texte angelegt.
     * @return Die Map in der die Texte gespeichert sind.
     */
    public Map texteLaden()
    {
        Map dict = new HashMap();
        // Texte für Spieler
        dict.put("Harry","\"Mein Name ist Hase, ich weiß von nichts!\"");
        dict.put("Peter","\"Ich bin der coolste Hase vom Hasendorf!\"");
        
        // Texte für Gegner
        dict.put("Igel","\"Jetzt wirds stachelig!\"");
        dict.put("Bär","\"Jetzt wirds brummig!!\"");
        dict.put("Ork","\"Mhhh gleich gibts Hasenbraten!!\"");
        dict.put("Hund", "Wau! Wau!");
        
        //Texte für NPCsvers
        dict.put("Biber","\"Hallölinger!\"");
        dict.put("Eichhörnchen","\"Hallo auch!\"");
        dict.put("Alter Mann","\"Ho ho ho komm mal her du, lass uns reden!\"");
        dict.put("gute Fee","\"Na du süßer?\"");
        dict.put("Mäuschen","\"Piep piep pieeeeeep!!!!!!\"");
        return dict;
    }
}
