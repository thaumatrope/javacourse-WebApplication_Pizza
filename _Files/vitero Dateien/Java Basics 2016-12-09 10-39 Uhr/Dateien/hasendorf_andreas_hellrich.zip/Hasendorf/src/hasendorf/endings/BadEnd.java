/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.endings;

import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import java.util.Scanner;

/**
 *Dient dazu das Ending auszugeben
 * @author Teilnehmer
 */
public class BadEnd extends Endings implements CanBeTold
{
     /**
     * gibt das BadEnd (Game Over) aus
     * @param got die Standardübergabe
     * @return gibt die Übergabe zurück. Eigentlich nicht nötig aber wegen Interface.
     */
    @Override
    public Uebergabe tell(Uebergabe got)
    {
        System.out.println("Du bist Tot.");
        System.out.println("Prinzessin Stummelschwanz bleibt verschwunden.");
        System.out.println("Der König ist traurig.");
        System.out.println("Alle sind traurig.");
        System.out.println("Versuch es noch mal!");
        System.out.println("Ich glaub an dich!");
       return got;
    }
}
