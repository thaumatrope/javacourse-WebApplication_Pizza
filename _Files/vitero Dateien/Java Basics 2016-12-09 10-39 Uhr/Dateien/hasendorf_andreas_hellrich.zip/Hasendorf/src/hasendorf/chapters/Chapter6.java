/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.fightingSystem.Fight;
import hasendorf.chars.Gegner;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;
/**
 * Das sechste Kapitel
 * @author Teilnehmer
 */
public class Chapter6 extends Chapters implements CanBeTold
{
    /**
     * legt das sechste Kapitel an
     */
    public Chapter6()
    {

		id =6;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        Create gegner = new Create();
        Gegner ork = gegner.gegner()[2];
        Spieler spieler = gibdas.getSpieler();
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String orkText = dict.get("Ork").toString();
        String harryText = dict.get("Harry").toString();
        
        story = "*****************************************************************\n";
        story += "Du siehst einen großen  "+ork.getName()+ ". \n Er hat "+ork.getHaare()+", seine Augen sind "+ork.getAugen()+".";
        story +="Er begrüßt dich mit den Worten: \n"+ork.talk(orkText);
        if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
        
        }

    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Übergabe wieder aus.
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        
        //Story wird angelegt
        this.setStory(gibdas);
        System.out.println(this.getStory());
        
	Fight fight = new Fight(gibdas,3);
	fight.fight(gibdas,3);
	    
	// Auf zum nächsten Kapitel!	
        Chapter7 chap7 = new Chapter7();
	gibdas = chap7.tell(gibdas);
        return gibdas;
                
        }  




    


}
