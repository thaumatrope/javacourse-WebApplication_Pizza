/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.chars.NPC;
import hasendorf.chars.Spieler;
import hasendorf.endings.BadEnd;
import hasendorf.misc.Uebergabe;
import java.util.Scanner;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;
/**
 * Das dritte Kapitel
 * @author Teilnehmer
 */
public class Chapter3 extends Chapters implements CanBeTold
{
    /**
     * legt das dritte Kapitel an
     */
    public Chapter3()
    {
        
    id =3;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        
		Create others = new Create();
                Spieler spieler = gibdas.getSpieler();
        NPC biber = others.others()[1];
	String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String biberText = dict.get("Biber").toString();
        String harryText = dict.get("Harry").toString();
                
               
	
        story = "*****************************************************************\n";
        story += "Mit dem Schwert in der Hand gehst du nun weiter an einem Fluss entlang.\n";
        story += "Du begnest einem Biber!";
        story += "Er hat "+biber.getHaare()+"Fell und "+biber.getAugen()+"Augen.";
        story += "\nEr begrüßt dich mit "+biber.talk(biberText);
        if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
        story += "\nEr fragt: \"Hilfst du mir meinen Damm zu bauen?\"";
        story += " Hilfst du ihm bauen?\n";
        story += "Wenn du helfen willst, dann gib ja ein, ansonsten etwas anderes!\n";
        story += "_________________________________________________________________";
              
        
    
    }
    
    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Rückgabe zurück
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        //Scanner wird angelegt
        Scanner ein = new Scanner(System.in);
        //Story wird angelegt
        this.setStory(gibdas);
        System.out.println(this.getStory());
        //Fragt ab ob man hilft
        if (ein.next().contains("ja")) // Wenn man ihm hilft
        {
            System.out.println("Du ertrinkst beim Dammbauen!");
            System.out.println("Game over!");
            BadEnd bad = new BadEnd();
            bad.tell(gibdas);
            
        }
        
        else  // wenn man nicht hilft
        {
            
            System.out.println("Der Biber sagt: Na gut, dann muss ich eben allein zurrecht kommen!");
            
            
        }  
        
       // Auf zum nächsten Kapitel!
	Chapter4 chap4 = new Chapter4();
	gibdas = chap4.tell(gibdas);
        return gibdas;
         
    
    }
    
    
}
