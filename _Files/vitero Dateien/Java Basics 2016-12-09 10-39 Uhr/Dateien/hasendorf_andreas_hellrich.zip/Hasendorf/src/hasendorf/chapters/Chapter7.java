/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.chars.NPC;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import java.util.Scanner;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;
/**
 * Das siebte Kapitel
 * @author Teilnehmer
 */
public class Chapter7 extends Chapters implements CanBeTold
{
    /**
     * legt das siebte Kapitel an
     */
    public Chapter7()
    {
        
    id =7;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        
	Create others = new Create();
        NPC guteFee = others.others()[3];
	Spieler spieler = gibdas.getSpieler();
                
        
                
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String gutefeeText = dict.get("gute Fee").toString();
        String harryText = dict.get("Harry").toString();
		
        story = "*****************************************************************\n";
        story += "Du siehst eine wunderschöne "+guteFee.getName()+ ". \nSie hat "+guteFee.getHaare()+" Haare und  "+guteFee.getAugen()+" Augen.";
        story += "\nEs begrüßt dich mit "+guteFee.talk(gutefeeText);
        
       if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
        
        story += "\nSie lächelt dich an.";
        story += "\n Hilfst du ihm suchen?\n";
        story += "Sie sagt du hast einen Wunsch frei.\n";
        story += "Wenn du mehr Leben willst, dann drücke 1, \nwenn du mehr Kraft willst dann drücke etwas anderes.";
        story += "\n_________________________________________________________________";
              
        
    
    }
    
    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Rückgabe zurück
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        //Scanner wird angelegt
        Scanner ein = new Scanner(System.in);
        //Story wird angelegt
        this.setStory(gibdas);
        System.out.println(this.getStory());
        //Fragt ab ob man hilft
        if (ein.next().contains("1")) // Wenn man ihm hilft
        {
            System.out.println("Die gute Fee gewährt dir deinen Wunsch.");
            Spieler spieler = gibdas.getSpieler();
            spieler.moreMaxHp(25); // Man wird mit einem Edelstein belohnt
            System.out.println("Deine maximale Gesundheit steigt um 25.");
            System.out.println("Sie beträgt nun: "+spieler.getMaxHp());
        }
        
        else  // wenn man nicht hilft
        {
            
            System.out.println("Die gute Fee gewährt dir deinen Wunsch");
            Spieler spieler = gibdas.getSpieler();
            spieler.stronger(7); // Man wird mit einem Edelstein belohnt
            System.out.println("Deine Kraft steigt um 7.");
            System.out.println("Sie beträgt nun: "+spieler.getSt());
            
        }  
        // Auf zum nächsten Kapitel!
	Chapter8 chap8 = new Chapter8();
	gibdas = chap8.tell(gibdas);
        return gibdas;
         
    
    }
    
    
}
