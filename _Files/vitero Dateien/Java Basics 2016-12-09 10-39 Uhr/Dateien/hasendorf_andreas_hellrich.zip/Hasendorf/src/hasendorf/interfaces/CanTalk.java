/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.interfaces;



/**
 * Dient dazu zu sprechen
 * @author Teilnehmer
 */
public interface CanTalk 
{
    /**
     * Gibt das was gesagt wird zurück
     * @param texte das was gesagt wird
     * @return das was gesagt wird
     */
    public String talk(String texte);
}
