/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chars;

import hasendorf.interfaces.CanTalk;
import hasendorf.chars.Chars;

/**
 * Die Spielerklasse
 * @author Teilnehmer
 */
public class Spieler extends Chars implements CanTalk
{
    /**
     * Der Spieler wird als Char angelegt
     * @param name Der Name
     * @param haare Die Haar-/Fellfarbe
     * @param augen Die Augenfarbe
     * @param hostile Gibt an ob der Char feindseelig ist.
     * @param hp die hp
     * @param st die Stärke
     * @param maxhp die maxhp
     */
    public Spieler (String name, String haare, String augen, boolean hostile,int hp,int st,int maxhp)
    {
        //Der Konstruktor der Charsklasse wird benutzt
        super(name,haare,augen,hostile,hp,st,maxhp);
        
    }
    /**
     * legt die Begrüßung fest
     * @param texte der Text
     * @return gibt die Begrüßung aus
     */
    @Override
    public String talk(String texte)
    {
        String says = texte;
        return says;
    }
    
    
}
