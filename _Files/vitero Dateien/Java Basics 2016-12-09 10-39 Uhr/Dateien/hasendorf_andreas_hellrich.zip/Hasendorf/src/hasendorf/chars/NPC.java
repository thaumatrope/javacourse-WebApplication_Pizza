/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chars;

import hasendorf.interfaces.CanTalk;

/**
 * Die Klasse für andere Charaktäre
 * @author Teilnehmer
 */
public class NPC extends Chars implements CanTalk
{
    /**
     * 
     * Der Charakter wird angelegt
     * @param name Der Name
     * @param haare Die Haar-/Fellfarbe
     * @param augen Die Augenfarbe
     * @param hostile Gibt an, ob der Charakter feindseelig ist
     * @param hp die HP
     * @param st die Stärke
     * @param maxhp die maximalen HP
     */
    public NPC (String name, String haare, String augen,boolean hostile, int hp, int st, int maxhp)
    {
         //Der Konstruktor der Charsklasse wird benutzt
        super(name,haare,augen,hostile,hp,st,maxhp);
        
        
    }
    /**
     * legt die Begrüßung fest
     * @param texte der Text
     * @return gibt die Begrüßung aus
     */
    @Override
    public String talk(String texte)
    {
        String says = texte;
        return says;
    }
}
