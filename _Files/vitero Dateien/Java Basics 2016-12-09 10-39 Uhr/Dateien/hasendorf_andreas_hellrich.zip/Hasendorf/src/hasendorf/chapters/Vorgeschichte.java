/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Charwahl;
import hasendorf.chars.Hasen;
import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;

/**
 *
 * @author Teilnehmer
 */
public class Vorgeschichte extends Chapters implements CanBeTold
{
    public Vorgeschichte()
    {
        
    id =2;
    }
    /**
     * Legt die Story für die Vorgeschichte fest.
     * @param gibdas Die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        //Hier wird der Story String festgelegt
        story = "_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-\n";
        //Ab hier wird er erweitert.
        story += "         W I L L K O M M E N   I M   H A S E N D O R F!\n";
        story += "-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-\n";
        story += "_________________________________________________________________\n";
        story += "Die anmutige Prinzessin Stummelschwanz wurde entführt!\n";
        story += "Doch zum Glück gibt es in dem Dorf tapfere Helden!\n";
       // Die Hasen werden aus der Übergabe ausgelesen.
        Hasen[] bunnys = gibdas.getBunnys();
        // Hier wird der story string erweitert.
        story +="-----------------------------------------------------------------\n";
        story += bunnys[0].getName()+" hat "+bunnys[0].getHaare()+" Fell und "+bunnys[0].getAugen()+" Augen.\n";     
        story += bunnys[1].getName()+" hat "+bunnys[1].getHaare()+" Fell und "+bunnys[1].getAugen()+" Augen.\n";
        story +="Harry hält mehr aus, Peter schlägtfester zu.\n";
        story +="-----------------------------------------------------------------\n";
        
        
        
        
                
        
        
        
        
        
    
    }
    /**
     * Verwaltet das Erzählen der Vorgeschichte
     * @param gibdas 
     */
    public Uebergabe tell(Uebergabe gibdas)
    {
        //Legt die Story fest
        this.setStory(gibdas);
        
        //Gibt die Story aus
        System.out.println(this.getStory());
        //Hier wählt der Spieler den Charakter
        Charwahl charwahl = new Charwahl();
        Uebergabe ueber = charwahl.choose(gibdas);
	   
		return ueber;
    }
    
    
    
}
