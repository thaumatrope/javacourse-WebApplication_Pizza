/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Uebergabe;

/**
 *Die Kapitelverwaltung
 * @author Teilnehmer
 */
public class Chapters 
{
     int id;
    String story;
    
    /**
     * gibt die Id des Kapitels zurück
     * @return id
     */
    public final int getId()
    {
        return id;
    }
    
    /**
     * gibt die Story zurück
     * @return story
     */
    public String getStory()
    {
        
        return story;
    }
    
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    public void setStory(Uebergabe gibdas)
    {
       
    
    }
}


