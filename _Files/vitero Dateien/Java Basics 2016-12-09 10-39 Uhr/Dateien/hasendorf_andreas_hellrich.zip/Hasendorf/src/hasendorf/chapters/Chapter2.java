/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.fightingSystem.Fight;
import hasendorf.chars.Gegner;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;
/**
 * Das zweite Kapitel
 * @author Teilnehmer
 */
public class Chapter2 extends Chapters implements CanBeTold
{
    /**
     * legt das zweite Kapitel an
     */
    public Chapter2()
    {

		id =2;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        Create gegner = new Create();
        Gegner igel = gegner.gegner()[0];
        Spieler spieler = gibdas.getSpieler();
        
        story = "*****************************************************************\n";
        story +="Als nächstes begegnet dir ein "+igel.getName()+ ".\ner hat "+igel.getHaare()+" Fell und "+igel.getAugen()+ " Augen.";
        
        
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String igelText = dict.get("Igel").toString();
        String harryText = dict.get("Harry").toString();
        
        story +="\nEr begrüßt dich mit den Worten: \n"+igel.talk(igelText);
        if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
        
        }

    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Übergabe wieder aus.
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        
        
        //Story wird angelegt
        this.setStory(gibdas);
        System.out.println(this.getStory());
        
	Fight fight = new Fight(gibdas,1);
	fight.fight(gibdas,1);
	System.out.println("Ein weiterer Igel taucht auf!");
        System.out.println("_________________________________________________________________");
        ;
		
	Gegner gegner = gibdas.getGegner()[0];
	gegner.heal(gegner.getMaxHp());
	fight.fight(gibdas,1);
	System.out.println("Du findest ein Schwert!");
	System.out.println("Deine Stärke steigt um 3!");
	Spieler spieler = gibdas.getSpieler();
	spieler.stronger(3);
	System.out.println("Deine Stärke beträgt jetzt: "+spieler.getSt());
	
        // Auf zum nächsten Kapitel!
        Chapter3 chap3 = new Chapter3();
	gibdas = chap3.tell(gibdas);
        return gibdas;
                
        }  




    


}
