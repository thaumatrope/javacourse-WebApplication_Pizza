/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.misc;

import hasendorf.chars.Spieler;
import hasendorf.chars.Gegner;
import hasendorf.chars.NPC;
import hasendorf.chars.Hasen;


/**
 *Hier wird verschiedenstes angelegt
 * @author Teilnehmer
 */
public class Create 
{
    /**
     * Die Hasen werden angelegt
     * @return und zurückgegeben
     */
    public Hasen[] hasen()
    {
        Hasen[] bunnies = new Hasen[3];
        bunnies[0] = new Hasen("Harry Hoppel","weißes","rote",false,150,10,150);
        bunnies[1] = new Hasen("Peter Puschel","braunes","schwarze",false,130,15,130);
        bunnies[2] = new Hasen("Prinzessin Stummelschwanz", "schwarz-weißes","braune",false,5,1,5);
        return bunnies;   
        
    }
    
    
    
    /**
     * Der Spieler wird angelegt
     * @param wahl Der gewählte Hase
     * @param bunnys Die wählbaren Hasen
     * @return gibt den Spieler zurück
     */
    public Spieler spieler(String wahl, Hasen[] bunnys)
    {
        
        // Wenn Harry gewählt wurde
        if (wahl.contains("Harry"))
        {
            Spieler spieler = new Spieler(bunnys[0].getName(),bunnys[0].getHaare(),bunnys[0].getAugen(),bunnys[0].getHostile(),bunnys[0].getHp(),bunnys[0].getSt(),bunnys[0].getMaxHp());
            return spieler;
            
        }
        
        // Wenn Peter gewählt wurde
        else
        {
            Spieler spieler = new Spieler(bunnys[1].getName(),bunnys[1].getHaare(),bunnys[1].getAugen(),bunnys[1].getHostile(),bunnys[1].getHp(),bunnys[1].getSt(),bunnys[1].getMaxHp());
            return spieler; 
        }
        
          
        
    }
   
    /**
     * Legt das Eichhörnchen an. 
     * @return gibt das Eichhörnchen aus
     */
    public NPC[] others()
    {
        
        NPC[] npcs = new NPC[5];
        npcs[0] = new NPC("Eichhörnchen","braun","schwarz",false,30,2,30);
        npcs[1] = new NPC("Biber","braunes","braune",false,40,5,40);
        npcs[2] = new NPC("Alter Mann","glatzenartige","eisblaue",false,40,5,40);
        npcs[3] = new NPC("gute Fee","glänzende", "silberne",false,90,60,90);
        npcs[4] = new NPC("Mäuschen","mausgraues", "kleine",false,2,2,2);
        return npcs;
    }
    
    /**
     * Gibt die Gegner zurück
     * @return gegner
     */
    public Gegner[] gegner()
    {
        Gegner[] gegner = new Gegner[4];
        gegner[0] = new Gegner("Igel","stacheliges","schwarze",true,40,5,40);
        gegner[1] = new Gegner("Bär", "zotteliges", "scwharze",true,50,21,50);
        gegner[2] = new Gegner("Ork", "kein", "rote",true,70,17,70);
        gegner[3] = new Gegner("Hund", "struppiges", "wütende",true,65,18,65);
                
        
        return gegner;
    }
    
    
    
    
    
}
