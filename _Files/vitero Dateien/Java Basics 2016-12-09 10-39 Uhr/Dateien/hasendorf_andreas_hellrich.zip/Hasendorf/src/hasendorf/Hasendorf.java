/*
 ****************************
 *       Hasendorf by       *
 *     Andreas Hellrich     *
 ****************************
 *   ALL RIGHTS RESERVED!   *
 *    Copyright 12 MMXVI    *
 ****************************
 */
package hasendorf;

import hasendorf.misc.Uebergabe;
import hasendorf.misc.Create;
import hasendorf.chars.Gegner;
import hasendorf.chars.NPC;
import hasendorf.chapters.Vorgeschichte;
import hasendorf.chars.Hasen;



/**
 * Die Hauptklasse
 * @author Teilnehmer
 */
public class Hasendorf {

    /**
     * Die Main Methode
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        
        // Ein Objekt der Create Klasse wird angelegt
        Create create=new Create(); 
        
        //Die Hasen werden angelegt
        Hasen[] bunnys = create.hasen();
        
        //Die NPCs werden angelegt
        NPC[] others = create.others();
        
        //Die Gegner werden angelegt
        Gegner[] gegner = create.gegner();
		
		
		
        
        //Eine Dummy Übergabe wird angelegt
        Uebergabe gibDas = new Uebergabe("Chuck Norris",bunnys,false,others,gegner);
        
        //Die Vorgeschichte wird angelegt
        Vorgeschichte vorgeschichte = new Vorgeschichte();
        
        //Die Vorgeschichte wird erzählt
        vorgeschichte.tell(gibDas);
		
        
        
        
        
                
        
    }
    
}
