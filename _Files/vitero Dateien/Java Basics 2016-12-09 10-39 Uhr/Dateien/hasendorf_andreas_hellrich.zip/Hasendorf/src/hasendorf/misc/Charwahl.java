/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.misc;


import hasendorf.chapters.Chapter1;
import hasendorf.chars.Hasen;
import hasendorf.chars.Spieler;

import java.util.Scanner;


/**
 *Hier wird der Hase gewählt
 * @author Teilnehmer
 */
public class Charwahl {
    
    /**
     * Dient der Auswahl des Chars
     * @param gibdas Die übliche Übergabe
     * @return gibt die Übergabe mit dem gewählten Chars aus
     */
    public Uebergabe choose(Uebergabe gibdas)
    {
       // Hasen werden eingeladen
        Hasen[] bunnys = gibdas.getBunnys();
        // Scanner für eingabe wird angelegt
        Scanner ein = new Scanner(System.in);
        // Es wird gefragt wen man spielen will
        System.out.println("Welchen Hasen willst du spielen? \n > Gib Harry ein: für "+bunnys[0].getName()+" \n > oder Gib Peter ein: für "+bunnys[1].getName());
        System.out.println("_________________________________________________________________");
        // Die Eingabe wird gelesen
        String wahl = ein.next();
        // Ein strich wird ausgegeben... wow... kann Java nicht tolle sachen? XD
        System.out.println("_________________________________________________________________");
        
        // Wenn der Spieler Harry oder Peter eingibt
        if (wahl.contains("Harry") || wahl.contains("Peter"))
            
        {
        Create player = new Create();
        Spieler spieler = player.spieler(wahl,bunnys);
        System.out.println("Du spielst also "+spieler.getName()+ "!");
        Uebergabe herdamit = new Uebergabe(spieler, bunnys, gibdas.getHasGem(), gibdas.others, gibdas.gegner );
        System.out.println(herdamit.getSpieler().getName());
        
        System.out.println("Dein Abenteuer beginnt!");
        Uebergabe gibDas = herdamit;
        Chapter1 chap1 = new Chapter1();
        gibDas = chap1.tell(gibDas);
		return gibDas;
            
        }
        
        // Wenn der Spieler zu unfähig ist Harry oder Peter einzugeben
        else 
        {
            System.out.println("Dieser Hase steht leider nicht zur Wahl!");
            // Schleifen sind Out! Selbstaufrufende Funktionen sind der neue Top-Hit!
            Charwahl charwahl = new Charwahl();
            Uebergabe gibdasher = charwahl.choose(gibdas);
			
            return gibdasher;
        }
        
       
    }
    
}

