/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.chars.NPC;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import java.util.Scanner;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;
/**
 * Das erste Kapitel
 * @author Teilnehmer
 */
public class Chapter1 extends Chapters implements CanBeTold
{
    /**
     * legt das erste Kapitel an
     */
    public Chapter1()
    {
        
    id =1;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        
	Create others = new Create();
        NPC eichhörnchen = others.others()[0];
	Spieler spieler = gibdas.getSpieler();
                
        
                
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String eichhText = dict.get("Eichhörnchen").toString();
        String harryText = dict.get("Harry").toString();
		
        story = "*****************************************************************\n";
        story += "Du siehst ein nettes "+eichhörnchen.getName()+ ". \nSein Fell ist "+eichhörnchen.getHaare()+", seine Augen sind "+eichhörnchen.getAugen()+".";
        story += "\nEs begrüßt dich mit "+eichhörnchen.talk(eichhText);
        
       if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
        
        story += "\nEs hat seine Nuss verloren.";
        story += " Hilfst du ihm suchen?\n";
        story += "Wenn du helfen willst, dann gib ja ein, ansonsten etwas anderes!\n";
        story += "_________________________________________________________________";
              
        
    
    }
    
    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Rückgabe zurück
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        //Scanner wird angelegt
        Scanner ein = new Scanner(System.in);
        //Story wird angelegt
        this.setStory(gibdas);
        System.out.println(this.getStory());
        //Fragt ab ob man hilft
        if (ein.next().contains("ja")) // Wenn man ihm hilft
        {
            System.out.println("Das Eichhörnchen freut sich sehr, dass du ihm\ngeholfen hast und schenkt dir einen Edelstein!");
            gibdas.setHasGem(true); // Man wird mit einem Edelstein belohnt
            
        }
        
        else  // wenn man nicht hilft
        {
            
            System.out.println("Das Eichhörnchen läuft beleidigt weg.");
            gibdas.setHasGem(false); // Unfreundliche Hasen kriegen keine Edelsteine
            
        }  
        // Auf zum nächsten Kapitel!
	Chapter2 chap2 = new Chapter2();
        
	gibdas = chap2.tell(gibdas);
        return gibdas;
         
    
    }
    
    
}
