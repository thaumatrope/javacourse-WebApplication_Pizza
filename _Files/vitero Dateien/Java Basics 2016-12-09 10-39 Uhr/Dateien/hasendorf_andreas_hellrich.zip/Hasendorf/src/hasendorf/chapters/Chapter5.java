/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.chars.NPC;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import java.util.Scanner;
import hasendorf.interfaces.CanBeTold;
import java.util.InputMismatchException;
import java.util.Map;
/**
 * Das fünfte Kapitel
 * @author Teilnehmer
 */
public class Chapter5 extends Chapters implements CanBeTold
{
    /**
     * legt das fünfte Kapitel an
     */
    public Chapter5()
    {
        
    id =5;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        
	Create others = new Create();
        NPC alterMann = others.others()[2];
	Spieler spieler = gibdas.getSpieler();
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String amText = dict.get("Alter Mann").toString();
        String harryText = dict.get("Harry").toString();
                
                
		
        story = "*****************************************************************\n";
        story += "Du begegnest in der Höhle einem bärtigen alten Mann.\n Er riecht irgendwie nach Schnaps.\n";
        story += "Er hat "+alterMann.getHaare()+"Haare und "+alterMann.getAugen()+"Augen.";
        story += "\nEr begrüßt dich mit "+alterMann.talk(amText);
        if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
        story += "\nEr lacht wegen deiner witzigen Antwort.";
        story += "\nEr sagt: Ich stelle dir nun ein Rätsel:";
        story += "\nWas ist die Anwort auf das Leben, das Universum und den ganzen Rest?\n";
        story += "_________________________________________________________________";
              
        
    
    }
    
    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Rückgabe zurück
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        Spieler spieler = gibdas.getSpieler();
        //Scanner wird angelegt
        Scanner ein = new Scanner(System.in);
        //Story wird angelegt
        this.setStory(gibdas);
        System.out.println(this.getStory());
        //Fragt ab ob man hilft
        
        try{
        if (ein.nextInt()==42) // Wenn man ihm hilft
        {
            System.out.println("Sehr richtig. Dafür heile ich dich!");
            spieler.heal(spieler.getMaxHp()-spieler.getHp());
            System.out.println("Deine HP: "+spieler.getHp());
            
        }
        
        else  // wenn man nicht hilft
        {
            
            System.out.println("Falsch!!! Los hau ab! Unwissender!!!");
            System.out.println("Du läufst weiter.");
            
            
        }  
        }
        
        catch(InputMismatchException im) // Wenn keine Zahl eingegeben wird
        {
            System.out.println("Falsch!!! Los hau ab! Unwissender!!!");
            System.out.println("Du läufst weiter.");
        }
        // Auf zum nächsten Kapitel!
	Chapter6 chap6 = new Chapter6();
	gibdas = chap6.tell(gibdas);
        return gibdas;
         
    
    }
    
    
}
