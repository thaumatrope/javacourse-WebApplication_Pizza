/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.interfaces;

import hasendorf.misc.Uebergabe;
import hasendorf.Exceptions.SpielerWarBoeseException;

/**
 *
 * @author Teilnehmer
 */
public interface CanBeTold 
{
    /**
     * Gibt die Story aus
     * @param gibdas die Übergabe
     * @return die Übergabe
     */
    public Uebergabe tell(Uebergabe gibdas) throws SpielerWarBoeseException;
    
    /**
     * legt die Story fest
     * @param gibdas die Übergabe
     */
    public void setStory(Uebergabe gibdas);
}
