/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.fightingSystem;

import hasendorf.misc.Uebergabe;
import hasendorf.chars.Spieler;
import hasendorf.chars.Gegner;
import hasendorf.endings.BadEnd;
import java.util.Scanner;

/**
 *Das Kampfsystem
 * @author Teilnehmer
 */
public class Fight {
    
    
	private int init;
    
    public Fight(Uebergabe gibdas, int x)
    {
       
		
        
        
    
    }
	/**
         * Hier wird gekämpft
         * @param gibdas die Übergabe
         * @param x der Gegner für den Kampf
         * @return gibt die Übergabe zurück z.B. um die aktuellen hp zu übergeben
         */
	public int fight(Uebergabe gibdas, int x)
	{   System.out.println("Dein Gegenüber lacht und greift dich an!\n Beliebige Taste (außer Enter) drücken und mit Enter\n bestätigen um den Kampf zu beginnen.");
		          System.out.println("_________________________________________________________________");
        Scanner ein = new Scanner(System.in);
                String moo = ein.next();
            int ini = this.ini(); // Initiative wird ausgewürfelt
		
		//Wenn du den Initiativwurfgewinnst
		if(ini == 1)
		{
			Spieler spieler = gibdas.getSpieler();
			
			Gegner gegner = gibdas.getGegner()[x-1];
                        System.out.println("Deine HP: "+spieler.getHp());
                        System.out.println("Gegnerische HP: "+gegner.getHp());
                        System.out.println("Deine Stärke: "+spieler.getSt());
                        System.out.println("Gegnerische Stärke: "+gegner.getSt());
			while(spieler.getHp()> 0 && gegner.getHp()> 0) // Solange du und der Gegner leben
				
				{
					
					if(spieler.getHp()>0) //Wenn du lebst
					{
					System.out.println("Du triffst den Gegner.");
					gegner.hit(spieler.getSt());
                                        
                                        
					if (gegner.getHp()<0)
					{
					    gegner.heal(0-gegner.getHp());
					}
					System.out.println("Gegnerische HP: "+ gegner.getHp());
                                        
                                         
                                        
					}
					
                                        
                                        else // Wenn du tot bist.
                                                {
                                                    BadEnd bad = new BadEnd();
                                                     bad.tell(gibdas);
                                                }
					if(gegner.getHp()>0) //wenn der Gegner lebt
					{
					System.out.println("Der Gegner trifft dich.");
					spieler.hit(gegner.getSt());
					System.out.println("Deine HP: " + spieler.getHp());
					}
					
					else
					{
						System.out.println("Gegner besiegt!");
					}
                                        
                                        
				}
                       
		}
		
		else
		{
			Spieler spieler = gibdas.getSpieler();
			Gegner gegner = gibdas.getGegner()[x-1];
			spieler = gibdas.getSpieler();
			gegner = gibdas.getGegner()[x-1];
			
			while(spieler.getHp()> 0 && gegner.getHp()> 0) // Solange du und der Gegner lebt

			{
			
			System.out.println("Der Gegner trifft dich.");
			if(spieler.getHp()>=gegner.getSt())
			{
			spieler.hit(gegner.getSt());
			System.out.println("Deine HP: " + spieler.getHp());
			}
			else
			{
				
				BadEnd bad = new BadEnd();
                                   bad.tell(gibdas);
				
				
					
			}
			
			System.out.println("Du triffst den Gegner.");
			gegner.hit(spieler.getSt());
			System.out.println("Gegnerische HP: "+ gegner.getHp());
			}
			
			
			
		}
	
		
		
		return 1;
	}
   /**
    * Würfelt die Initiative aus. 1 geißt du beginnst, 2 heißt Gegner gewinnt.
    * @return Initiative
    */ 
   public int ini()
    {
       Roll roll = new Roll();
	   String[] ini = roll.get1W6();
	   System.out.println("Initiative wird gewürfelt.");
	   for(int i=0;i<4;i++)
	   {
	  		 System.out.println(ini[i]);
			 
			 if (ini[3].contains("1"))
			 {
			     init = 1;
			 }
			 
			 else
			 {
				 init = 2;
			 }
	   }
	   
	   switch(init)
	   {
		   case 1: 
			   return 1;
			   
			   
		   case 2: 
			   return 2;
			   
			   
		   default:
		       return 3;
			   
			   
	   }
	   
	   
	   
    }
    
}
