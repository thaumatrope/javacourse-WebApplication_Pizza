/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.misc;

import hasendorf.chars.Spieler;
import hasendorf.chars.Gegner;
import hasendorf.chars.NPC;
import hasendorf.chars.Hasen;


/**
 *
 * @author Teilnehmer
 * Die Übergabe dient dazu, dass Parameter von Klasse zu Klasse weitergegeben werden
 */
public class Uebergabe 
{
    // Initialisierung von Variablen
    String wahl;
    Hasen[] bunnys;
    boolean hasGem;
    NPC[] others;
    Gegner[] gegner;
    Spieler spieler;
    
    /**
     * Die erste Übergabe.
     * @param wahl der Gewählte Hase
     * @param bunnys die Hasen
     * @param hasGem Warst du auch schön lieb zu dem Eichhörnchen?!
     * @param gegner Die Gegners!
     * @param others Andere Wesen
     * 
     */
    
    
    
    public Uebergabe(String wahl, Hasen[] bunnys, boolean hasGem, NPC[] others,Gegner[] gegner)
    {
        this.wahl = wahl;
        this.bunnys = bunnys;
        this.hasGem = hasGem;
        this.others = others;
        this.gegner =gegner;
    }
     /**
     * Restliche Übergaben
     * @param spieler der Spieler
     * @param bunnys die Hasen
     * @param hasGem Warst du auch schön lieb zu dem Eichhörnchen?!
     * @param gegner Die Gegners!
     * @param others Andere Wesen
     * 
     */
    public Uebergabe(Spieler spieler, Hasen[] bunnys, boolean hasGem, NPC[] others,Gegner[] gegner)
    {
        this.spieler = spieler;
        this.bunnys = bunnys;
        this.hasGem = hasGem;
        this.others = others;
        this.gegner =gegner;
    }
    
    
    /**
     * 
     * @return gibt die Wahl aus
     */
     public String getWahl()
    {
        return wahl;
    
    }
    /**
     * 
     * @return gibt die Hasen aus
     */
    public Hasen[] getBunnys()
    {
        return bunnys;
    
    }
    
    /**
     * 
     * @return gibt aus ob der Gem vorhanden ist
     */
    public boolean getHasGem()
    {
        return hasGem;
    
    }
    
    /**
     * Setzt die Wahl
     * @param wahl 
     */
    public void setWahl(String wahl)
    {
        this.wahl = wahl;
    
    }
    
    /**
     * Setzt die Hasen
     * @param bunnies Die Hasen.
     */
    public void setBunnys(Hasen[] bunnies)
    {
        this.bunnys = bunnies;
    
    }
    
    /**
     * Setzt ob man den Gem hat.
     * @param hasGem 
     */
    public void setHasGem(boolean hasGem)
    {
        this.hasGem = hasGem;
    
    }
    
	
	/**
	* Setzt den Spieler
	* @param spieler der Spieler wird übergeben
	*/
    public void setSpieler(Spieler spieler)
    {
        this.spieler = spieler;
    
    }
    /**
     * 
     * @return gibt den spieler aus
     */
	
    public Spieler getSpieler()
    {
        return spieler;
    }
    
	/**
     * Setzt den Gegner
     * @param gegner der übergebene Gegner
     */
    public void setGegner(Gegner[] gegner)
    {
        this.gegner = gegner;
    
    }
    
	
	/**
     * 
     * @return gibt den Gegner aus
     */
    public Gegner[] getGegner()
    {
        return this.gegner;
    }
    
    
}
