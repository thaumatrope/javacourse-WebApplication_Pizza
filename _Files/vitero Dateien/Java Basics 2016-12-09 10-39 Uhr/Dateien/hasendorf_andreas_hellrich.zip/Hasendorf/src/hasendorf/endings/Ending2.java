/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.endings;

import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import java.util.Scanner;

/**
 *Dient dazu das Ending auszugeben
 * @author Teilnehmer
 */
public class Ending2 extends Endings implements CanBeTold
{
     /**
     * gibt das Ending aus
     * @param got die Standardübergabe
     * @return gibt die Übergabe zurück. Eigentlich nicht nötig aber wegen Interface
     */
    @Override
    public Uebergabe tell(Uebergabe got)
    {
        System.out.println("Du hast es geschafft!");
        System.out.println("Du hast die Prinzessin gerettet!");
        System.out.println("Die Prinzessin sieht, dass du eine Edelstein bei dir trägst.");
        System.out.println("Oh mein Gott! Du hast meinen Zauberstein gefunden!");
        System.out.println("Den hab ich schon seit meiner Kindheit gesucht!");
        System.out.println("Willst du mich heiraten? Dann sag jetzt ja. Wenn nicht sag irgendwas anderes!");
        System.out.println("__________________________________________________________________________________");
        Scanner scans = new Scanner(System.in);
        String scan = scans.next();
        if (scan.contains("ja"))
        {
            System.out.println("Ihr heiratet und du wirst später einmal König und gehst in die Geschichte ein.");
            System.out.println("Wie es bei Hasen üblich ist, kriegt ihr viele Kinder.");
            System.out.println("Die Kriegen dann auch viele Kinder und so weiter. Fibonacci eben.");
        }
        else
        {
            System.out.println("Du und die Prinzessin werden beste Freunde.");
            System.out.println("Ihr trefft euch jede Woche Dienstag abends zum Backgammon spielen.");
        }
       return got;
    }
}
