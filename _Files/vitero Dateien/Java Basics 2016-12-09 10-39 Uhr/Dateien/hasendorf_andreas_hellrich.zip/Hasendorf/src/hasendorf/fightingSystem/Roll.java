package hasendorf.fightingSystem;

/**
 * Dient zum würfeln
 * @author Teilnehmer
 */
public class Roll
{
    /**
     * 1 W6
     * @return Würfelwürfe
     */
  public int[] dice1W6()
  {
	  int[] dice = GetDice(2);
	  return dice;
  }

/**
 * 2 W6
 * @return Würfelwürfe
 */  
public int[] dice2W6()
{
        int[] dice = GetDice(4);
        return dice;
}


/**
 * Der eigentliche Wurf
 * @param bis wie oft geworfen wird. Für 1 W6 einmal, für 2 W6 zweimal (pro Person)
 * @return das Ergebnis
 */
public int[] GetDice(int bis)	
{

        int[] dice = new int[bis];


        for(int i = 0; i<bis;i++)
        {
                dice[i] =(int)(Math.random()*6) + 1;
        }


        return dice;

}

/**
 * Gibt aus, was gewürfelt wurde bei 1 W6
 * @return Die Ergebnisse in einem Array
 */
public String[] get1W6()
{
        int[] dice = this.dice1W6();
        String[] result = new String[4];
    int winner = Math.max(dice[0], dice[1]);

        result[0] = ("Spieler 1 hat eine " + dice[0] + " gewürfelt!");
        result[1] = ("Spieler 2 hat eine " + dice[1] + " gewürfelt!");
        if(winner == dice[0])
        {
                result[2] = "Spieler 1 gewinnt!";
                result[3] = "1";

        }
        else
        {
                result[2] = "Spieler 2 gewinnt!";
                result[3]= "2";

        }


        return result;
}



/**
 * Gibt aus, was gewürfelt wurde bei 2 W6
 * @return Die Ergebnisse in einem Array
 */
public String[] Get2W6()
{
        int[] dice = this.dice2W6();
        String[] result = new String[3];
    int winner = Math.max((dice[0]+dice[1]), (dice[2]+dice[3]));

        result[0] = ("Spieler 1 hat eine " + dice[0] + " und eine " +dice[1]+" gewürfelt!");
        result[1] = ("Spieler 2 hat eine " + dice[2] + " und eine " +dice[2]+" gewürfelt!");
        if(winner == (dice[0]+dice[1]))
        {
                result[2] = "Spieler 1 gewinnt!";

        }
        else
        {
                result[2] = "Spieler 2 gewinnt!";

        }

        return result;
}
	
	
	
	
	
	  
}
