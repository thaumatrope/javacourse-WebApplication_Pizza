/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chapters;

import hasendorf.misc.Create;
import hasendorf.misc.Texte;
import hasendorf.fightingSystem.Fight;
import hasendorf.chars.Gegner;
import hasendorf.chars.Spieler;
import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import java.util.Map;

/**
 * Das vierte Kapitel
 * @author Teilnehmer
 */
public class Chapter8 extends Chapters implements CanBeTold
{
    /**
     * legt das vierte Kapitel an
     */
    public Chapter8()
    {
        
    id =8;
    }
    /**
     * Setzt die Story
     * @param gibdas die übliche Übergabe
     */
    @Override
    public void setStory(Uebergabe gibdas)
    {
        
	Create gegner = new Create();
        Gegner hund = gegner.gegner()[3];
	Spieler spieler = gibdas.getSpieler();
        String[] geteilt = spieler.getName().split(" ");
        String vorname = geteilt[0];
        Texte smalltalk = new Texte();
        Map dict = smalltalk.texteLaden();
        String peterText = dict.get("Peter").toString();
        String hundText = dict.get("Hund").toString();
        String harryText = dict.get("Harry").toString();
		
        story = "*****************************************************************\n";
        story += "Du begnest einem großen Hund.\n";
        story += "Er hat "+hund.getHaare()+"Fell und "+hund.getAugen()+" Augen.";
        
        story += "\nEr begrüßt dich mit "+hund.talk(hundText);
        if (vorname.contains("Harry"))
            story += "\nDu antwortest mit "+spieler.talk(harryText);
       else
            story += "\nDu antwortest mit "+spieler.talk(peterText);
       
        story += "\n_________________________________________________________________";
              
        
    
    }
    
    /**
     * Erzählt die Story
     * @param gibdas die übliche Übergabe
     * @return gibt die Rückgabe zurück
     */
    @Override
    public Uebergabe tell(Uebergabe gibdas)
    {
        this.setStory(gibdas);
        System.out.println(this.getStory());
        Fight fight = new Fight(gibdas,2);
	fight.fight(gibdas,2);
        System.out.println("Du hast den Hund besiegt und gehst weiter.");
	
        // Auf zum nächsten Kapitel!
        
        
        Chapter9 chap9 = new Chapter9();
	gibdas = chap9.tell(gibdas);
        return gibdas;
         
    
    }
    
    
}
