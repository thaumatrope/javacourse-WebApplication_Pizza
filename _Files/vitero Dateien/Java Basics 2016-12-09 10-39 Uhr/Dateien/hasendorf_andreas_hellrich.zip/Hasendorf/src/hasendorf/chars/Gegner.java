/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chars;

import hasendorf.interfaces.CanTalk;
import java.util.Map;

/**
 *
 * @author Teilnehmer
 */
public class Gegner extends Chars implements CanTalk
{
    /**
     * Der Konstruktor für die Gegner
     * @param name der Name
     * @param haare die Haar-/Fellfarbe
     * @param augen die Augenfarbe
     * @param hostile ist er bösartig?
     * @param hp die Hitpoints
     * @param st die Stärke
     * @param maxhp die maximalen Hitpoints
     */
    public Gegner(String name, String haare, String augen, boolean hostile, int hp, int st, int maxhp)
    {
        super(name,haare,augen,hostile,hp,st,maxhp );
    }
    
    /**
     * legt die Begrüßung fest
     * @param texte der Text
     * @return gibt die Begrüßung aus
     */
    @Override
    public String talk(String texte)
    {
        String says = texte;
        return says;
    }
}
