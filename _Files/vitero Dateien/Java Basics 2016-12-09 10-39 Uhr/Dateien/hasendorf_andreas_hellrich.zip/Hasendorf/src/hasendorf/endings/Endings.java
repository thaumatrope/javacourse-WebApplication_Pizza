/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.endings;
import hasendorf.chapters.Chapters;
import hasendorf.interfaces.CanBeTold;
import hasendorf.misc.Uebergabe;
import hasendorf.Exceptions.SpielerWarBoeseException;

/**
 *Dient dazu die Endings auszugeben
 * @author Teilnehmer
 */
public class Endings extends Chapters implements CanBeTold

{
     /**
     * gibt das Ending aus
     * @param got die Standardübergabe
     * @return gibt die Übergabe zurück. Eigentlich nicht nötig aber wegen Interface.
     */
    @Override
    public Uebergabe tell(Uebergabe got) throws SpielerWarBoeseException
    {
        throw new hasendorf.Exceptions.SpielerWarBoeseException();
       
    }
}
