/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.chars;

import hasendorf.interfaces.CanTalk;

/**
 * Die Hasenklasse
 * @author Teilnehmer
 */
public class Hasen extends Chars implements CanTalk
{
    /**
     * Die Hasen werden angelegt
     * @param name Der Name des Hasen
     * @param haare Die Fellfarbe des Hasen
     * @param augen Die Augenfarbe des Hasen
     * @param hostile Gibt an ob der Hase feindseelig ist.
     * @param hp Die hp
     * @param st Die staerke
     * @param maxhp die maximalen hp
     */
    public Hasen (String name, String haare, String augen, boolean hostile, int hp, int st, int maxhp)
    {
        //Der Konstruktor der Charsklasse wird benutzt
        super(name,haare,augen,hostile,hp,st,maxhp );
        
        
        
       
       
    
    }
    /**
     * legt die Begrüßung fest
     * @param texte der Text
     * @return gibt die Begrüßung aus
     */
    @Override
    public String talk(String texte)
    {
        String says = texte;
        return says;
    }
    
    
}
