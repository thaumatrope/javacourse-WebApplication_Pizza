/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hasendorf.endings;

import hasendorf.misc.Uebergabe;
import hasendorf.interfaces.CanBeTold;
import hasendorf.Exceptions.*;

/**
 *Dient dazu das Ending auszugeben
 * @author Teilnehmer
 */
public class Ending1 extends Endings implements CanBeTold
{
    /**
     * gibt das Ending aus
     * @param got die Standardübergabe
     * @return gibt die Übergabe zurück. Eigentlich nicht nötig aber wegen Interface.
     */
    
    public Uebergabe tell(Uebergabe got) throws SpielerWarBoeseException
    {
       throw new SpielerWarBoeseException();
       //return got;
    }
}