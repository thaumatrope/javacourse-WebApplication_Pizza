/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package eulerproblems;

import java.util.ArrayList;

/**
 * Klasse der Lucas-artig-definierbaren Folgen.
 * 
 * @author SRH
 */
public class Lucas implements Series{
    //Attribute
    /**
     * !!!PRIVATE!!!
     * Folgen-Array
     */
    final private ArrayList<Long> series=new ArrayList();
    
    //Konstruktor

    //Methoden
    /**
     * Berechnet die nächsten /next/ Folgenmitglieder und fügt diese zum Folgenarray hinzu.
     * @param extra Anzahl der zusätzlichen Folgenmitglieder
    */
    @Override
    final public void nextMember(int extra){
        for (int zaehler=0;zaehler<extra;zaehler++){
            long last1=lastMember();
            long last2=series.get(series.size()-2);
            series.add(last1+last2);
        }
    }
    /**
    * Berechnet das nächste Folgenmitglied und fügt es zum Folgenarray hinzu.
    * @see #nextMember(int)
    */
    @Override
    final public void nextMember(){
        nextMember(1);
    }
    /**
     * Gibt das letzte Folgenglied zurück.
     * @return letztes Folgenglied
     */
    final public long lastMember(){
        return series.get(series.size()-1);
    }
    /**
     * Fügt eine Zahl zum Folgenarray hinzu.
     * @param next Zahl die hinzugefügt werden soll
     * !!!PROTECTED!!!
     */
    protected void add(long next){
        series.add(next);
    }
    /**
     * get-Funktion als Methode direkt an die Folge gebunden.
     * @param index Index des gesuchten Folgenmitglieds
     * @return Folgenmitglied an der Position /index/
     */
    @Override
    final public long getMember(int index){
        return series.get(index);
    }
    /**
     * size-Funktion als Methode direkt an die Folge gebunden.
     * @return Länge der bestehenden Folge
     */
    final public int size(){
        return series.size();
    }
    /**
     * Rückgabe einer Teilfolge der bestehenden Folge zwischen den Indices /low/ und /high/ (inkl.)
     * @param lowindex untere Index-Schranke
     * @param highindex obere Index-Schranke
     * @return Teilfolge Lucas[low:high]
     */
    final public Lucas getPart(int lowindex,int highindex){
        Lucas partial=null;
        if(lowindex<series.size()-1){
            partial=new Lucas();
            int pos=lowindex;
            while(pos<series.size()-1){
                partial.add(series.get(pos));
                pos++;
            }
            if(highindex>series.size()-1){
                partial.nextMember(highindex-series.size());
            }
        }
        return partial;
    }
    /**
     * Rückgabe einer Teilfolge der bestehenden Folge zwischen den Indices 0 und /highindex/ (inkl.)
     * @param highindex obere Index-Schranke
     * @return Teilfolge Lucas[0:highindex]
     * @see #getPart(int, int) 
     */
    final public Lucas getPart(int highindex){
        Lucas partial=this.getPart(0,highindex);
        return partial;        
    }
    /**
     * Rückgabe der aktuellen Folge mit Kommata-Trennung.
     * @return aktuelle Folge in der Form "L[0], L[1], ..."
     */
    @Override
    final public String csvString(){
        String outtext=""+series.get(0);
        if(series.size()>1){
            for (int element=1;element<series.size();element++){
                outtext+=", "+series.get(element);
            }
        }
        return outtext;
    }
}
