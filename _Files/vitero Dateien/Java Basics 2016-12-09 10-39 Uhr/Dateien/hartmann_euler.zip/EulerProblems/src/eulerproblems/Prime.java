/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eulerproblems;

import java.util.ArrayList;
import java.util.Collections;

/**
 * (Singelton) Primzahlenliste (PZL) wird bei Bedarf erweitert und besteht bis Programmende.
 * 
 * @author SRH
 */
public class Prime implements Series{
    //Attribute
    /**
     * Singleton-Variable
     */
    static private Prime instance=null; //Singelton-Variable
    /**
     * Primzahlenliste (PLZ)
     */
    final private ArrayList<Long> primlist=new ArrayList(); //PZL besser als Set ABER keine get-Methode?
    
    //Konstruktoren
    /** !!!PRIVATE!!!
     * Konstruktor der PZL mit den ersten 10 Einträgen.
     */
    private Prime(){
        primlist.add(2L);
        primlist.add(3L);
        this.nextMember(8);
    }
     
    //Methoden
    /**
     * Stelle sicher, dass nur eine PZL erzeugt werden kann (singleton pattern).
     * @return Singleton-Objekt der PZL
     */
    static public Prime create(){
        if(instance==null){
            instance=new Prime();
        }
        return instance;
    }    
    /** !!!PRIVATE!!!
     * Erweitert die PZL um number, wenn der isPrim(number) true liefert und number nicht schon in der PZL vorhanden ist.
     * @param number Neuer Kandidat für die PZL
     */
    private void addIf(long number){
        if(isPrim(number) && !primlist.contains(number)){
            primlist.add(number);
            Collections.sort(primlist);
        }
    }
    /**
    * Primzahlentest als Schleife über die bisher bekannten Primzahlen.
    * @param number zu testende Zahl
    * @return Testergebnis
    */
    final public boolean isPrim(long number){
        if (primlist.contains(number)){
            return true;
        }
        if (number<2){//Sonderfaelle <0, 0 und 1 immer 
            return false;
        }
        for (long prim: primlist){
            if (number%prim==0){
                return false;
            }
        }
        int step=1;
        for (long prim: primlist){
            step*=prim;
        }
        for(int tester=step; tester<=Math.sqrt(number)+1; tester+=step){//Muss nur bis sqrt(number) getestet werden
            if((number%(tester-1)==0) || (number%(tester+1)==0)){
                return false;
            }
        }
        return true;        
    }
    /**
    * Primzahlentest als Schleife über die bisher bekannten Primzahlen.
    * @param number zu testende Zahl
    * @return Testergebnis
    */
    private boolean isPrim_new(long number){//SCHNELLERER TEST, tut aber noch nicht :(
        if(primlist.contains(number)){
            return true;
        }
        if(number<2){
            return false;
        }
        return ((((number+1)%6)==0)||(((number-1)%6)==0));
    }
    /**
    * Fügt die nächsten /extra/ Primzahlen zur PZL hinzu.
    * @param extra Anzahl der zusätzlichen Primzahlen
    */
    @Override
    final public void nextMember(int extra){
        for(int zaehler=0;zaehler<extra;zaehler++){
            long lastprim=primlist.get(primlist.size()-1);
            for (long next=lastprim+1L;next<(2*lastprim);next++){
                if(isPrim(next)){
                    primlist.add(next);
                    break;
                }
            }
        }
    }
    /**
    * Fügt die nächste Primzahl zur PZL hinzu.
    * @see #nextMember(int)
    */
    @Override
    final public void nextMember(){
        nextMember(1);
    }
    /**
     * Gibt die Primzahl an der /index/-ten Stelle aus der PZL zurück.
     * @param index Index der gewünschten Primzahl
     * @return Primzahl
     */    
    @Override
    final public long getMember(int index){
        if(index>=primlist.size()){
            nextMember(index-primlist.size()+1);
        }
        return primlist.get(index);
    }
    /**
     * Erweitert die PZL bis maximal zu einem Wert /number/.
     * @param number Obergrenze der Erweiterung
     */
    final public void upTo(long number){
        //for (long zahl=0L;zahl<=number;zahl++){
        for (long zahl=3L;zahl<=number;zahl+=2){
            this.addIf(zahl);
        }
    }
    /**
     * Rückgabe der aktuellen PZL mit Kommata-Trennung.
     * @return aktuelle PZL in der Form "p[0], p[1], ..."
     */
    @Override
    final public String csvString(){
        /*
        * Rückgabe der aktuellen Primzahlenliste als csv-String.
        */
        String outtext=""+primlist.get(0);
        if(primlist.size()>1){
            for (int element=1;element<primlist.size();element++){
                outtext+=", "+primlist.get(element);
            }
        }
        return outtext;
    }
    /**
     * Rückgabe einer Teilliste der PZL zwischen den Indices /lowindex/ und /highindex/ (inkl.)
     * @param lowindex untere Index-Schranke
     * @param highindex obere Index-Schranke
     * @return Teilliste PZL[lowindex:highindex]
     */
    final public ArrayList<Long> getPart(int lowindex, int highindex){
        ArrayList<Long> partial=new ArrayList();
        if(lowindex<primlist.size()){
            this.nextMember(lowindex-1-primlist.size());
        }
        if(highindex+1>primlist.size()){
            this.nextMember(highindex+1-primlist.size());
        }
        for(int pos=lowindex;pos<highindex+1;pos++){
            partial.add(primlist.get(pos));
        }            
        return partial;
    }
    /**
     * Rückgabe einer Teilliste der PLZ im Bereich /low/ und /high/ (inkl.)
     * @param low untere Schranke
     * @param high obere Schranke
     * @return Teilliste PZL[nearIndex(low),nearIndex(high)]
     * @see #getPart(int, int) 
     */
    final public ArrayList<Long> getPart(long low,long high){
        /*
        * Rueckgabe einer Teilliste der Primzahlenliste zwischen den Grenzzahlen @args.
        */
        upTo(high);
        int lowindex=0;
        while (low>primlist.get(lowindex)){
            lowindex++;
        }
        int highindex=primlist.size()-1;
        while (high<primlist.get(highindex)){
            highindex--;
        }
        ArrayList<Long> partial=getPart(lowindex,highindex);
        return partial;
    }
    /**
     * Rückgabe einer Teilliste der PLZ im Bereich 2 bis /high/ (inkl.)
     * @param high obere Schranke
     * @return Teilliste [0:nearIndex(high)]
     * @see #getPart(long, long) 
     */
    final public ArrayList<Long> getPart(long high){
        return getPart(2L,high);
    }
    /**
     * Rückgabe einer Paar-Liste aller möglichen Primfaktoren von /number/.
     * @param number zu zerlegende Zahl
     * @return Paar-Liste [{p[0],-1L},{p[1],-1L},...]
     */
    final public ArrayList<Long[]> PrimFactorList(long number){//besser als Map ABER nur umstaendliche get-Methode?
        ArrayList<Long[]> factorpairs=new ArrayList();
        ArrayList<Long> factorlist=new ArrayList();
        factorlist=getPart((long)Math.sqrt(number));
        for (long prim:factorlist){
            Long[] pair={prim,-1L};
            factorpairs.add(pair);
        }
        return factorpairs;
    }
}