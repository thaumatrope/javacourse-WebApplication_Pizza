/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package eulerproblems;

//import java.lang.StringBuffer;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 * Klasse aller bearbeiteten Probleme.
 * 
 * @author SRH
 */
public class Problems{
    //Attribute
    
    //Konstruktoren
    
    //Methoden
    /**
     * Problem 1 (Veraltet): Summe der durch 3 oder 5 teilbaren natürlichen Zahlen bis zu einem Grenzwert /limit/.
     * @param limit Grenzwert
     * @return endgültige Summe
     */
    public int multiple35(int limit){
        int sum=0;
        for (int zahl=0;zahl<limit;zahl++) {// zahl++ entspricht zahl=zahl+1 entspricht zahl+=1
            if ((zahl%3==0) || (zahl%5==0)) {// || entspricht OR (^ entspraeche XOR)
                sum+=zahl;// sum=sum+zahl
            }
        }
        return sum;
    }
    /**
     * Problem 1: Summe der durch /divisorlist/ teilbaren natürlichen Zahlen (ohne Doppelung) bis zu einem Grenzwert /limit/.
     * @param divisorlist Liste der Teiler
     * @param limit Grenzwert
     * @return endgültige Summe
     */
    public int multipleSum(int[] divisorlist, int limit){
        Set<Integer> teilbar=new TreeSet<>();
        for (int zahl=0;zahl<limit;zahl++){
            for (int divisor:divisorlist){
                if(zahl%divisor==0){
                    teilbar.add(zahl);
                }
            }
        }
        int sum=0;
        for(int element:teilbar){
            sum+=element;
        }
        return sum;
}
    /**
     * Problem 2: Summe aller durch /Teiler/ teilbaren Fibonacci-Zahlen bis zu einem Grenzwert /limit/.
     * @param limit Grenzwert
     * @param divisor Teiler
     * @return endgültige Summe
     */
    public long partSumFibonacci(long limit, int divisor) {
        Fibonacci fib=Fibonacci.create();
        while(fib.lastMember()<limit){
            fib.nextMember();
        }
        long sum=0;
        for(int index=0;index<fib.size()-1;index++){
            long number=fib.getMember(index);
            if(number<limit && number%divisor==0){
                sum+=number;
            }
        }
        return sum;
    }
    /**
     * Problem 3: Bestimme den größten Primzahlfaktor einer Zahl.
     * @param zahl zur zerlegende Zahl
     * @return größter Primzahlfaktor
     */
    public long largestPrimeFactor(long zahl){
        long largest=1L;
        long factor=2L;
        while (factor*factor<=zahl) {
            while (zahl%factor==0) {
                zahl=zahl/factor;
                largest=Math.max(largest,factor);
            }
            factor++;
        }
        largest=Math.max(largest,zahl);
        return largest;
    }
    /**
     * Problem 3 (Alternative): Bestimme den größten Primzahlfaktor einer Zahl über die Primzahlfolgen-Klasse und die Zählung der Faktor-Exponenten.
     * !!!DAUERT LANGE!!!
     * @param zahl zu zerlegende Zahl
     * @return größter Primzahlfaktor
     * @see #largestPrimeFactor(long) 
     * @see #factorization(long)
     * see #Prime.PrimFactorList(long)
     */
    public long largestPrimeFactor2(long zahl){
        ArrayList<Long[]> factors=factorization(zahl);
        long largest=1L;
        for (Long[] pair:factors){
            if(pair[1]!=-1L){
                largest=pair[0];
            }
        }
        return largest;
    }
    /**
     * Zählung für die Primzahlfaktor-Exponenten über eien Paar-Liste.
     * @param zahl zu zerlegende Zahl
     * @return Paar-Liste [{p[i],Exponent(p[i])},...]
     * @see #largestPrimeFactor2(long)
     */
    public ArrayList<Long[]> factorization(long zahl){
        Prime prim=Prime.create();
        ArrayList<Long[]> factorlist=prim.PrimFactorList(zahl);
        for (Long[] factor : factorlist) {
            while(zahl%factor[0]==0){
                zahl/=factor[0];
                factor[1]++;
            }
        }
        //int counter=1; //Ausgabe-Counter
        for (Long[] factor : factorlist) {
            if(factor[1]!=-1L){ //Test ob besetzt
                factor[1]+=1L; //Shift um 1 wegen Vorinitalisierung der Exponenten
                //System.out.println(""+counter+". Faktorpaar ["+factor[0]+","+(factor[1])+"]"); //Ausgabe der Paare
                //counter++;
            }
        }
        return factorlist;
    }
    /**
     * Problem 4: Bestimme die größte Palindrom-Zahl aus dem Produkt zweier n-stelliger Zahlen.
     * @param power Anzahl der Stellen der beiden Faktoren
     * @return gefundenes Palindrom und Produkt-Formel
     */
    public String palimdromicNumber(int power){
        int lowlimit=(int)Math.pow(10,power);
        int uplimit=(int)Math.pow(10,power+1);
        int prod;
        int largest=0;
        String pair="";
        for (int i=lowlimit;i<uplimit;i++){
            for (int j=lowlimit;j<uplimit;j++){ //baeh Schachtel-if, das kann dauern ...
                prod=i*j;
                if (isPalindrom(Integer.toString(prod))){
                    if(prod>largest){
                        largest=prod;
                        pair=" ("+i+" × "+j+")";
                    }
                }
            }
        }
        return ""+largest+pair;
    }
    /**
     * Test, ob ein String ein Palindrom ist.
     * @param inputString Ursprungswort
     * @return Testergebnis
     * @see #palimdromicNumber(int) 
     */
    public boolean isPalindrom(String inputString){
        String reverseString=new StringBuffer(inputString).reverse().toString();
        return (reverseString.equals(inputString));
    }
    /**
     * Problem 5: Bestimme das kleinste gemeinsame Vielfache aller Zahlen bis zum Grenzwert /limit/
     * @param limit Grenzwert
     * @return kleinstes gemeinsames Vielfaches
     */
    public int smallestMultiple(long limit){
        Prime prim=Prime.create();
        ArrayList<Long> factors=prim.getPart(limit);
        double kgv=1;
        for (double primnumber:factors){
            double power=1.;
            while(Math.pow(primnumber,power+1)<=limit){
                power++;
            }
            kgv*=Math.pow(primnumber,power);
        }
        return (int)kgv;
    }
    /**
     * Problem 6: Bestimme die Differenz zwischen Quadratsumme und das Summenquadrat der natürlichen Zahlen bis zu einem Grenzwert /limit/.
     * @param limit Grenzwert
     * @return endgültige Differenz
     */
    public int sumSquareDifference(int limit){
        int sum=0;
        int qsum=0;
        for (int zahl=0;zahl<=limit;zahl++){
            sum+=zahl;
            qsum+=Math.pow(zahl,2);
        }
        int difference=(int)Math.pow(sum,2)-qsum;
        return difference;
    }
    /**
     * Problem 7: Bestimme die /index/-te Primzahl.
     * !!!DAUERT LANGE!!!
     * @param index Index der gesuchten Primzahl
     * @return Primzahl
 see #Prime.getMember(int)
     */
    public long primeIndex(int index){
        Prime prim=Prime.create();
        return prim.getMember(index-1);
    }
    /**
     * Problem 8: Bestimme aus einer als Textfile vorliegenden Zahl das größt-mögliche Produkt aus n-aufeianderfolgender Stellen.
     * @param filePathName Eingangszahl als Textfile
     * @param power Anzahl der aufeinadnerfolgenden Stellen ausgedrückt als Zehnerpotenz 
     * @return Größt-mögliches Produkt, Position der Stellen im File und Zahlenabschnitt
     */
    public String largestSeriesProduct(String filePathName,int power){
        String returnText="";
        try{
            Scanner instream=new Scanner(new FileReader(filePathName));
            String text="";
            while(instream.hasNextLine()){
                text+=instream.nextLine();
            }
            int textLength=text.length();
            long largest=1;
            int bestStart=-1;
            String bestSeries="-NaN-";
            for(int seriesStart=0;seriesStart<textLength-power+1;seriesStart++){
                String seriesString=text.substring(seriesStart,seriesStart+power);
                long seriesInt=Long.parseLong(seriesString);
                long product=1;
                if(seriesInt/(long)Math.pow(10,power-1)==0){
                    product=0;
                }else{
                    for (int index=0;index<power;index++){
                        product*=Integer.parseInt(seriesString.substring(index,index+1));
                    }
                }
                if(product>largest){
                    largest=product;
                    bestStart=seriesStart;
                    bestSeries=seriesString;
                }
                largest=Math.max(largest,product);
            }
            returnText=""+largest+" (beginning at position "+bestStart+" reading "+bestSeries+")";
        }catch(FileNotFoundException fnf){
            System.out.println(fnf);
            fnf.printStackTrace();
        }
        return returnText;
    }
    /**
     * Problem 10: Bestimme die Summe aller Primzahlen bis zu einem Grenzwert /limit/.
     * !!!DAUERT LANGE!!!
     * @param limit Grenzwert
     * @return endgültige Summe
     */
    public long primeSum(long limit){
        Prime prim=Prime.create();
        ArrayList<Long> factors=prim.getPart(limit);
        long sum=0;
        for (long primnumber:factors){
            sum+=primnumber;
        }
        return sum;
    }
    /**
     * Problem 17: Bestimme die Summe der Buchstaben (keine Leerzeichen, keine Bindestriche, englische Schreibweise) aller Zahlworte bis zu einem Grenzwert /limit/.
     * @param limit Grenzwert
     * @return endgültige Summe
     * @see #numberWord(int) 
     * @see #countNumberWord(java.lang.String)
     */
    public int addNumberWord(int limit){
        int sum=0;
        for (int number=1;number<=limit;number++){
            sum+=countNumberWord(numberWord(number));
        }
        return sum;
    }
    /**
     * Entferne die Leerzeichen und Bindestriche aus einem Zahlwort und zähle die Buchstaben.
     * @param numberWord Zahlwort
     * @return Länge des reduzierten Zahlworts
     */
    public int countNumberWord(String numberWord){
        String trimWord=numberWord.replace(" ","");
        trimWord=trimWord.replace("-","");
        return trimWord.length();
    }
    /**
     * Switch-case-Schranken zum Zusammensetzen des englischen Zahlenworts einer Zahl /number/.
     * @param number Eingangszahl
     * @return Zahlenwort
     */
    public String numberWord(int number){
        String word="";
        boolean tenty=false;
        if(number<1000){
            switch(number/100){
                case 1: number-=100; word+="one hundred ";   if(number!=0){word+="and ";} break;
                case 2: number-=200; word+="two hundred ";   if(number!=0){word+="and ";} break;
                case 3: number-=300; word+="three hundred "; if(number!=0){word+="and ";} break;
                case 4: number-=400; word+="four hundred ";  if(number!=0){word+="and ";} break;
                case 5: number-=500; word+="five hundred ";  if(number!=0){word+="and ";} break;
                case 6: number-=600; word+="six hundred ";   if(number!=0){word+="and ";} break;
                case 7: number-=700; word+="seven hundred "; if(number!=0){word+="and ";} break;
                case 8: number-=800; word+="eight hundred "; if(number!=0){word+="and ";} break;
                case 9: number-=900; word+="nine hundred ";  if(number!=0){word+="and ";} break;
                case 0: break;
            }
            switch(number/10){
                case 1: number-=10; tenty=true; switch(number){
                    case 1: word+="eleven";    break;
                    case 2: word+="twelve";    break;
                    case 3: word+="thirteen";  break;
                    case 4: word+="fourteen";  break;
                    case 5: word+="fifteen";   break;
                    case 6: word+="sixteen";   break;
                    case 7: word+="seventeen"; break;
                    case 8: word+="eighteen";  break;
                    case 9: word+="nineteen";  break;
                    case 0: word+="ten";       break;
                } break;
                case 2: number-=20; word+="twenty-";  break;
                case 3: number-=30; word+="thirty-";  break;
                case 4: number-=40; word+="forty-";   break;
                case 5: number-=50; word+="fifty-";   break;
                case 6: number-=60; word+="sixty-";   break;
                case 7: number-=70; word+="seventy-"; break;
                case 8: number-=80; word+="eighty-";  break;
                case 9: number-=90; word+="ninety-";  break;
                case 0: break;
            }
            if(!tenty){
                switch(number){
                    case 1: number-=100; word+="one";   break;
                    case 2: number-=200; word+="two";   break;
                    case 3: number-=300; word+="three"; break;
                    case 4: number-=400; word+="four";  break;
                    case 5: number-=500; word+="five";  break;
                    case 6: number-=600; word+="six";   break;
                    case 7: number-=700; word+="seven"; break;
                    case 8: number-=800; word+="eight"; break;
                    case 9: number-=900; word+="nine";  break;
                    case 0: break;
                }
            }
        }
        if(word.endsWith("-")){
            word=word.replace("-","");
        }
        if(word.endsWith(" ")){
            word=word.trim();
        }
        if(number==1000){
            word+="one thousand";
        }
        return word;
    }
    /**
     * Ausgabe aller englischen Zahlenworte und deren (reduzierter) Länge bis zu einem Grenzwert /limit/.
     * @param limit Grenzwert
     * @see #countNumberWord(java.lang.String) 
     */
    public void printAllNumberWord(int limit){
        for (int zahl=1;zahl<=limit;zahl++){
            String nW=numberWord(zahl);
            System.out.println(""+nW+" hat "+countNumberWord(nW)+" Zeichen.");
        }
    }
    /**
     * Problem 27: Bestimme die erste n-stellige Fibonacci-Zahl.
     * !!!DAUERT LANG!!!
     * @param digit Anzahl der Stellen der gesuchten Fibonaccizahl
     * @return Fibonacci-Zahl
     */
    public long digitFibonacci(int digit){
        Fibonacci fib=Fibonacci.create();
        long found=0;
        long power=(long)Math.pow(10,digit-1);
        boolean search=true;
        while(search){
            if(fib.lastMember()/power==0){
                fib.nextMember();
                System.out.println(""+fib.lastMember());
            }else{
                found=fib.lastMember();
                search=false;
            }
        }
        return found;
    }
}
