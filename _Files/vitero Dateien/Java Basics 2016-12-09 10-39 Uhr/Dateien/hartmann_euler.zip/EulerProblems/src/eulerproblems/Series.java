/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eulerproblems;

/**
 * Interface einiger Reihenmethoden
 * 
 * @author SRH
 */
public interface Series {
    /**
    * Fügt die nächsten /etxra/ Folgenmitglieder und fügt sie zum Folgenarray hinzu.
    * @param extra Anzahl der zusätzlichen Folgenmitglieder
     */
    public void nextMember(int extra);
    /**
    * Berechnet das nächste Folgenmitglied und fügt es zum Folgenarray hinzu.
    * @see #nextMember(int)
    */
    public void nextMember();
    /**
     * get-Funktion als Methode direkt an die jeweilige Folge gebunden.
     * @param index Index des gesuchten Folgenmitglieds
     * @return Folgenmitglied an der Position /index/
     */
    public long getMember(int index);
    /**
     * Rückgabe der aktuellen Folge mit Kommata-Trennung.
     * @return aktuelle Folge in der Form "Folge[0], Folge[1], ..."
     */
    public String csvString();    
}
