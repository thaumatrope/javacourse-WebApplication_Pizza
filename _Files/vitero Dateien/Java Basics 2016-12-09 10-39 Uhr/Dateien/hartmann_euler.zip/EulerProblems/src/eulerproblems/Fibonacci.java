/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eulerproblems;

/**
 * (Singleton) Fibonacci-Folge (Fib) abgeleitet als Spezialfall der Lucas-Folgen.
 * 
 * @author SRH
 */
public class Fibonacci extends Lucas{
    //Attribute
    /** !!!PRIVATE!!!
     * Singleton-Variable
     */
    static private Fibonacci instance=null;
    
    //Konstruktoren
    /** !!!PRIVATE!!!
     * Konstruktor mit den Grundelementen f[0]=1, f[1]=1
     */
    private Fibonacci(){
        super.add(1);
        super.add(1);
    }
    /**
     * !!!PRIVATE!!!
     * Konstruktor mit den Grundelementen f[0]=1, f[1]=1 und darauf aufbauenden /index/-2 Elementen
     * @param length Länge der ersetn Initalisierung
     */
    private Fibonacci(int length){
        super.add(1L);
        super.add(1L);
        super.nextMember(length-2);
    }
    
    //Methoden
    /**
     * Stelle sicher, dass nur eine Fib erzeugt werden kann (singleton pattern).
     * @return Singleton-Objekt der Fib
     */
    static public Fibonacci create(){
        if(instance==null){
            instance=new Fibonacci();
        }
        return instance;
    }
    /**
     * Stelle sicher, dass nur eine Fib von Länge /length/ erzeugt werden kann (singleton pattern).
     * @param length Länge der ersetn Initalisierung
     * @return Singleton-Objekt der Fib
     */
    static public Fibonacci create(int length){
        if(instance==null){
            instance=new Fibonacci(length);
        }
        return instance;
    }
}
