/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package eulerproblems;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

/**
 * MAIN: Verschiedene mathematische Fragen/Probleme von https://projecteuler.net/ .
 *
 * @author SRH
 */
public class EulerProblems {
    
    /**
     * CLI-ähnlicher Programmablauf.
     * @param args Kommandozeilenparameter (wird nicht verwendet)
     */
    public static void main(String[] args){
        
        List<Integer> implemented=Arrays.asList(1,2,3,4,5,6,7,8,10,17);
        
        BufferedReader userinput = new BufferedReader(new InputStreamReader(System.in));
        int pnr=-999;
        System.out.println("");
        do{
            System.out.print("Which problem should be tackled next (end 999):\t");
            pnr=askInput(userinput,pnr);
            if(implemented.contains(pnr)){
                problems(pnr,userinput);
            }else{
                if(pnr!=999 && pnr>0){
                    System.out.println("\tUnfortunately problem "+pnr+" is not implemented, yet.\n");
                }
            }
        }while(pnr!=999);
        System.out.println(" --- EXIT! ---");
                
        // TEST TEST TEST
        //System.out.println("\n\n---------------------------------------\n");
        //fibTest();
        //System.out.println("\n---------------------------------------\n");
        //primeTest();
        //System.out.println("\n---------------------------------------\n");
        //numberNameTest(1000);
        //*/
    }
    
    /**
     * Switch-case-Weiche für die Problemabfrage.
     * @param pnr Usereingabe der Problemnummer
     * @param eingabe Eingabe-Reader wird durchgereicht an Usereingabe für Problem-Parameter
     */
    static public void problems(int pnr,BufferedReader eingabe){
        Problems equations=new Problems();
        System.out.print("\tProblem "+pnr+":");
        int problemInt;
        long problemLong;
        String problemFile;
        int userInt=-999;
        long userLong=-999L;
        switch(pnr){
            case 1:
                System.out.println("\tFind the sum of all the multiples of 3 and 5 below a limit.");
                problemInt=1000;
                int[] problemIntList={3,5}; //leider noch keine User-Eingabe dieser Liste
                System.out.print("\t\t\tLimit (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.println("\t\t\t(Limit: "+problemInt+")\n"
                        + "\t\t\t--> Solution: "+equations.multipleSum(problemIntList,problemInt)+"\n");
                break;
            case 2:
                System.out.println("\tSum all k-divisible members of the Fibonacci sequence with values below a limit.");
                problemInt=2;
                problemLong=(long)4e6; // 4e6=4000000=4_000_000
                System.out.print("\t\t\tDenominator (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.print("\t\t\tLimit (default "+problemLong+"):\t");
                problemLong=askInput(eingabe,problemLong);
                if(problemInt==0){
                    System.out.println("\t*** Denominator 0 not allowed! (using default instead) ***");
                    problemInt=2;
                }
                System.out.println("\t\t\t(Denominator: "+problemInt+", Limit: "+problemLong+")\n"
                        + "\t\t\t--> Solution: "+equations.partSumFibonacci(problemLong,problemInt)+"\n");
                break;
            case 3:
                System.out.println("\tFind the largest prime factor of a number.");
                problemLong=600851475143L;
                System.out.print("\t\t\tNumber (default "+problemLong+"):\t");
                problemLong=askInput(eingabe,problemLong);
                System.out.println("\t\t\t(Number: "+problemLong+")\n"
                        + "\t\t\t--> Solution: "+equations.largestPrimeFactor(problemLong)+"\n");
                /*zweite Methode dauert laenger
                System.out.println("\t(Number: "+problemLong+")\n"
                + "\t\t\t--> Solution: "+equations.largestPrimeFactor2(problemLong)+"\n");
                */
                break;
            case 4:
                System.out.println("\tFind the largest palindromic number made from the product of two n-digit numbers.");
                problemInt=3;
                System.out.print("\t\t\tDigits (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                if(problemInt<2){
                    System.out.println("\t*** Less than 2 digits not allowed! (using default instead) ***");
                    problemInt=3;
                }
                System.out.println("\t\t\t(Digits: "+problemInt+")\n"
                        + "\t\t\t--> Solution: "+equations.palimdromicNumber(problemInt-1)+"\n");
                break;
            case 5:
                System.out.println("\tFind the smallest positive number that is evenly divisible by all natural numbers up to a limit.");
                problemLong=20L;
                System.out.print("\t\t\tLimit (default "+problemLong+"):\t");
                problemLong=askInput(eingabe,problemLong);
                System.out.println("\t\t\t(Limit: "+problemLong+")\n"
                        + "\t\t\t--> Solution: "+equations.smallestMultiple(problemLong)+"\n");
                break;
            case 6:
                System.out.println("\tFind the difference between the sum of the squares and the square of the sum of all natural numbers up to a limit.");
                problemInt=100;
                System.out.print("\t\t\tLimit (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.println("\t\t\t(Limit: "+problemInt+")\n"
                        + "\t\t\t--> Solution: "+equations.sumSquareDifference(problemInt)+"\n");
                break;
            case 7:
                System.out.println("\t!!! CAUTION: THIS MAY TAKE SOME TIME FOR LARGE VALUES!!!\n"
                        + "\t\t\tFind the the prime number with index k.");
                problemInt=10001;
                System.out.print("\t\t\tIndex (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.println("\t\t\t(Index: "+problemInt+")\n"
                        + "\t\t\t--> Solution: "+equations.primeIndex(problemInt)+"\n");
                break;
            case 8:
                System.out.println("\tGiven a number in a file find the largest product of all possible n-consecutive digits.");
                problemFile="T:\\JavaBasic\\EulerProblems\\productseries.txt";
                System.out.print("\t\t\tNumber file (default "+problemFile+"):\t");
                problemFile=askInput(eingabe,problemFile);
                problemInt=13;
                System.out.print("\t\t\tDigits (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.println("\t\t\t(File: "+problemFile+", Digits: "+problemInt+")\n"
                        + "\t\t\t--> Solution: "+equations.largestSeriesProduct(problemFile,problemInt)+"\n");
                break;
            case 10:
                System.out.println("\t!!! CAUTION: THIS MAY TAKE SOME TIME FOR LARGE VALUES!!!\n"
                        + "\t\t\tFind the sum of all the primes below a limit.");
                problemLong=(long)2e6;
                System.out.print("\t\t\tLimit (default "+problemLong+"):\t");
                problemLong=askInput(eingabe,problemLong);
                System.out.println("\t\t\t(Limit: "+problemLong+")\n"
                        + "\t\t\t--> Solution: "+equations.primeSum(problemLong)+"\n");
                break;
            case 17:
                System.out.println("\tSum the letters (no white spaces and no hyphens) for all number words of all the natural numbers up to a limit.");
                problemInt=1000;
                System.out.print("\t\t\tLimit (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.println("\t\t\t(Limit: "+problemInt+")\n"
                        + "\t\t\t--> Solution: "+equations.addNumberWord(problemInt)+"\n");
                break;
                /* // noch nicht fertig
                case 25:
                System.out.println("\tFind the index of the first Fibonacci number which contains n-digits.");
                int problemInt=1000;
                System.out.print("\t\t\tLimit (default "+problemInt+"):\t");
                problemInt=askInput(eingabe,problemInt);
                System.out.println("\t\t\t(Digits: "+problemInt+")\n"
                + "\t\t\t--> Solution: "+equations.digitFibonacci(problemInt)+"\n");
                break;
                */
        }
    }
    /**
     * Usereingabe eines int-Wertes als Problem-Parameter. Mit ENTER wird der default-Wert beibehalten.
     * @param userinput Eingabe-Reader für die Userabfrage
     * @param defaultInt default-Wert des Problems
     * @return default-Wert oder Usereingabe, wenn sinnvolle Usereingabe erfolgt ist
     */
    static public int askInput(BufferedReader userinput,int defaultInt){
        int outInt=-999;
        String userAnswer="";
        try{
            userAnswer=userinput.readLine();
        }catch(IOException ioe){/* //erstmal ohne Fehlertext
            System.out.println("\t*** invalid input (IOE) ***");
        */}
        try{
            outInt=Integer.valueOf(userAnswer.trim());
        }catch(NumberFormatException nfe){/* //erstmal ohne Fehlertext
            System.out.println("\t*** invalid input (NFE) ***");
        */}
        if(outInt<0){
            outInt=defaultInt;
        }
        return outInt;
    }
    /**
     * Usereingabe eines long-Wertes als Problem-Parameter. Mit ENTER wird der default-Wert beibehalten.
     * @param userinput Eingabe-Reader für die Userabfrage
     * @param defaultLong default-Wert des Problems
     * @return default-Wert oder Usereingabe, wenn sinnvolle Usereingabe erfolgt ist
     */
    static public long askInput(BufferedReader userinput,long defaultLong){
        long outLong=-999L;
        String userAnswer="";
        try{
            userAnswer=userinput.readLine();
        }catch(IOException ioe){/* //erstmal ohne Fehlertext
            System.out.println("\t*** invalid input (IOE) ***");
        */}
        try{
            outLong=Long.valueOf(userAnswer.trim());
        }catch(NumberFormatException nfe){/* //erstmal ohne Fehlertext
            System.out.println("\t*** invalid input (NFE) ***");
        */}
        if(outLong<0){
            outLong=defaultLong;
        }
        return outLong;
    }
    /**
     * Usereingabe eines String-Wertes als Problem-Parameter. Mit ENTER wird der default-Wert beibehalten.
     * @param userinput Eingabe-Reader für die Userabfrage
     * @param defaultString default-Wert des Problems
     * @return default-Wert oder Usereingabe, wenn sinnvolle Usereingabe erfolgt ist
     */
    static public String askInput(BufferedReader userinput,String defaultString){
        String outString=defaultString;
        String userAnswer="";
        try{
            userAnswer=userinput.readLine();
        }catch(IOException ioe){/* //erstmal ohne Fehlertext
            System.out.println("\t*** invalid input (IOE) ***");
        */}
        if(!(userAnswer.trim()).equals("")){
            outString=userAnswer;
        }
        return outString;
    }
    /**
     * Testaufrufe für die Fibonacci-Reihe.
     */
    static public void fibTest(){
        Fibonacci fibonacci=Fibonacci.create(3);
        System.out.println(fibonacci.csvString()+" (Instanz: "+fibonacci+")");
        fibonacci.nextMember();
        System.out.println(fibonacci.csvString()+" (Instanz: "+fibonacci+")");
        Fibonacci fibonacci2=Fibonacci.create();
        System.out.println(fibonacci2.csvString()+" (Instanz: "+fibonacci2+")");
        fibonacci2.nextMember(3);
        System.out.println(fibonacci2.csvString()+" (Instanz: "+fibonacci2+")");
        
    }
    /**
     * Testaufrufe für die  Primzahlenliste.
     */
    static public void primeTest(){
        Prime prim=Prime.create();
        //System.out.println("0 ist prim: "+prim.isPrim(0));
        //System.out.println("2 ist prim: "+prim.isPrim(2));
        //System.out.println("4 ist prim: "+prim.isPrim(4));
        //System.out.println("7 ist prim: "+prim.isPrim(7));
        //System.out.println("104743 ist prim: "+prim.isPrim(104743));
        //System.out.println(prim.csvString()+" (Instanz: "+prim+")");
        //System.out.println(""+prim.csvString());
        //System.out.println(""+prim.getMember(5));
        //System.out.println(""+prim.csvString());
        /*
        Prime prim1=Prime.create();
        System.out.println("7 ist prim: "+prim1.isPrim(7));
        System.out.println(prim1.csvString()+" (Instanz: "+prim1+")");
        System.out.println("13 ist prim: "+prim.isPrim(13));
        System.out.println(prim.csvString()+" (Instanz: "+prim+")");
        System.out.println("169 ist prim: "+prim.isPrim(169));
        System.out.println(prim.csvString()+" (Instanz: "+prim+")");
        System.out.println("97 ist prim: "+prim.isPrim(97));
        System.out.println(prim.csvString()+" (Instanz: "+prim+")");
        System.out.println("173 ist prim: "+prim.isPrim(173));
        prim.upTo(173);
        System.out.println(prim.csvString()+" (Instanz: "+prim+")");
        System.out.println("61 ist prim: "+prim.isPrim(61));
        prim.upTo(61);
        System.out.println(prim.csvString()+" (Instanz: "+prim+")");
        System.out.println("200 ist prim: "+prim.isPrim(200));
        prim.upTo(200);
        prim.nextMember(10);
        System.out.println(""+prim.csvString());
        ArrayList<Long> partial=prim.getPart(20L);
        for (long element:partial){
            System.out.print(""+element+", ");
        }
        System.out.println("");
        ArrayList<Long> partial2=prim.getPart(4L,12L);
        for (long element:partial2){
            System.out.print(""+element+", ");
        }
        System.out.println("");
        */
        
    }
    /**
     * Testaufruf der Zahl-Wort-Bestimmung für alle Zahlen bis zum Grenzwert /limit/.
     * @param limit Grenzwert
     */
    static public void numberNameTest(int limit){
        Problems equations=new Problems();
        equations.printAllNumberWord(limit);
    }
}