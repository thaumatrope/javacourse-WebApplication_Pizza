/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myPackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.message.callback.PrivateKeyCallback;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspWriter;

/**
 *
 * @author franz
 */
@WebServlet(name = "meinServlet",urlPatterns = "/meinServlet")
public class ServletPool extends HttpServlet {
    
   private String name;
   
   public void init(){
       // wird vom Servletcontainer automatisch aufgerufen bei erstelleung
       // des Objekts
   }
    
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp){
        PrintWriter out = null;
        //String name="";
        try {
           
            out = resp.getWriter();
            
            
            if(req.getSession().getAttribute("name")!=null ){ 
             this.name= (String)req.getSession().getAttribute("name");
             
            }else{
                out.print("SessionAttribut ist leer:::::");
            }
            
            out.print(this.name);
           // this.name=null;
        } catch (IOException ex) {
            Logger.getLogger(ServletPool.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            out.close();
        }
    }
    public void doPost(){
        
    }
    public void destroy(){
        //wird vom Servletcontainer aufgerufen wenn er der Meinung ist,
        //das er das Servlet nicht mehr benötigt.
    }
}
